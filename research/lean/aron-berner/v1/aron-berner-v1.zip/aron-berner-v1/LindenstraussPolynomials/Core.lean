import LindenstraussPolynomials.Compositions
import LindenstraussPolynomials.DavieGamelin

/-!
# The core of the proof

For every increasing $`n`-tuple of almost norming points the geometric lemma gives a lower bound for the fully mixed value of the limit form ({lit}`eq:vordered`); iterated limits along an ultrafilter then turn these bounds into $`\|\widetilde Q(z)\|\ge\|Q\|` at a point $`z` of the unit ball of $`X^{**}`.
-/

noncomputable section

open scoped BigOperators Topology
open Finset Filter

namespace LindenstraussPolynomials

variable {𝕜 : Type*} [RCLike 𝕜]
variable {X : Type*} [NormedAddCommGroup X] [NormedSpace 𝕜 X]
variable {Y : Type*} [NormedAddCommGroup Y] [NormedSpace 𝕜 Y]
variable {d : ℕ}

/-- The Davie–Gamelin bound for the vector-valued extension:
{lit}`‖P̃(z)‖ ≤ ‖P‖` for {lit}`‖z‖ ≤ 1`. -/
lemma norm_diagExtV_le {B : MLin 𝕜 X Y d} (hB : IsSymm B) (z : Bidual 𝕜 X) (hz : ‖z‖ ≤ 1) :
    ‖diagExtV z B‖ ≤ polyNorm (diag B) := by
  apply ContinuousLinearMap.opNorm_le_bound _ (polyNorm_nonneg _)
  intro g
  rw [diagExtV_apply]
  refine (davie_gamelin (hB.comp g) z hz).trans ?_
  rw [mul_comm]
  exact polyNorm_comp_le g B

lemma diagExtV_smul (z : Bidual 𝕜 X) (c : 𝕜) (B : MLin 𝕜 X Y d) :
    diagExtV z (c • B) = c • diagExtV z B := by
  ext g
  rw [diagExtV_apply, smul_apply, diagExtV_apply, smul_eq_mul,
    ← diagExt_smul]
  congr 1
  ext v
  simp

/-- The error term {lit}`η'_m` of {lit}`eq:vordered`. -/
def etaV (d : ℕ) (a : ℝ) (m : ℕ) : ℝ :=
  hConst (d + 1) * Real.sqrt (2 * ((7 * Kc (d + 1)) ^ (d + 1) * alpha a m)) +
    4 * (cPol (d + 1) + 1) * alpha a m

lemma tendsto_etaV {a : ℝ} (ha : 0 < a) (ha1 : a < 1) :
    Tendsto (etaV d a) atTop (𝓝 0) := by
  have h := tendsto_alpha ha.le ha1
  have h1 : Tendsto (fun m => Real.sqrt (2 * ((7 * Kc (d + 1)) ^ (d + 1) * alpha a m)))
      atTop (𝓝 0) := by
    have := ((h.const_mul ((7 * Kc (d + 1)) ^ (d + 1))).const_mul 2).sqrt
    rw [mul_zero, mul_zero, Real.sqrt_zero] at this
    exact this
  have := (h1.const_mul (hConst (d + 1))).add (h.const_mul (4 * (cPol (d + 1) + 1)))
  rw [mul_zero, mul_zero, add_zero] at this
  exact this

variable {A : MLin 𝕜 X Y (d + 1)} {a : ℝ}

/-- Equation {lit}`eq:vordered`: for {lit}`m < i₁ < ⋯ < i_n`,
{lit}`|y_m^*(Q̌(x_{i₁},…,x_{i_n}))| ≥ M - η'_m`. -/
theorem ordered_bound [CompleteSpace Y] [Nontrivial X] (hA : IsSymm A)
    (hA1 : polyNorm (diag A) = 1) (ha : 0 < a) (ha8 : a < 1 / 8) (m : ℕ)
    (ι : Fin (d + 1) → ℕ) (hι : StrictMono ι) (hm : ∀ i, m < ι i) :
    polyNorm (diag (limQ A a)) - etaV d a m ≤
      ‖seqg A a m (limQ A a (fun i => seqx A a (ι i)))‖ := by
  set ℓ := ι (Fin.last d)
  set ι' : Fin (d + 1) → ℕ := Fin.cons m (fun i : Fin d => ι i.castSucc) with hι'def
  have hι' : StrictMono ι' :=
    strictMono_cons (hι.comp Fin.strictMono_castSucc) (fun i => hm _)
  have hℓ : ∀ i, ι' i < ℓ := by
    intro i
    induction i using Fin.cases with
    | zero => simpa [ι'] using hm (Fin.last d)
    | succ i => simpa [ι'] using hι (Fin.castSucc_lt_last i)
  obtain ⟨c, hc, hchain⟩ := defc_chain (A := A) ha ha8 ℓ d ι' hι' hℓ
  set E := (7 * Kc (d + 1)) ^ (d + 1) * alpha a m with hE
  have hK := one_le_Kc (d + 1)
  have hα := alpha_pos ha m
  have hE0 : 0 ≤ E := by positivity
  set g := c • seqg A a m with hgdef
  have hg : ‖g‖ ≤ 1 := norm_smul_seqg_le ha m hc
  set a' := g.compContinuousMultilinearMap (seqP A a m) with ha'
  have hMm1 := one_le_seqM hA1 ha ha8 m
  have hMm2 := seqM_le hA1 ha (by linarith) m
  have hsymm : IsSymm a' := (isSymm_seqP hA m).comp g
  have hpn : polyNorm (diag a') ≤ seqM A a m := by
    have := polyNorm_comp_le g (seqP A a m)
    have h0 : 0 ≤ seqM A a m := by linarith
    unfold seqM at *
    nlinarith [polyNorm_nonneg (diag (seqP A a m))]
  have hgeo := geometry_lemma hsymm (by linarith : 0 < seqM A a m) hpn
    (fun i => seqx A a (ι i)) (fun i => (norm_seqx ha _).le)
    (fun i => seqf A a (ι i.castSucc)) (fun i => (norm_seqf ha _).le) hE0 (by
      intro t ht
      have h := hchain (Fin.cons 0 t) (by
        intro i
        induction i using Fin.cases with
        | zero => simp
        | succ i => simpa using ht i)
      rw [chainApply_succ] at h
      simp only [Fin.cons_zero, substOp_zero] at h
      have heq : ι' 0 = m := rfl
      rw [heq] at h
      unfold defc at h
      have h2 : seqM A a m - E ≤ RCLike.re (g (diag (seqP A a m) (chainApply
          (Fin.tail fun i => seqf A a (ι' i)) (Fin.tail fun i => seqx A a (ι' i))
          (Fin.tail (Fin.cons 0 t : Fin (d + 1) → ℝ)) (seqx A a ℓ)))) := by
        linarith
      exact h2)
  -- pass from `P_m` to `Q`
  set u : Fin (d + 1) → X := fun i => seqx A a (ι i)
  have hu : ∀ i, ‖u i‖ ≤ 1 := fun i => (norm_seqx ha _).le
  have h1 : ‖a' u‖ ≤ ‖seqg A a m (seqP A a m u)‖ := by
    simp only [a', ContinuousLinearMap.compContinuousMultilinearMap_coe, Function.comp_apply,
      g, smul_apply, norm_smul]
    nlinarith [norm_nonneg c, norm_nonneg (seqg A a m (seqP A a m u))]
  have h2 : ‖seqg A a m (seqP A a m u)‖ ≤
      ‖seqg A a m (limQ A a u)‖ + cPol (d + 1) * (4 * alpha a m) := by
    have e : seqg A a m (seqP A a m u) =
        seqg A a m (limQ A a u) - seqg A a m ((limQ A a - seqP A a m) u) := by
      simp
    rw [e]
    refine (norm_sub_le _ _).trans (add_le_add le_rfl ?_)
    calc ‖seqg A a m ((limQ A a - seqP A a m) u)‖
        ≤ ‖seqg A a m‖ * ‖(limQ A a - seqP A a m) u‖ := (seqg A a m).le_opNorm _
      _ ≤ 1 * ‖limQ A a - seqP A a m‖ :=
          mul_le_mul (norm_seqg ha m) (norm_apply_le_of_ball _ hu) (norm_nonneg _) zero_le_one
      _ ≤ cPol (d + 1) * (4 * alpha a m) := by
          rw [one_mul]; exact opNorm_limQ_sub hA hA1 ha ha8 m
  have h3 := abs_polyNorm_limQ_sub hA hA1 ha ha8 m
  have h4 : Real.sqrt (seqM A a m * E) ≤ Real.sqrt (2 * E) := by
    apply Real.sqrt_le_sqrt
    have : seqM A a m ≤ 2 := hMm2.trans (by rw [div_le_iff₀ (by linarith)]; linarith)
    nlinarith
  have hH : 0 ≤ hConst (d + 1) := (zero_le_one).trans (one_le_hConst (by omega))
  have h5 : hConst (d + 1) * Real.sqrt (seqM A a m * E) ≤ hConst (d + 1) * Real.sqrt (2 * E) :=
    mul_le_mul_of_nonneg_left h4 hH
  rw [abs_le] at h3
  unfold etaV
  rw [← hE]
  have : ‖a' u‖ = ‖a' fun i => seqx A a (ι i)‖ := rfl
  linarith

/-- The core theorem for normalized symmetric forms: there is a symmetric {lit}`B` with
{lit}`‖B - A‖ < ε` (as polynomials) whose canonical extension attains its norm. -/
theorem core_attain [CompleteSpace Y] [Nontrivial X] (hA : IsSymm A)
    (hA1 : polyNorm (diag A) = 1) {ε : ℝ} (hε : 0 < ε) :
    ∃ B : MLin 𝕜 X Y (d + 1), IsSymm B ∧ polyNorm (diag (B - A)) < ε ∧
      ∃ z : Bidual 𝕜 X, ‖z‖ ≤ 1 ∧ ‖diagExtV z B‖ = polyNorm (diag B) := by
  set a := min (1 / 16) (ε / 8) with hadef
  have ha : 0 < a := lt_min (by norm_num) (by linarith)
  have ha8 : a < 1 / 8 := (min_le_left _ _).trans_lt (by norm_num)
  have haε : 4 * a < ε := by
    have : a ≤ ε / 8 := min_le_right _ _
    linarith
  refine ⟨limQ A a, isSymm_limQ hA hA1 ha ha8,
    (polyNorm_limQ_sub_A hA hA1 ha ha8).trans_lt haε, ?_⟩
  have hx : ∀ k, ‖seqx A a k‖ ≤ 1 := fun k => (norm_seqx ha k).le
  set z := ultraPoint (𝕜 := 𝕜) (seqx A a) hx
  refine ⟨z, norm_ultraPoint_le _ _, le_antisymm
    (norm_diagExtV_le (isSymm_limQ hA hA1 ha ha8) z (norm_ultraPoint_le _ _)) ?_⟩
  have hlow : ∀ m, polyNorm (diag (limQ A a)) - etaV d a m ≤ ‖diagExtV z (limQ A a)‖ := by
    intro m
    have h := le_norm_diagExt_ultra (seqx A a) hx m (polyNorm (diag (limQ A a)) - etaV d a m)
      ((seqg A a m).compContinuousMultilinearMap (limQ A a)) (fun ι hι hm => by
        simpa using ordered_bound hA hA1 ha ha8 m ι hι hm)
    refine h.trans ?_
    rw [← diagExtV_apply]
    calc ‖diagExtV z (limQ A a) (seqg A a m)‖ ≤ ‖diagExtV z (limQ A a)‖ * ‖seqg A a m‖ :=
          (diagExtV z (limQ A a)).le_opNorm _
      _ ≤ ‖diagExtV z (limQ A a)‖ * 1 :=
          mul_le_mul_of_nonneg_left (norm_seqg ha m) (norm_nonneg (diagExtV z (limQ A a)))
      _ = _ := mul_one _
  have ht := (tendsto_etaV (d := d) ha (by linarith)).const_sub (polyNorm (diag (limQ A a)))
  rw [sub_zero] at ht
  exact le_of_tendsto ht (Eventually.of_forall hlow)

end LindenstraussPolynomials
