import LindenstraussPolynomials.Chain

/-!
# The geometric lemma (Lemma lem:geometry and Remark rem:real)

Let $`\|P\|\le M`, $`u_1,\ldots,u_n` in the unit ball of $`X` and $`f_1,\ldots,f_{n-1}` in the unit ball of $`X^*`. If
$$`\operatorname{Re}P\bigl(S_1(t_1)\cdots S_{n-1}(t_{n-1})\,u_n\bigr)\ge M-E\quad\text{for all }t_1,\ldots,t_{n-1}\in[0,1],`
then the fully mixed value of the symmetric form is almost maximal:
$$`|\check P(u_1,\ldots,u_n)| \ge M - H_n\sqrt{ME}.`
Over $`\mathbb R` the bound improves to $`M-C_nE` (Remark {lit}`rem:real`).
-/

noncomputable section

open scoped BigOperators
open Finset

namespace LindenstraussPolynomials

/-- {lit}`D_n = (1/n!) ∑_{r=1}^n C(n,r) r^n` ({lit}`eq:constants`). -/
def dConst (n : ℕ) : ℝ := (1 / (n.factorial : ℝ)) * ∑ r ∈ Finset.Icc 1 n, (n.choose r : ℝ) * (r : ℝ) ^ n

/-- {lit}`H_n = D_n (√2 + 2n(n-1)c_n)` ({lit}`eq:constants`). -/
def hConst (n : ℕ) : ℝ := dConst n * (Real.sqrt 2 + 2 * n * (n - 1) * cPol n)

/-- {lit}`C_n = D_n (1 + 2n(n-1)c_n)` (Remark {lit}`rem:real`). -/
def cConstReal (n : ℕ) : ℝ := dConst n * (1 + 2 * n * (n - 1) * cPol n)

lemma one_le_dConst {n : ℕ} (hn : 1 ≤ n) : 1 ≤ dConst n := by
  unfold dConst
  have hfac : (0 : ℝ) < n.factorial := by exact_mod_cast Nat.factorial_pos n
  have hterm : (n : ℝ) ^ n ≤ ∑ r ∈ Finset.Icc 1 n, (n.choose r : ℝ) * (r : ℝ) ^ n := by
    have hmem : n ∈ Finset.Icc 1 n := Finset.mem_Icc.mpr ⟨hn, le_rfl⟩
    have := Finset.single_le_sum (f := fun r => (n.choose r : ℝ) * (r : ℝ) ^ n)
      (fun r _ => by positivity) hmem
    simpa using this
  rw [one_div, inv_mul_eq_div, le_div_iff₀ hfac, one_mul]
  refine le_trans ?_ hterm
  exact_mod_cast Nat.factorial_le_pow n

lemma dConst_nonneg (n : ℕ) : 0 ≤ dConst n := by unfold dConst; positivity

lemma one_le_hConst {n : ℕ} (hn : 1 ≤ n) : 1 ≤ hConst n := by
  unfold hConst
  have h1 : (1 : ℝ) ≤ Real.sqrt 2 := by
    rw [show (1 : ℝ) = Real.sqrt 1 by simp]
    exact Real.sqrt_le_sqrt (by norm_num)
  have h2 : 0 ≤ 2 * (n : ℝ) * (n - 1) * cPol n := by
    have : (1 : ℝ) ≤ n := by exact_mod_cast hn
    have := cPol_nonneg n
    have : 0 ≤ (n : ℝ) - 1 := by linarith
    positivity
  have := one_le_dConst hn
  nlinarith

lemma one_le_cConstReal {n : ℕ} (hn : 1 ≤ n) : 1 ≤ cConstReal n := by
  unfold cConstReal
  have h2 : 0 ≤ 2 * (n : ℝ) * (n - 1) * cPol n := by
    have : (1 : ℝ) ≤ n := by exact_mod_cast hn
    have := cPol_nonneg n
    have : 0 ≤ (n : ℝ) - 1 := by linarith
    positivity
  have := one_le_dConst hn
  nlinarith

/-- {lit}`∑_{F ⊆ {1,…,n}} |F|^n = n! D_n`. -/
lemma sum_card_pow_eq {n : ℕ} (hn : 1 ≤ n) :
    (∑ F : Finset (Fin n), ((F.card : ℝ)) ^ n) = n.factorial * dConst n := by
  have h1 := Finset.sum_powerset_apply_card (fun m => ((m : ℝ)) ^ n) (x := (univ : Finset (Fin n)))
  rw [Finset.powerset_univ] at h1
  rw [h1]
  simp only [Finset.card_univ, Fintype.card_fin, nsmul_eq_mul]
  unfold dConst
  have hfac : (n.factorial : ℝ) ≠ 0 := by exact_mod_cast (Nat.factorial_pos n).ne'
  rw [← mul_assoc, mul_one_div_cancel hfac, one_mul]
  rw [Finset.range_eq_Ico, Finset.sum_eq_sum_Ico_succ_bot (by omega)]
  have : Finset.Ico 1 (n + 1) = Finset.Icc 1 n := rfl
  rw [this]
  simp [zero_pow (by omega : n ≠ 0)]

variable {𝕜 : Type*} [RCLike 𝕜]
variable {X : Type*} [NormedAddCommGroup X] [NormedSpace 𝕜 X]

/-- {lit}`∑_F (-1)^{n-|F|} |F|^n = n!` (finite polarization applied to {lit}`t ↦ t^n`). -/
lemma alt_sum_card_pow (n : ℕ) :
    (∑ F : Finset (Fin n), ((-1 : 𝕜) ^ (n - F.card)) * ((F.card : 𝕜)) ^ n) = n.factorial := by
  have hsymm : IsSymm (ContinuousMultilinearMap.mkPiAlgebra 𝕜 (Fin n) 𝕜) := by
    intro σ v
    simp only [ContinuousMultilinearMap.mkPiAlgebra_apply, Function.comp_apply]
    exact Equiv.prod_comp σ v
  have := finite_polarization hsymm (fun _ => (1 : 𝕜))
  simp only [ContinuousMultilinearMap.mkPiAlgebra_apply, diag_apply, Finset.prod_const_one,
    smul_eq_mul, mul_one, Finset.sum_const, Finset.prod_const, Finset.card_univ,
    Fintype.card_fin, nsmul_eq_mul] at this
  rw [this]

variable {d : ℕ}

/-- The core of Lemma {lit}`lem:geometry`, with abstract defects {lit}`δ` (compatibility) and
{lit}`κ` (flatness along composed vectors). -/
theorem geometry_core {a : MLin 𝕜 X 𝕜 (d + 1)} (ha : IsSymm a) {M : ℝ}
    (hPM : polyNorm (diag a) ≤ M) (f : Fin d → StrongDual 𝕜 X) (u : Fin d → X) (x : X)
    (hf : ∀ i, ‖f i‖ ≤ 1) (hu : ∀ i, ‖u i‖ ≤ 1) (hx : ‖x‖ ≤ 1) {δ κ : ℝ} (hδ : 0 ≤ δ)
    (hκ : 0 ≤ κ)
    (hcomp : ∀ i j : Fin d, i < j → ‖f i (f j x • u j) - f i x‖ ≤ δ)
    (hflat : ∀ t : Fin d → ℝ, (∀ i, t i ∈ Set.Icc (0 : ℝ) 1) →
      ‖diag a (chainApply f u t x) - (M : 𝕜)‖ ≤ κ) :
    ‖a (zv f u x) - (M : 𝕜)‖ ≤
      dConst (d + 1) * (((d + 1 : ℕ) : ℝ) * cPol (d + 1) * M * (d * δ) + κ) := by
  have hM0 : 0 ≤ M := (polyNorm_nonneg _).trans hPM
  set C' := ((d + 1 : ℕ) : ℝ) * cPol (d + 1) * M * (d * δ) + κ with hC'
  have hC'0 : 0 ≤ C' := by
    have := cPol_nonneg (d + 1)
    positivity
  have hz : ∀ k, ‖zv f u x k‖ ≤ 1 := norm_zv_le hf hu hx
  -- (a) flatness on the convex hull (`eq:flat`)
  have hconv : ∀ θ : Fin (d + 1) → ℝ, (∀ k, 0 ≤ θ k) → ∑ k, θ k = 1 →
      ‖diag a (∑ k, ((θ k : ℝ) : 𝕜) • zv f u x k) - (M : 𝕜)‖ ≤ C' := by
    intro θ hθ hθs
    obtain ⟨t, ht, hdist⟩ := chain_approx f u x δ hδ hf hu hcomp θ hθ hθs
    set y := chainApply f u t x
    set v := ∑ k, ((θ k : ℝ) : 𝕜) • zv f u x k
    have hy : ‖y‖ ≤ 1 := (norm_chainApply_le f u t hf hu ht x).trans hx
    have hv : ‖v‖ ≤ 1 := by
      calc ‖v‖ ≤ ∑ k, ‖((θ k : ℝ) : 𝕜) • zv f u x k‖ := norm_sum_le _ _
        _ ≤ ∑ k, θ k * 1 := by
            gcongr with k
            rw [norm_smul, RCLike.norm_ofReal, abs_of_nonneg (hθ k)]
            exact mul_le_mul_of_nonneg_left (hz k) (hθ k)
        _ = 1 := by simp [hθs]
    have hlip := lipschitz_diag ha hv hy
    calc ‖diag a v - (M : 𝕜)‖ ≤ ‖diag a v - diag a y‖ + ‖diag a y - (M : 𝕜)‖ := by
          rw [← dist_eq_norm, ← dist_eq_norm, ← dist_eq_norm]; exact dist_triangle _ _ _
      _ ≤ ((d + 1 : ℕ) : ℝ) * cPol (d + 1) * polyNorm (diag a) * ‖v - y‖ + κ :=
          add_le_add hlip (hflat t ht)
      _ ≤ ((d + 1 : ℕ) : ℝ) * cPol (d + 1) * M * (d * δ) + κ := by
          have hc0 : 0 ≤ ((d + 1 : ℕ) : ℝ) * cPol (d + 1) := by
            have := cPol_nonneg (d + 1); positivity
          have hvy : ‖v - y‖ ≤ d * δ := by rw [norm_sub_rev]; exact hdist
          have := mul_le_mul (mul_le_mul_of_nonneg_left hPM hc0) hvy (norm_nonneg _)
            (by positivity)
          linarith
  -- (b) values on sums over subsets
  have hsub : ∀ F : Finset (Fin (d + 1)),
      ‖diag a (∑ j ∈ F, zv f u x j) - ((F.card : 𝕜)) ^ (d + 1) * (M : 𝕜)‖ ≤
        ((F.card : ℝ)) ^ (d + 1) * C' := by
    intro F
    rcases F.eq_empty_or_nonempty with rfl | hF
    · simp only [Finset.sum_empty, Finset.card_empty, Nat.cast_zero]
      have : diag a (0 : X) = 0 := by
        simp only [diag_apply]
        exact a.map_coord_zero 0 rfl
      rw [this, zero_pow (by omega), zero_pow (by omega)]
      simp
    · have hcard : (0 : ℝ) < F.card := by exact_mod_cast hF.card_pos
      set θ : Fin (d + 1) → ℝ := fun k => if k ∈ F then 1 / (F.card : ℝ) else 0
      have hθ : ∀ k, 0 ≤ θ k := fun k => by
        simp only [θ]; split_ifs <;> positivity
      have hθs : ∑ k, θ k = 1 := by
        simp only [θ]
        rw [Finset.sum_ite_mem, Finset.univ_inter, Finset.sum_const, nsmul_eq_mul]
        field_simp
      have hsum : (∑ j ∈ F, zv f u x j) =
          ((F.card : ℝ) : 𝕜) • ∑ k, ((θ k : ℝ) : 𝕜) • zv f u x k := by
        rw [Finset.smul_sum]
        have hk : ∀ k, ((F.card : ℝ) : 𝕜) • (((θ k : ℝ) : 𝕜) • zv f u x k) =
            if k ∈ F then zv f u x k else 0 := by
          intro k
          simp only [θ, smul_smul, ← RCLike.ofReal_mul]
          split_ifs with hk
          · rw [mul_one_div_cancel hcard.ne', RCLike.ofReal_one, one_smul]
          · simp
        simp_rw [hk]
        rw [Finset.sum_ite_mem, Finset.univ_inter]
      rw [hsum, diag_smul_arg]
      have h := hconv θ hθ hθs
      calc ‖(((F.card : ℝ) : 𝕜)) ^ (d + 1) • diag a (∑ k, ((θ k : ℝ) : 𝕜) • zv f u x k) -
            ((F.card : 𝕜)) ^ (d + 1) * (M : 𝕜)‖
          = ((F.card : ℝ)) ^ (d + 1) *
              ‖diag a (∑ k, ((θ k : ℝ) : 𝕜) • zv f u x k) - (M : 𝕜)‖ := by
            rw [smul_eq_mul, show ((F.card : 𝕜)) = (((F.card : ℝ)) : 𝕜) by simp, ← mul_sub,
              norm_mul, norm_pow, RCLike.norm_ofReal, abs_of_nonneg hcard.le]
        _ ≤ ((F.card : ℝ)) ^ (d + 1) * C' := by gcongr
  -- (c) polarization
  have hpol := finite_polarization ha (zv f u x)
  have halt := alt_sum_card_pow (𝕜 := 𝕜) (d + 1)
  have hfac : (0 : ℝ) < (d + 1).factorial := by exact_mod_cast Nat.factorial_pos (d + 1)
  have key : (((d + 1).factorial : 𝕜)) * (a (zv f u x) - (M : 𝕜)) =
      ∑ F : Finset (Fin (d + 1)), ((-1 : 𝕜) ^ ((d + 1) - F.card)) *
        (diag a (∑ j ∈ F, zv f u x j) - ((F.card : 𝕜)) ^ (d + 1) * (M : 𝕜)) := by
    rw [mul_sub, ← smul_eq_mul, hpol, ← halt]
    simp only [smul_eq_mul, Finset.sum_mul, ← Finset.sum_sub_distrib]
    refine Finset.sum_congr rfl fun F _ => ?_
    ring
  have hbound : (((d + 1).factorial : ℝ)) * ‖a (zv f u x) - (M : 𝕜)‖ ≤
      (d + 1).factorial * dConst (d + 1) * C' := by
    have h1 : ‖(((d + 1).factorial : 𝕜)) * (a (zv f u x) - (M : 𝕜))‖ =
        ((d + 1).factorial : ℝ) * ‖a (zv f u x) - (M : 𝕜)‖ := by
      rw [norm_mul, RCLike.norm_natCast]
    rw [← h1, key]
    calc ‖∑ F : Finset (Fin (d + 1)), ((-1 : 𝕜) ^ ((d + 1) - F.card)) *
          (diag a (∑ j ∈ F, zv f u x j) - ((F.card : 𝕜)) ^ (d + 1) * (M : 𝕜))‖
        ≤ ∑ F : Finset (Fin (d + 1)), ‖((-1 : 𝕜) ^ ((d + 1) - F.card)) *
          (diag a (∑ j ∈ F, zv f u x j) - ((F.card : 𝕜)) ^ (d + 1) * (M : 𝕜))‖ := norm_sum_le _ _
      _ ≤ ∑ F : Finset (Fin (d + 1)), ((F.card : ℝ)) ^ (d + 1) * C' := by
          gcongr with F
          rw [norm_mul, norm_pow, norm_neg, norm_one, one_pow, one_mul]
          exact hsub F
      _ = (d + 1).factorial * dConst (d + 1) * C' := by
          rw [← Finset.sum_mul, sum_card_pow_eq (by omega)]
  have hb2 : ((d + 1).factorial : ℝ) * ‖a (zv f u x) - (M : 𝕜)‖ ≤
      ((d + 1).factorial : ℝ) * (dConst (d + 1) * C') := by
    rw [← mul_assoc]; exact hbound
  exact le_of_mul_le_mul_left hb2 hfac

/-- {lit}`a(z₀,…,z_d) = (∏ fᵢ(x)) a(u₀,…,u_{d-1},x)`. -/
lemma apply_zv {a : MLin 𝕜 X 𝕜 (d + 1)} (f : Fin d → StrongDual 𝕜 X) (u : Fin (d + 1) → X) :
    a (zv f (fun i => u i.castSucc) (u (Fin.last d))) =
      (∏ i, f i (u (Fin.last d))) * a u := by
  have h : zv f (fun i => u i.castSucc) (u (Fin.last d)) =
      fun k => (Fin.lastCases (1 : 𝕜) (fun j => f j (u (Fin.last d))) k : 𝕜) • u k := by
    funext k
    induction k using Fin.lastCases with
    | last => simp
    | cast j => simp
  rw [h, a.map_smul_univ, Fin.prod_univ_castSucc]
  simp

lemma norm_prod_le_one {f : Fin d → StrongDual 𝕜 X} (hf : ∀ i, ‖f i‖ ≤ 1) {x : X}
    (hx : ‖x‖ ≤ 1) : ‖∏ i, f i x‖ ≤ 1 := by
  rw [norm_prod]
  refine Finset.prod_le_one₀ (fun _ _ => norm_nonneg _) (fun i _ => ?_)
  calc ‖f i x‖ ≤ ‖f i‖ * ‖x‖ := (f i).le_opNorm x
    _ ≤ 1 * 1 := by gcongr; exact hf i
    _ = 1 := one_mul 1

/-- The vector {lit}`S_i(1) S_j(1/2) x` used in the compatibility step. -/
lemma chain_pair_value (f : Fin d → StrongDual 𝕜 X) (u : Fin d → X) (x : X) {i j : Fin d}
    (hij : i < j) :
    chainApply f u (fun h => if h = i then 1 else if h = j then 1 / 2 else 0) x =
      ((1 / 2 : 𝕜) * (f i x + f j x * f i (u j))) • u i := by
  rw [chainApply_pair f u _ i j hij (fun h hi hj => by simp [hi, hj])]
  have hji : j ≠ i := (ne_of_lt hij).symm
  simp only [ite_eq_right hji, substOp_apply]
  simp only [map_add, map_smul, smul_eq_mul]
  push_cast
  simp only [sub_self, zero_smul, zero_add, one_smul]
  congr 1
  ring

/-- **Lemma {lit}`lem:geometry`.** Let {lit}`a` be a symmetric {lit}`(d+1)`-linear form (the symmetric form of
{lit}`P`), {lit}`‖P‖ ≤ M`, {lit}`u₀,…,u_d ∈ B_X`, {lit}`f₀,…,f_{d-1} ∈ B_{X*}`, and suppose that
{lit}`Re P(S₀(t₀) ⋯ S_{d-1}(t_{d-1}) u_d) ≥ M - E` for all {lit}`tᵢ ∈ [0,1]`.  Then
{lit}`|a(u₀,…,u_d)| ≥ M - H_{d+1} √(ME)`. -/
theorem geometry_lemma {a : MLin 𝕜 X 𝕜 (d + 1)} (ha : IsSymm a) {M : ℝ} (hM : 0 < M)
    (hPM : polyNorm (diag a) ≤ M) (u : Fin (d + 1) → X) (hu : ∀ i, ‖u i‖ ≤ 1)
    (f : Fin d → StrongDual 𝕜 X) (hf : ∀ i, ‖f i‖ ≤ 1) {E : ℝ} (hE : 0 ≤ E)
    (hpath : ∀ t : Fin d → ℝ, (∀ i, t i ∈ Set.Icc (0 : ℝ) 1) →
      M - E ≤ RCLike.re (diag a (chainApply f (fun i => u i.castSucc) t (u (Fin.last d))))) :
    M - hConst (d + 1) * Real.sqrt (M * E) ≤ ‖a u‖ := by
  by_cases hEM : M ≤ E
  · have h1 : M ≤ Real.sqrt (M * E) := Real.le_sqrt_of_sq_le (by nlinarith)
    have h2 := one_le_hConst (n := d + 1) (by omega)
    have h3 : 0 ≤ Real.sqrt (M * E) := Real.sqrt_nonneg _
    nlinarith [norm_nonneg (a u)]
  push Not at hEM
  set ρ := E / M with hρ
  have hρ0 : 0 ≤ ρ := div_nonneg hE hM.le
  have hρ1 : ρ < 1 := (div_lt_one hM).mpr hEM
  set x := u (Fin.last d) with hxdef
  set u' : Fin d → X := fun i => u i.castSucc with hu'def
  have hx : ‖x‖ ≤ 1 := hu _
  have hu' : ∀ i, ‖u' i‖ ≤ 1 := fun i => hu _
  -- compatibility (`eq:compatibility`)
  have hcomp : ∀ i j : Fin d, i < j → ‖f i (f j x • u' j) - f i x‖ ≤ 2 * Real.sqrt ρ := by
    intro i j hij
    set c : 𝕜 := (1 / 2 : 𝕜) * (f i x + f j x * f i (u' j)) with hc
    have hval := chain_pair_value f u' x hij
    set t : Fin d → ℝ := fun h => if h = i then 1 else if h = j then 1 / 2 else 0
    have ht : ∀ h, t h ∈ Set.Icc (0 : ℝ) 1 := by
      intro h; simp only [t]; split_ifs <;> constructor <;> norm_num
    have hp := hpath t ht
    rw [hval, diag_smul_arg] at hp
    have hnfx : ‖f i x‖ ≤ 1 := by
      calc ‖f i x‖ ≤ ‖f i‖ * ‖x‖ := (f i).le_opNorm x
        _ ≤ 1 * 1 := by gcongr; exact hf i
        _ = 1 := one_mul 1
    have hnυ : ‖f j x * f i (u' j)‖ ≤ 1 := by
      rw [norm_mul]
      have h1 : ‖f j x‖ ≤ 1 := by
        calc ‖f j x‖ ≤ ‖f j‖ * ‖x‖ := (f j).le_opNorm x
          _ ≤ 1 * 1 := by gcongr; exact hf j
          _ = 1 := one_mul 1
      have h2 : ‖f i (u' j)‖ ≤ 1 := by
        calc ‖f i (u' j)‖ ≤ ‖f i‖ * ‖u' j‖ := (f i).le_opNorm _
          _ ≤ 1 * 1 := by gcongr; exacts [hf i, hu' j]
          _ = 1 := one_mul 1
      calc ‖f j x‖ * ‖f i (u' j)‖ ≤ 1 * 1 := by gcongr
        _ = 1 := one_mul 1
    have hcn : ‖c‖ ≤ 1 := by
      rw [hc, norm_mul]
      have : ‖f i x + f j x * f i (u' j)‖ ≤ 2 :=
        (norm_add_le _ _).trans (by linarith)
      have h2 : ‖(1 / 2 : 𝕜)‖ = 1 / 2 := by simp
      rw [h2]; linarith
    have hpu : ‖diag a (u' i)‖ ≤ M := (norm_diag_le_polyNorm a (hu' i)).trans hPM
    -- `M - E ≤ ‖c‖^(d + 1) M`
    have hcM : M - E ≤ ‖c‖ ^ (d + 1) * M := by
      calc M - E ≤ RCLike.re (c ^ (d + 1) • diag a (u' i)) := hp
        _ ≤ ‖c ^ (d + 1) • diag a (u' i)‖ := RCLike.re_le_norm _
        _ = ‖c‖ ^ (d + 1) * ‖diag a (u' i)‖ := by rw [norm_smul, norm_pow]
        _ ≤ ‖c‖ ^ (d + 1) * M := by gcongr
    have hcn' : 1 - ρ ≤ ‖c‖ ^ (d + 1) := by
      rw [hρ, sub_le_iff_le_add, ← sub_le_iff_le_add', le_div_iff₀ hM]
      linarith
    have hd2 : 2 ≤ (d + 1) := by
      have : (i : ℕ) < j := hij
      have : (j : ℕ) < d := j.isLt
      omega
    have hc2 : 1 - ρ ≤ ‖c‖ ^ 2 :=
      hcn'.trans (pow_le_pow_of_le_one (norm_nonneg _) hcn hd2)
    -- parallelogram law
    set ξ := f i x
    set υ := f j x * f i (u' j)
    have hυ : f i (f j x • u' j) = υ := by simp [υ]
    rw [hυ]
    have hpar := parallelogram_law_with_norm ℝ ξ υ
    have hsum : ‖ξ + υ‖ = 2 * ‖c‖ := by
      rw [hc, norm_mul]
      simp
    have hsq : ‖υ - ξ‖ ^ 2 ≤ (2 * Real.sqrt ρ) ^ 2 := by
      rw [mul_pow, Real.sq_sqrt hρ0, norm_sub_rev]
      have hξ1 := hnfx
      nlinarith [norm_nonneg ξ, norm_nonneg υ, norm_nonneg (ξ - υ)]
    exact (pow_le_pow_iff_left₀ (norm_nonneg _) (by positivity) two_ne_zero).mp hsq
  -- flatness along composed vectors
  have hflat : ∀ t : Fin d → ℝ, (∀ i, t i ∈ Set.Icc (0 : ℝ) 1) →
      ‖diag a (chainApply f u' t x) - (M : 𝕜)‖ ≤ Real.sqrt (2 * (M * E)) := by
    intro t ht
    set w := diag a (chainApply f u' t x)
    have hw : ‖w‖ ≤ M :=
      (norm_diag_le_polyNorm a ((norm_chainApply_le f u' t hf hu' ht x).trans hx)).trans hPM
    have hre := hpath t ht
    apply Real.le_sqrt_of_sq_le
    have h1 : ‖w - (M : 𝕜)‖ ^ 2 = ‖w‖ ^ 2 - 2 * M * RCLike.re w + M ^ 2 := by
      rw [RCLike.norm_sq_eq_def, RCLike.norm_sq_eq_def]
      simp only [map_sub, RCLike.ofReal_re, RCLike.ofReal_im, sub_zero]
      ring
    rw [h1]
    nlinarith [norm_nonneg w]
  have hcore := geometry_core ha hPM f u' x hf hu' hx (by positivity) (Real.sqrt_nonneg _)
    hcomp hflat
  -- simplify the constant
  have hsqrtρ : M * Real.sqrt ρ = Real.sqrt (M * E) := by
    rw [show M * E = M ^ 2 * ρ by rw [hρ]; field_simp, Real.sqrt_mul (sq_nonneg M),
      Real.sqrt_sq hM.le]
  have hconst : dConst (d + 1) * (((d + 1 : ℕ) : ℝ) * cPol (d + 1) * M * (d * (2 * Real.sqrt ρ)) +
      Real.sqrt (2 * (M * E))) = hConst (d + 1) * Real.sqrt (M * E) := by
    rw [hConst, Real.sqrt_mul (by norm_num : (0 : ℝ) ≤ 2)]
    have e1 : ((d + 1 : ℕ) : ℝ) * cPol (d + 1) * M * (d * (2 * Real.sqrt ρ)) =
        2 * ((d + 1 : ℕ) : ℝ) * d * cPol (d + 1) * (M * Real.sqrt ρ) := by ring
    rw [e1, hsqrtρ]
    push_cast
    ring
  rw [hconst] at hcore
  have hz := apply_zv (a := a) f u
  have hprod := norm_prod_le_one hf hx
  have hzu : ‖a (zv f u' x)‖ ≤ ‖a u‖ := by
    rw [hz, norm_mul]
    calc ‖∏ i, f i (u (Fin.last d))‖ * ‖a u‖ ≤ 1 * ‖a u‖ := by gcongr
      _ = ‖a u‖ := one_mul _
  have : M - ‖a (zv f u' x) - (M : 𝕜)‖ ≤ ‖a (zv f u' x)‖ := by
    have := norm_sub_norm_le (M : 𝕜) (a (zv f u' x))
    rw [norm_sub_rev (M : 𝕜), RCLike.norm_ofReal, abs_of_pos hM] at this
    linarith
  linarith

end LindenstraussPolynomials

namespace LindenstraussPolynomials

variable {X : Type*} [NormedAddCommGroup X] [NormedSpace ℝ X]
variable {d : ℕ}

/-- **Remark {lit}`rem:real`.** Over {lit}`ℝ`, the conclusion of Lemma {lit}`lem:geometry` improves to
{lit}`|a(u₀,…,u_d)| ≥ M - C_{d+1} E` with {lit}`C_n = D_n (1 + 2n(n-1)c_n)`. -/
theorem geometry_lemma_real {a : MLin ℝ X ℝ (d + 1)} (ha : IsSymm a) {M : ℝ} (hM : 0 < M)
    (hPM : polyNorm (diag a) ≤ M) (u : Fin (d + 1) → X) (hu : ∀ i, ‖u i‖ ≤ 1)
    (f : Fin d → StrongDual ℝ X) (hf : ∀ i, ‖f i‖ ≤ 1) {E : ℝ} (hE : 0 ≤ E)
    (hpath : ∀ t : Fin d → ℝ, (∀ i, t i ∈ Set.Icc (0 : ℝ) 1) →
      M - E ≤ diag a (chainApply f (fun i => u i.castSucc) t (u (Fin.last d)))) :
    M - cConstReal (d + 1) * E ≤ |a u| := by
  by_cases hEM : M ≤ E
  · have h2 := one_le_cConstReal (n := d + 1) (by omega)
    nlinarith [abs_nonneg (a u)]
  push Not at hEM
  set ρ := E / M with hρ
  have hρ0 : 0 ≤ ρ := div_nonneg hE hM.le
  set x := u (Fin.last d) with hxdef
  set u' : Fin d → X := fun i => u i.castSucc with hu'def
  have hx : ‖x‖ ≤ 1 := hu _
  have hu' : ∀ i, ‖u' i‖ ≤ 1 := fun i => hu _
  have hcomp : ∀ i j : Fin d, i < j → ‖f i (f j x • u' j) - f i x‖ ≤ 2 * ρ := by
    intro i j hij
    set c : ℝ := (1 / 2 : ℝ) * (f i x + f j x * f i (u' j)) with hc
    have hval := chain_pair_value f u' x hij
    set t : Fin d → ℝ := fun h => if h = i then 1 else if h = j then 1 / 2 else 0
    have ht : ∀ h, t h ∈ Set.Icc (0 : ℝ) 1 := by
      intro h; simp only [t]; split_ifs <;> constructor <;> norm_num
    have hp := hpath t ht
    rw [hval, diag_smul_arg] at hp
    have hbound : ∀ (g : StrongDual ℝ X) (v : X), ‖g‖ ≤ 1 → ‖v‖ ≤ 1 → |g v| ≤ 1 := by
      intro g v hg hv
      calc |g v| = ‖g v‖ := (Real.norm_eq_abs _).symm
        _ ≤ ‖g‖ * ‖v‖ := g.le_opNorm v
        _ ≤ 1 * 1 := by gcongr
        _ = 1 := one_mul 1
    have hξ : |f i x| ≤ 1 := hbound _ _ (hf i) hx
    have hυ : |f j x * f i (u' j)| ≤ 1 := by
      rw [abs_mul]
      have h1 := hbound _ _ (hf j) hx
      have h2 := hbound _ _ (hf i) (hu' j)
      calc |f j x| * |f i (u' j)| ≤ 1 * 1 := by gcongr
        _ = 1 := one_mul 1
    have hcn : |c| ≤ 1 := by
      rw [hc, abs_mul]
      have : |f i x + f j x * f i (u' j)| ≤ 2 := (abs_add_le _ _).trans (by linarith)
      rw [abs_of_pos (by norm_num : (0 : ℝ) < 1 / 2)]; linarith
    have hpu : |diag a (u' i)| ≤ M := by
      have := (norm_diag_le_polyNorm a (hu' i)).trans hPM
      rwa [Real.norm_eq_abs] at this
    have hcM : M - E ≤ |c| ^ (d + 1) * M := by
      calc M - E ≤ c ^ (d + 1) • diag a (u' i) := hp
        _ ≤ |c ^ (d + 1) • diag a (u' i)| := le_abs_self _
        _ = |c| ^ (d + 1) * |diag a (u' i)| := by rw [smul_eq_mul, abs_mul, abs_pow]
        _ ≤ |c| ^ (d + 1) * M := by gcongr
    have hcn' : 1 - ρ ≤ |c| ^ (d + 1) := by
      rw [hρ, sub_le_iff_le_add, ← sub_le_iff_le_add', le_div_iff₀ hM]
      linarith
    have hc1 : 1 - ρ ≤ |c| :=
      hcn'.trans (pow_le_of_le_one (abs_nonneg _) hcn (by omega))
    set ξ := f i x
    set υ := f j x * f i (u' j)
    have hυeq : f i (f j x • u' j) = υ := by simp [υ]
    rw [hυeq, Real.norm_eq_abs]
    have hsum : |ξ + υ| = 2 * |c| := by
      rw [hc, abs_mul, abs_of_pos (by norm_num : (0 : ℝ) < 1 / 2)]; ring
    have hpm : |υ - ξ| + |ξ + υ| ≤ 2 := by
      rw [abs_le] at hξ hυ
      rcases abs_cases (υ - ξ) with ⟨h1, _⟩ | ⟨h1, _⟩ <;>
        rcases abs_cases (ξ + υ) with ⟨h2, _⟩ | ⟨h2, _⟩ <;> linarith
    linarith
  have hflat : ∀ t : Fin d → ℝ, (∀ i, t i ∈ Set.Icc (0 : ℝ) 1) →
      ‖diag a (chainApply f u' t x) - ((M : ℝ) : ℝ)‖ ≤ E := by
    intro t ht
    have hw : |diag a (chainApply f u' t x)| ≤ M := by
      have := (norm_diag_le_polyNorm a
        ((norm_chainApply_le f u' t hf hu' ht x).trans hx)).trans hPM
      rwa [Real.norm_eq_abs] at this
    have hre := hpath t ht
    rw [Real.norm_eq_abs, abs_le]
    constructor
    · linarith
    · linarith [le_abs_self (diag a (chainApply f u' t x))]
  have hcore := geometry_core ha hPM f u' x hf hu' hx (by positivity) hE hcomp
    (by simpa using hflat)
  have hconst : dConst (d + 1) * (((d + 1 : ℕ) : ℝ) * cPol (d + 1) * M * (d * (2 * ρ)) + E) =
      cConstReal (d + 1) * E := by
    rw [cConstReal]
    have hMρ : M * ρ = E := by rw [hρ]; field_simp
    have e1 : ((d + 1 : ℕ) : ℝ) * cPol (d + 1) * M * (d * (2 * ρ)) =
        2 * ((d + 1 : ℕ) : ℝ) * d * cPol (d + 1) * (M * ρ) := by ring
    rw [e1, hMρ]
    push_cast
    ring
  rw [hconst] at hcore
  have hz := apply_zv (a := a) f u
  have hprod := norm_prod_le_one hf hx
  have hzu : |a (zv f u' x)| ≤ |a u| := by
    rw [hz, abs_mul]
    rw [Real.norm_eq_abs] at hprod
    calc |∏ i, f i (u (Fin.last d))| * |a u| ≤ 1 * |a u| := by gcongr
      _ = |a u| := one_mul _
  rw [Real.norm_eq_abs] at hcore
  have : M - |a (zv f u' x) - M| ≤ |a (zv f u' x)| := by
    have := abs_sub_abs_le_abs_sub M (a (zv f u' x))
    rw [abs_sub_comm M, abs_of_pos hM] at this
    linarith
  simp only [RCLike.ofReal_real_eq_id, id] at hcore
  linarith

end LindenstraussPolynomials
