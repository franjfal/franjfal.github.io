import Mathlib

/-!
# An estimate for nonnegative polynomials (Lemma lem:K)

For every $`n\ge1` there is $`K_n\ge1` such that
$$`\max_{0\le t\le1} r(t) \le K_n\int_0^1 r(t)\,dt`
for every real polynomial $`r` of degree at most $`n` that is nonnegative on $`[0,1]`.

The formal proof minimizes $`\int_0^1|r|` over the unit sphere of the coefficient space, which is compact; the article argues by contradiction with Vandermonde interpolation. Both prove the same statement.
-/

noncomputable section

open scoped BigOperators
open Finset

namespace LindenstraussPolynomials

/-- Evaluation of the polynomial with coefficient vector {lit}`c`. -/
def evalc {n : ℕ} (c : Fin (n + 1) → ℝ) (t : ℝ) : ℝ := ∑ k : Fin (n + 1), c k * t ^ (k : ℕ)

lemma continuous_evalc_uncurry (n : ℕ) :
    Continuous (Function.uncurry fun (c : Fin (n + 1) → ℝ) (t : ℝ) => |evalc c t|) := by
  unfold evalc
  apply Continuous.abs
  apply continuous_finsetSum
  intro k _
  exact ((continuous_apply k).comp continuous_fst).mul (continuous_snd.pow _)

/-- {lit}`Φ(c) = ∫₀¹ |∑ c_k t^k| dt`. -/
def Phi {n : ℕ} (c : Fin (n + 1) → ℝ) : ℝ := ∫ t in (0 : ℝ)..1, |evalc c t|

lemma continuous_Phi (n : ℕ) : Continuous (Phi (n := n)) :=
  intervalIntegral.continuous_parametric_intervalIntegral_of_continuous'
    (continuous_evalc_uncurry n) 0 1

lemma evalc_smul {n : ℕ} (a : ℝ) (c : Fin (n + 1) → ℝ) (t : ℝ) :
    evalc (a • c) t = a * evalc c t := by
  simp [evalc, Finset.mul_sum, mul_assoc]

lemma Phi_smul {n : ℕ} (a : ℝ) (c : Fin (n + 1) → ℝ) : Phi (a • c) = |a| * Phi c := by
  simp only [Phi, evalc_smul, abs_mul]
  exact intervalIntegral.integral_const_mul _ _

lemma Phi_nonneg {n : ℕ} (c : Fin (n + 1) → ℝ) : 0 ≤ Phi c :=
  intervalIntegral.integral_nonneg zero_le_one (fun _ _ => abs_nonneg _)

lemma Phi_pos {n : ℕ} {c : Fin (n + 1) → ℝ} (hc : c ≠ 0) : 0 < Phi c := by
  by_contra hle
  push Not at hle
  have hzero : ∀ t ∈ Set.Icc (0 : ℝ) 1, evalc c t = 0 := by
    intro t ht
    by_contra hne
    have hcont : Continuous fun t => |evalc c t| :=
      (continuous_evalc_uncurry n).comp (Continuous.prodMk continuous_const continuous_id)
    have := intervalIntegral.integral_pos (a := 0) (b := 1) zero_lt_one hcont.continuousOn
      (fun _ _ => abs_nonneg _) ⟨t, ht, abs_pos.mpr hne⟩
    exact absurd hle (not_le.mpr this)
  set p : Polynomial ℝ := ∑ k : Fin (n + 1), Polynomial.C (c k) * Polynomial.X ^ (k : ℕ)
  have hp_eval : ∀ t, p.eval t = evalc c t := by
    intro t; simp [p, evalc, Polynomial.eval_finsetSum]
  have hp0 : p = 0 := by
    apply Polynomial.eq_zero_of_infinite_isRoot
    apply Set.Infinite.mono (s := Set.Icc (0 : ℝ) 1)
    · intro t ht
      simp only [Set.mem_ofPred_eq, Polynomial.IsRoot, hp_eval]
      exact hzero t ht
    · exact Set.Icc_infinite zero_lt_one
  apply hc
  funext j
  have hcoeff : p.coeff j = c j := by
    simp only [p, Polynomial.finsetSum_coeff, Polynomial.coeff_C_mul_X_pow]
    rw [Finset.sum_eq_single j]
    · simp
    · intro k _ hkj
      rw [ite_eq_right]
      intro h
      exact hkj (Fin.ext h.symm)
    · simp
  rw [← hcoeff, hp0]
  simp

/-- **Lemma {lit}`lem:K`.** For every {lit}`n` there is {lit}`K ≥ 1` such that
{lit}`max_{0 ≤ t ≤ 1} r(t) ≤ K ∫₀¹ r(t) dt` for every real polynomial {lit}`r` of degree at most {lit}`n`
which is nonnegative on {lit}`[0,1]`. -/
theorem lemmaK (n : ℕ) : ∃ K : ℝ, 1 ≤ K ∧ ∀ r : Polynomial ℝ, r.natDegree ≤ n →
    (∀ t ∈ Set.Icc (0 : ℝ) 1, 0 ≤ r.eval t) →
    ∀ t ∈ Set.Icc (0 : ℝ) 1, r.eval t ≤ K * ∫ s in (0 : ℝ)..1, r.eval s := by
  have hS : IsCompact (Metric.sphere (0 : Fin (n + 1) → ℝ) 1) := isCompact_sphere 0 1
  have hne : (Metric.sphere (0 : Fin (n + 1) → ℝ) 1).Nonempty := by
    refine ⟨fun _ => 1, ?_⟩
    rw [mem_sphere_zero_iff_norm, pi_norm_const]
    simp
  obtain ⟨c0, hc0S, hmin⟩ := hS.exists_isMinOn hne (continuous_Phi n).continuousOn
  have hc0 : c0 ≠ 0 := by
    intro h; rw [h] at hc0S; simp at hc0S
  set m := Phi c0 with hm
  have hmpos : 0 < m := Phi_pos hc0
  refine ⟨max 1 ((n + 1) / m), le_max_left _ _, ?_⟩
  intro r hr hnonneg t ht
  set c : Fin (n + 1) → ℝ := fun k => r.coeff k
  have heval : ∀ s, r.eval s = evalc c s := by
    intro s
    rw [Polynomial.eval_eq_sum_range' (n := n + 1) (by omega), ← Fin.sum_univ_eq_sum_range]
    rfl
  have hint_nonneg : 0 ≤ ∫ s in (0 : ℝ)..1, r.eval s :=
    intervalIntegral.integral_nonneg zero_le_one hnonneg
  by_cases hc : c = 0
  · have : r.eval t = 0 := by rw [heval]; simp [evalc, hc]
    rw [this]
    exact mul_nonneg (le_trans zero_le_one (le_max_left _ _)) hint_nonneg
  · have hcpos : 0 < ‖c‖ := norm_pos_iff.mpr hc
    -- the integral equals `Φ(c) ≥ ‖c‖ m`
    have hint : (∫ s in (0 : ℝ)..1, r.eval s) = Phi c := by
      unfold Phi
      refine intervalIntegral.integral_congr fun s hs => ?_
      rw [Set.uIcc_of_le zero_le_one] at hs
      rw [← heval, abs_of_nonneg (hnonneg s hs)]
    have hPhi : ‖c‖ * m ≤ Phi c := by
      have hunit : ‖c‖⁻¹ • c ∈ Metric.sphere (0 : Fin (n + 1) → ℝ) 1 := by
        rw [mem_sphere_zero_iff_norm, norm_smul, norm_inv, norm_norm,
          inv_mul_cancel₀ hcpos.ne']
      have h1 : Phi c0 ≤ Phi (‖c‖⁻¹ • c) := hmin hunit
      rw [Phi_smul, abs_inv, abs_norm] at h1
      rw [← hm] at h1
      have := mul_le_mul_of_nonneg_left h1 hcpos.le
      rwa [← mul_assoc, mul_inv_cancel₀ hcpos.ne', one_mul] at this
    -- pointwise bound `r(t) ≤ (n+1) ‖c‖`
    have hpt : r.eval t ≤ (n + 1) * ‖c‖ := by
      rw [heval]
      calc evalc c t ≤ |evalc c t| := le_abs_self _
        _ ≤ ∑ k : Fin (n + 1), |c k * t ^ (k : ℕ)| := Finset.abs_sum_le_sum_abs _ _
        _ ≤ ∑ _k : Fin (n + 1), ‖c‖ := by
            gcongr with k
            rw [abs_mul, abs_pow, abs_of_nonneg ht.1]
            calc |c k| * t ^ (k : ℕ) ≤ |c k| * 1 := by
                  gcongr
                  exact pow_le_one₀ ht.1 ht.2
              _ = ‖c k‖ := by rw [mul_one, Real.norm_eq_abs]
              _ ≤ ‖c‖ := norm_le_pi_norm c k
        _ = (n + 1) * ‖c‖ := by simp
    calc r.eval t ≤ (n + 1) * ‖c‖ := hpt
      _ = ((n + 1) / m) * (‖c‖ * m) := by field_simp
      _ ≤ ((n + 1) / m) * Phi c := by gcongr
      _ ≤ max 1 ((n + 1) / m) * Phi c := by
          gcongr
          · exact Phi_nonneg c
          · exact le_max_right _ _
      _ = max 1 ((n + 1) / m) * ∫ s in (0 : ℝ)..1, r.eval s := by rw [hint]

end LindenstraussPolynomials
