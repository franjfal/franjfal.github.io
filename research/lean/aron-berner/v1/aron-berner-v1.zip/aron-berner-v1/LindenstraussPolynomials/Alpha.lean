import Mathlib

/-!
# The step sizes

The perturbations of the construction use the step sizes $`\alpha_k=a^{2^k}` for a fixed $`a\in(0,1)`, so that $`\alpha_{k+1}=\alpha_k^2`; this identity is used essentially in the inductive step. The module proves the tail estimates ({lit}`eq:tails`) and the product estimate ({lit}`eq:product`). Indices start at $`0`: $`\alpha_0=a` is the article's $`\alpha_1`.
-/

noncomputable section

open scoped BigOperators Topology
open Finset Filter

namespace LindenstraussPolynomials

/-- {lit}`α_k = a^{2^k}`. -/
def alpha (a : ℝ) (k : ℕ) : ℝ := a ^ (2 ^ k)

variable {a : ℝ}

lemma alpha_zero (a : ℝ) : alpha a 0 = a := by simp [alpha]

lemma alpha_pos (ha : 0 < a) (k : ℕ) : 0 < alpha a k := pow_pos ha _

lemma alpha_succ (a : ℝ) (k : ℕ) : alpha a (k + 1) = alpha a k ^ 2 := by
  simp only [alpha, pow_succ, pow_mul]

lemma alpha_le (ha0 : 0 ≤ a) (ha1 : a ≤ 1) (k : ℕ) : alpha a k ≤ a := by
  unfold alpha
  calc a ^ (2 ^ k) ≤ a ^ 1 := pow_le_pow_of_le_one ha0 ha1 (Nat.one_le_two_pow)
    _ = a := pow_one a

lemma alpha_anti (ha0 : 0 ≤ a) (ha1 : a ≤ 1) {k m : ℕ} (hkm : k ≤ m) :
    alpha a m ≤ alpha a k :=
  pow_le_pow_of_le_one ha0 ha1 (Nat.pow_le_pow_right (by norm_num) hkm)

lemma alpha_add_le (ha0 : 0 ≤ a) (ha1 : a ≤ 1) (k i : ℕ) :
    alpha a (k + i) ≤ alpha a k ^ (i + 1) := by
  unfold alpha
  rw [pow_add, pow_mul]
  exact pow_le_pow_of_le_one (pow_nonneg ha0 _) (pow_le_one₀ ha0 ha1)
    (Nat.lt_two_pow_self (n := i))

lemma tendsto_alpha (ha0 : 0 ≤ a) (ha1 : a < 1) : Tendsto (alpha a) atTop (𝓝 0) := by
  have h : Tendsto (fun k : ℕ => a ^ (k + 1)) atTop (𝓝 0) :=
    (tendsto_pow_atTop_nhds_zero_of_lt_one ha0 ha1).comp (tendsto_add_atTop_nat 1)
  apply squeeze_zero (fun k => (pow_pos' ha0 k)) _ h
  intro k
  have := alpha_add_le ha0 ha1.le 0 k
  simpa [alpha_zero] using this
where
  pow_pos' (ha0 : 0 ≤ a) (k : ℕ) : 0 ≤ alpha a k := pow_nonneg ha0 _

lemma geom_bound {x : ℝ} (hx0 : 0 ≤ x) (hx : x ≤ 1 / 2) (N : ℕ) :
    ∑ i ∈ range N, x ^ (i + 1) ≤ 2 * x - 2 * x ^ (N + 1) := by
  induction N with
  | zero => simp
  | succ N ih =>
    rw [Finset.sum_range_succ]
    have : 2 * x ^ (N + 2) ≤ x ^ (N + 1) := by
      rw [pow_succ]
      nlinarith [pow_nonneg hx0 (N + 1)]
    linarith

/-- {lit}`∑_{h ≥ k} α_h ≤ 2 α_k` (finite version of {lit}`eq:tails`). -/
lemma sum_alpha_le (ha0 : 0 ≤ a) (ha1 : a ≤ 1 / 2) (k N : ℕ) :
    ∑ i ∈ range N, alpha a (k + i) ≤ 2 * alpha a k := by
  have hk0 : 0 ≤ alpha a k := pow_nonneg ha0 _
  have hk1 : alpha a k ≤ 1 / 2 := (alpha_le ha0 (by linarith) k).trans ha1
  calc ∑ i ∈ range N, alpha a (k + i) ≤ ∑ i ∈ range N, alpha a k ^ (i + 1) :=
        Finset.sum_le_sum fun i _ => alpha_add_le ha0 (by linarith) k i
    _ ≤ 2 * alpha a k - 2 * alpha a k ^ (N + 1) := geom_bound hk0 hk1 N
    _ ≤ 2 * alpha a k := by nlinarith [pow_nonneg hk0 (N + 1)]

/-- {lit}`∑_{h ≥ k} α_h² ≤ 2 α_k²` (finite version of {lit}`eq:tails`). -/
lemma sum_alpha_sq_le (ha0 : 0 ≤ a) (ha1 : a ≤ 1 / 2) (k N : ℕ) :
    ∑ i ∈ range N, alpha a (k + i) ^ 2 ≤ 2 * alpha a k ^ 2 := by
  have h := sum_alpha_le ha0 ha1 (k + 1) N
  rw [alpha_succ] at h
  calc ∑ i ∈ range N, alpha a (k + i) ^ 2 = ∑ i ∈ range N, alpha a (k + 1 + i) := by
        refine Finset.sum_congr rfl fun i _ => ?_
        rw [← alpha_succ]; congr 1; ring
    _ ≤ 2 * alpha a k ^ 2 := h

/-- {lit}`(1-a) ∏_{h<k} (1 + α_h) = 1 - α_k` (proof of {lit}`eq:product`). -/
lemma prod_one_add_alpha (a : ℝ) (k : ℕ) :
    (1 - a) * ∏ h ∈ range k, (1 + alpha a h) = 1 - alpha a k := by
  induction k with
  | zero => simp [alpha_zero]
  | succ k ih =>
    rw [Finset.prod_range_succ, ← mul_assoc, ih, alpha_succ]
    ring

end LindenstraussPolynomials
