import LindenstraussPolynomials.Deficit

/-!
# Control of ordered compositions

Iterating the deficit identity controls the deficits along ordered compositions of substitutions ({lit}`eq:vbase`, {lit}`eq:vcompositions`), with a bound $`(7K_n)^d\alpha_{i_1}` and a scalar that does not depend on the parameters $`t_i` — which is what Lemma {lit}`lem:geometry` needs.
-/

noncomputable section

open scoped BigOperators Topology
open Finset Filter

namespace LindenstraussPolynomials

variable {𝕜 : Type*} [RCLike 𝕜]
variable {X : Type*} [NormedAddCommGroup X] [NormedSpace 𝕜 X]
variable {Y : Type*} [NormedAddCommGroup Y] [NormedSpace 𝕜 Y]
variable {d : ℕ}
variable {A : MLin 𝕜 X Y (d + 1)} {a : ℝ}

lemma nextG_eq (k : ℕ) (g : StrongDual 𝕜 Y) :
    nextG A a k g = g (seqw A a k) • seqg A a k := rfl

lemma norm_apply_seqw_le (k : ℕ) {g : StrongDual 𝕜 Y} (hg : ‖g‖ ≤ 1) :
    ‖g (seqw A a k)‖ ≤ 1 :=
  (g.le_opNorm _).trans (by
    have := norm_seqw_le (A := A) (a := a) k
    nlinarith [norm_nonneg g, norm_nonneg (seqw A a k)])

lemma norm_smul_seqg_le [Nontrivial X] (ha : 0 < a) (k : ℕ) {c : 𝕜} (hc : ‖c‖ ≤ 1) :
    ‖c • seqg A a k‖ ≤ 1 := by
  rw [norm_smul]
  have := norm_seqg (A := A) ha k
  nlinarith [norm_nonneg c, norm_nonneg (seqg A a k)]

/-- {lit}`d_ℓ^{y_ℓ^*}(x_ℓ) ≤ α_ℓ²`. -/
lemma defc_self [Nontrivial X] (ha : 0 < a) (ℓ : ℕ) :
    defc A a ℓ (seqg A a ℓ) (seqx A a ℓ) ≤ alpha a ℓ ^ 2 := by
  have hg := (seq_good (A := A) ha ℓ)
  unfold defc
  rw [show seqg A a ℓ = (seqT A a ℓ).2.2 from rfl, show seqx A a ℓ = (seqT A a ℓ).1 from rfl,
    hg.g_P, RCLike.ofReal_re]
  have := hg.near
  unfold seqM
  linarith

/-- {lit}`eq:vbase`: {lit}`d_k^{y_ℓ^*}(x_ℓ) ≤ 5 α_k²` for {lit}`k ≤ ℓ`. -/
lemma defc_base [Nontrivial X] (ha : 0 < a) (ha8 : a < 1 / 8) {k ℓ : ℕ} (hkl : k ≤ ℓ) :
    defc A a k (seqg A a ℓ) (seqx A a ℓ) ≤ 5 * alpha a k ^ 2 := by
  obtain ⟨N, rfl⟩ := Nat.exists_eq_add_of_le hkl
  have h1 := defc_backward_iter (A := A) ha (by linarith) k N (norm_seqg (A := A) ha (k + N))
    (norm_seqx (A := A) ha (k + N)).le
  have h2 := defc_self (A := A) ha (k + N)
  have h3 := alpha_anti ha.le (by linarith) (Nat.le_add_right k N)
  have h4 := alpha_pos ha (k + N)
  nlinarith

/-- The claim {lit}`eq:vcompositions`, for chains {lit}`ι 0 < ⋯ < ι D < ℓ`. -/
theorem defc_chain [Nontrivial X] (ha : 0 < a) (ha8 : a < 1 / 8) (ℓ : ℕ) :
    ∀ (D : ℕ) (ι : Fin (D + 1) → ℕ), StrictMono ι → (∀ i, ι i < ℓ) →
      ∃ c : 𝕜, ‖c‖ ≤ 1 ∧ ∀ t : Fin (D + 1) → ℝ, (∀ i, t i ∈ Set.Icc (0 : ℝ) 1) →
        defc A a (ι 0) (c • seqg A a (ι 0))
          (chainApply (fun i => seqf A a (ι i)) (fun i => seqx A a (ι i)) t (seqx A a ℓ)) ≤
          (7 * Kc (d + 1)) ^ (D + 1) * alpha a (ι 0)
  | 0, ι, hι, hℓ => by
    set i := ι 0
    refine ⟨seqg A a ℓ (seqw A a i), norm_apply_seqw_le i (norm_seqg (A := A) ha ℓ), ?_⟩
    intro t ht
    rw [chainApply_succ, chainApply_zero, ← nextG_eq]
    have h1 := defc_insert (A := A) ha i (norm_seqg (A := A) ha ℓ) (norm_seqx (A := A) ha ℓ).le (ht 0)
    have h2 : defc A a (i + 1) (seqg A a ℓ) (seqx A a ℓ) ≤ 5 * (alpha a i ^ 2) ^ 2 := by
      have := defc_base (A := A) ha ha8 (Nat.succ_le_of_lt (hℓ 0))
      rwa [alpha_succ] at this
    have h3 := lam_le (A := A) ha (by linarith) i
    have hα := alpha_pos ha i
    have hα1 := alpha_le ha.le (by linarith) i
    have hK := one_le_Kc (d + 1)
    have h5 : (alpha a i ^ 2) ^ 2 ≤ alpha a i ^ 2 := by
      have : alpha a i ^ 2 ≤ 1 := by nlinarith
      nlinarith
    have hB : defc A a (i + 1) (seqg A a ℓ) (seqx A a ℓ) + lam A a i ≤ 7 * alpha a i ^ 2 := by
      linarith
    calc _ ≤ Kc (d + 1) / alpha a i *
          (defc A a (i + 1) (seqg A a ℓ) (seqx A a ℓ) + lam A a i) := h1
      _ ≤ Kc (d + 1) / alpha a i * (7 * alpha a i ^ 2) :=
          mul_le_mul_of_nonneg_left hB (div_nonneg (by linarith) hα.le)
      _ = (7 * Kc (d + 1)) ^ (0 + 1) * alpha a i := by field_simp; ring
  | D + 1, ι, hι, hℓ => by
    have hι' : StrictMono (Fin.tail ι) := hι.comp (Fin.strictMono_succ)
    obtain ⟨c', hc', hbound⟩ := defc_chain ha ha8 ℓ D (Fin.tail ι) hι' (fun i => hℓ _)
    set j := ι 0
    set k := ι 1
    have hjk : j < k := hι (show (0 : Fin (D + 2)) < 1 from Fin.zero_lt_one)
    set g := c' • seqg A a k with hgdef
    have hg : ‖g‖ ≤ 1 := norm_smul_seqg_le ha k hc'
    refine ⟨g (seqw A a j), norm_apply_seqw_le j hg, ?_⟩
    intro t ht
    rw [chainApply_succ, ← nextG_eq]
    set y := chainApply (Fin.tail fun i => seqf A a (ι i)) (Fin.tail fun i => seqx A a (ι i))
      (Fin.tail t) (seqx A a ℓ) with hydef
    have hy : ‖y‖ ≤ 1 :=
      (norm_chainApply_le _ _ _ (fun i => (norm_seqf ha _).le) (fun i => (norm_seqx ha _).le)
        (fun i => ht _) _).trans (norm_seqx (A := A) ha ℓ).le
    have hyb : defc A a k g y ≤ (7 * Kc (d + 1)) ^ (D + 1) * alpha a k :=
      hbound (Fin.tail t) (fun i => ht _)
    set C := (7 * Kc (d + 1)) ^ (D + 1) with hC
    have hK := one_le_Kc (d + 1)
    have hC1 : 1 ≤ C := one_le_pow₀ (by linarith)
    have hα := alpha_pos ha j
    have hα1 := alpha_le ha.le (by linarith) j
    -- backward from `k` to `j + 1`
    obtain ⟨N, hN⟩ := Nat.exists_eq_add_of_le (Nat.succ_le_of_lt hjk)
    have hback := defc_backward_iter (A := A) ha (by linarith) (j + 1) N hg hy
    rw [← hN] at hback
    have hαk : alpha a k ≤ alpha a j ^ 2 := by
      rw [← alpha_succ]; exact alpha_anti ha.le (by linarith) (Nat.succ_le_of_lt hjk)
    rw [alpha_succ] at hback
    have h1 := defc_insert (A := A) ha j hg hy (ht 0)
    have h3 := lam_le (A := A) ha (by linarith) j
    have hB : defc A a (j + 1) g y + lam A a j ≤
        C * alpha a j ^ 2 + 4 * alpha a j ^ 4 + 2 * alpha a j ^ 2 := by
      have : C * alpha a k ≤ C * alpha a j ^ 2 := mul_le_mul_of_nonneg_left hαk (by linarith)
      have : (alpha a j ^ 2) ^ 2 = alpha a j ^ 4 := by ring
      linarith
    have hα3 : alpha a j ^ 3 ≤ alpha a j := by
      have : alpha a j ^ 2 ≤ 1 := by nlinarith
      nlinarith
    calc _ ≤ Kc (d + 1) / alpha a j * (defc A a (j + 1) g y + lam A a j) := h1
      _ ≤ Kc (d + 1) / alpha a j * (C * alpha a j ^ 2 + 4 * alpha a j ^ 4 + 2 * alpha a j ^ 2) :=
          mul_le_mul_of_nonneg_left hB (div_nonneg (by linarith) hα.le)
      _ = Kc (d + 1) * (C * alpha a j + 4 * alpha a j ^ 3 + 2 * alpha a j) := by
          field_simp
      _ ≤ Kc (d + 1) * (7 * C * alpha a j) := by
          apply mul_le_mul_of_nonneg_left _ (by linarith)
          nlinarith
      _ = (7 * Kc (d + 1)) ^ (D + 1 + 1) * alpha a j := by rw [pow_succ, hC]; ring

end LindenstraussPolynomials
