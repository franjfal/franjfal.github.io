import LindenstraussPolynomials.Basic

/-!
# Polarization

The identities of Section 1 of the article that recover the symmetric form $`\check P` from the polynomial $`P`:

* the finite-difference polarization formula ({lit}`eq:finitepolar`) and the sign polarization formula ({lit}`eq:signpolar`);
* the estimate $`\|P\|\le\|\check P\|\le c_n\|P\|` with $`c_n=n^n/n!` ({lit}`eq:polarnorm`);
* the uniqueness of the symmetric form with a given diagonal;
* the Lipschitz estimate $`|P(x)-P(y)|\le n c_n\|P\|\,\|x-y\|` on the unit ball ({lit}`eq:lipschitz`).
-/

noncomputable section

open scoped BigOperators
open Finset

namespace LindenstraussPolynomials

variable {𝕜 : Type*} [RCLike 𝕜]
variable {X : Type*} [NormedAddCommGroup X] [NormedSpace 𝕜 X]
variable {Y : Type*} [NormedAddCommGroup Y] [NormedSpace 𝕜 Y]

/-- The polarization constant {lit}`c_n = n^n / n!`. -/
def cPol (n : ℕ) : ℝ := (n : ℝ) ^ n / n.factorial

lemma cPol_nonneg (n : ℕ) : 0 ≤ cPol n := by unfold cPol; positivity

lemma one_le_cPol (n : ℕ) : 1 ≤ cPol n := by
  unfold cPol
  rw [le_div_iff₀ (by exact_mod_cast Nat.factorial_pos n), one_mul]
  exact_mod_cast Nat.factorial_le_pow n

variable {n : ℕ}

/-- Expansion of {lit}`A (∑ cⱼ vⱼ, …, ∑ cⱼ vⱼ)`. -/
lemma map_diag_sum_smul {m : ℕ} (A : MLin 𝕜 X Y n) (c : Fin m → 𝕜) (v : Fin m → X) :
    A (fun _ => ∑ j, c j • v j) = ∑ g : Fin n → Fin m, (∏ i, c (g i)) • A (v ∘ g) := by
  change A.toMultilinearMap (fun i => ∑ j, (fun (_ : Fin n) j => c j • v j) i j) = _
  rw [MultilinearMap.map_sum]
  refine Finset.sum_congr rfl fun g _ => ?_
  exact A.map_smul_univ (fun i => c (g i)) (fun i => v (g i))

lemma sum_superset_neg_one_pow (S : Finset (Fin n)) :
    (∑ F : Finset (Fin n), if S ⊆ F then ((-1 : 𝕜) ^ (n - F.card)) else 0) =
      if S = univ then 1 else 0 := by
  classical
  have h1 : (∑ F : Finset (Fin n), if S ⊆ F then ((-1 : 𝕜) ^ (n - F.card)) else 0) =
      ∑ T : Finset (Fin n), if T ⊆ Sᶜ then ((-1 : 𝕜) ^ T.card) else 0 := by
    refine Fintype.sum_equiv (Equiv.mk (fun F => Fᶜ) (fun T => Tᶜ) (fun F => by simp)
      (fun T => by simp)) _ _ (fun F => ?_)
    simp only [Equiv.coe_fn_mk]
    simp only [Finset.compl_subset_compl, Finset.card_compl, Fintype.card_fin]
  rw [h1, ← Finset.sum_filter]
  have h2 : (univ.filter fun T : Finset (Fin n) => T ⊆ Sᶜ) = (Sᶜ).powerset := by
    ext T; simp
  rw [h2]
  have h3 := Finset.sum_powerset_neg_one_pow_card (x := Sᶜ)
  have h4 : (∑ m ∈ (Sᶜ).powerset, (-1 : 𝕜) ^ m.card) =
      ((∑ m ∈ (Sᶜ).powerset, (-1 : ℤ) ^ m.card : ℤ) : 𝕜) := by push_cast; rfl
  rw [h4, h3]
  have : (Sᶜ = ∅) ↔ S = univ := by
    constructor
    · intro h; simpa using congrArg (fun T => Tᶜ) h
    · intro h; simp [h]
  by_cases hS : S = univ
  · simp [hS]
  · simp [hS, this.not.mpr hS]

/-- Sum over all maps {lit}`g : Fin n → Fin n` restricted to bijective ones is a sum over
permutations. -/
lemma sum_bijective_eq_sum_perm (F : (Fin n → Fin n) → Y) :
    (∑ g : Fin n → Fin n, if Function.Bijective g then F g else 0) =
      ∑ σ : Equiv.Perm (Fin n), F σ := by
  classical
  rw [← Finset.sum_filter]
  symm
  refine Finset.sum_nbij' (fun σ => ⇑σ)
    (fun g => if h : Function.Bijective g then Equiv.ofBijective g h else 1) ?_ ?_ ?_ ?_ ?_
  · intro σ _; exact Finset.mem_filter.mpr ⟨Finset.mem_univ _, σ.bijective⟩
  · intro g _; exact Finset.mem_univ _
  · intro σ _
    rw [dite_eq_left σ.bijective]
    exact Equiv.ext fun _ => rfl
  · intro g hg
    have hg' : Function.Bijective g := (Finset.mem_filter.mp hg).2
    rw [dite_eq_left hg']
    rfl
  · intro σ _; rfl

lemma sum_perm_symm {A : MLin 𝕜 X Y n} (hA : IsSymm A) (v : Fin n → X) :
    (∑ σ : Equiv.Perm (Fin n), A (v ∘ σ)) = (n.factorial : 𝕜) • A v := by
  simp only [hA _ v, Finset.sum_const, Finset.card_univ, Fintype.card_perm, Fintype.card_fin]
  rw [Nat.cast_smul_eq_nsmul]

/-- The finite polarization formula ({lit}`eq:finitepolar`):
{lit}`n! A(v₁,…,vₙ) = ∑_{F ⊆ {1,…,n}} (-1)^{n-|F|} P(∑_{j ∈ F} vⱼ)`. -/
theorem finite_polarization {A : MLin 𝕜 X Y n} (hA : IsSymm A) (v : Fin n → X) :
    (n.factorial : 𝕜) • A v =
      ∑ F : Finset (Fin n), ((-1 : 𝕜) ^ (n - F.card)) • diag A (∑ j ∈ F, v j) := by
  classical
  have hexp : ∀ F : Finset (Fin n), diag A (∑ j ∈ F, v j) =
      ∑ g : Fin n → Fin n, (if ∀ i, g i ∈ F then (1 : 𝕜) else 0) • A (v ∘ g) := by
    intro F
    have : (∑ j ∈ F, v j) = ∑ j, (if j ∈ F then (1 : 𝕜) else 0) • v j := by
      simp only [ite_smul, one_smul, zero_smul]
      rw [Finset.sum_ite_mem, Finset.univ_inter]
    rw [diag_apply, this, map_diag_sum_smul]
    refine Finset.sum_congr rfl fun g _ => ?_
    rw [Finset.prod_boole]
    simp
  simp_rw [hexp, Finset.smul_sum, smul_smul]
  rw [Finset.sum_comm]
  simp_rw [← Finset.sum_smul]
  have hin : ∀ g : Fin n → Fin n,
      (∑ F : Finset (Fin n), (-1 : 𝕜) ^ (n - F.card) * if ∀ i, g i ∈ F then (1 : 𝕜) else 0) =
        if Function.Bijective g then 1 else 0 := by
    intro g
    have := sum_superset_neg_one_pow (𝕜 := 𝕜) (univ.image g)
    have e1 : ∀ F : Finset (Fin n), ((-1 : 𝕜) ^ (n - F.card) *
        if ∀ i, g i ∈ F then (1 : 𝕜) else 0) =
          if univ.image g ⊆ F then ((-1 : 𝕜) ^ (n - F.card)) else 0 := by
      intro F
      have : (∀ i, g i ∈ F) ↔ univ.image g ⊆ F := by
        simp [Finset.image_subset_iff]
      by_cases h : ∀ i, g i ∈ F
      · simp [h, this.mp h]
      · simp [h, this.not.mp h]
    simp_rw [e1]
    rw [this]
    have e2 : univ.image g = univ ↔ Function.Bijective g := by
      constructor
      · intro h
        apply Finite.surjective_iff_bijective.mp
        intro j
        have : j ∈ univ.image g := by rw [h]; exact Finset.mem_univ j
        obtain ⟨i, -, hi⟩ := Finset.mem_image.mp this
        exact ⟨i, hi⟩
      · intro h
        exact Finset.eq_univ_of_forall fun j => by
          obtain ⟨i, hi⟩ := h.2 j
          exact Finset.mem_image.mpr ⟨i, Finset.mem_univ _, hi⟩
    by_cases h : Function.Bijective g
    · rw [ite_eq_left h, ite_eq_left (e2.mpr h)]
    · rw [ite_eq_right h, ite_eq_right (e2.not.mpr h)]
  simp_rw [hin, ite_smul, one_smul, zero_smul]
  rw [sum_bijective_eq_sum_perm (fun g => A (v ∘ g)), sum_perm_symm hA]

/-- The sign function {lit}`true ↦ 1`, {lit}`false ↦ -1`. -/
def sgn (b : Bool) : 𝕜 := if b then 1 else -1

lemma sgn_sq (b : Bool) : (sgn b : 𝕜) * sgn b = 1 := by cases b <;> simp [sgn]

lemma sgn_not (b : Bool) : (sgn (!b) : 𝕜) = - sgn b := by cases b <;> simp [sgn]

lemma norm_sgn (b : Bool) : ‖(sgn b : 𝕜)‖ = 1 := by cases b <;> simp [sgn]

lemma sum_sign_inner (g : Fin n → Fin n) :
    (∑ ε : Fin n → Bool, (∏ j, (sgn (ε j) : 𝕜)) * ∏ i, (sgn (ε (g i)) : 𝕜)) =
      if Function.Bijective g then (2 : 𝕜) ^ n else 0 := by
  classical
  by_cases hg : Function.Bijective g
  · rw [ite_eq_left hg]
    have : ∀ ε : Fin n → Bool, (∏ j, (sgn (ε j) : 𝕜)) * ∏ i, (sgn (ε (g i)) : 𝕜) = 1 := by
      intro ε
      have h := Equiv.prod_comp (Equiv.ofBijective g hg) (fun j => (sgn (ε j) : 𝕜))
      simp only [Equiv.ofBijective_apply] at h
      rw [h, ← Finset.prod_mul_distrib]
      exact Finset.prod_eq_one (fun j _ => sgn_sq _)
    simp [this, Finset.card_univ, Fintype.card_bool]
  · rw [ite_eq_right hg]
    have hns : ¬ Function.Surjective g := fun h => hg (Finite.surjective_iff_bijective.mp h)
    simp only [Function.Surjective, not_forall, not_exists] at hns
    obtain ⟨j, hj⟩ := hns
    set F : (Fin n → Bool) → 𝕜 := fun ε => (∏ k, (sgn (ε k) : 𝕜)) * ∏ i, (sgn (ε (g i)) : 𝕜)
    let e : (Fin n → Bool) ≃ (Fin n → Bool) :=
      { toFun := fun ε => Function.update ε j (!ε j)
        invFun := fun ε => Function.update ε j (!ε j)
        left_inv := fun ε => by ext k; by_cases hk : k = j <;> simp [Function.update, hk]
        right_inv := fun ε => by ext k; by_cases hk : k = j <;> simp [Function.update, hk] }
    have hflip : ∀ ε, F (e ε) = - F ε := by
      intro ε
      simp only [F, e, Equiv.coe_fn_mk]
      have h1 : (∏ i, (sgn (Function.update ε j (!ε j) (g i)) : 𝕜)) =
          ∏ i, (sgn (ε (g i)) : 𝕜) := by
        refine Finset.prod_congr rfl fun i _ => ?_
        rw [Function.update_of_ne (hj i)]
      have h2 : (∏ k, (sgn (Function.update ε j (!ε j) k) : 𝕜)) =
          - ∏ k, (sgn (ε k) : 𝕜) := by
        rw [← Finset.mul_prod_erase univ _ (Finset.mem_univ j),
          ← Finset.mul_prod_erase univ (fun k => (sgn (ε k) : 𝕜)) (Finset.mem_univ j)]
        simp only [Function.update_self, sgn_not]
        rw [Finset.prod_congr rfl (fun k hk => by
          rw [Function.update_of_ne (Finset.ne_of_mem_erase hk)])]
        ring
      rw [h1, h2]; ring
    have hsum : (∑ ε, F ε) = - ∑ ε, F ε := by
      conv_lhs => rw [← Equiv.sum_comp e F]
      simp_rw [hflip, Finset.sum_neg_distrib]
    have : (2 : 𝕜) * ∑ ε, F ε = 0 := by linear_combination hsum
    simpa using this

/-- The sign polarization formula ({lit}`eq:signpolar`):
{lit}`2^n n! A(v₁,…,vₙ) = ∑_{ε ∈ {±1}^n} (∏ εⱼ) P(∑ εⱼ vⱼ)`. -/
theorem sign_polarization {A : MLin 𝕜 X Y n} (hA : IsSymm A) (v : Fin n → X) :
    ((2 : 𝕜) ^ n * n.factorial) • A v =
      ∑ ε : Fin n → Bool, (∏ j, (sgn (ε j) : 𝕜)) • diag A (∑ j, (sgn (ε j) : 𝕜) • v j) := by
  classical
  simp_rw [diag_apply, map_diag_sum_smul, Finset.smul_sum, smul_smul]
  rw [Finset.sum_comm]
  simp_rw [← Finset.sum_smul, sum_sign_inner, ite_smul, zero_smul]
  rw [sum_bijective_eq_sum_perm (fun g => ((2 : 𝕜) ^ n) • A (v ∘ g)), ← Finset.smul_sum,
    sum_perm_symm hA, smul_smul]

/-- Passing from a bound on the unit ball to the operator norm. -/
lemma opNorm_le_of_ball {m : ℕ} (A : MLin 𝕜 X Y m) {C : ℝ} (hC : 0 ≤ C)
    (h : ∀ v : Fin m → X, (∀ i, ‖v i‖ ≤ 1) → ‖A v‖ ≤ C) : ‖A‖ ≤ C := by
  refine ContinuousMultilinearMap.opNorm_le_bound hC fun v => ?_
  by_cases hv : ∃ i, v i = 0
  · obtain ⟨i, hi⟩ := hv
    rw [A.map_coord_zero i hi, norm_zero]
    exact mul_nonneg hC (Finset.prod_nonneg fun _ _ => norm_nonneg _)
  · push Not at hv
    have hpos : ∀ i, 0 < ‖v i‖ := fun i => norm_pos_iff.mpr (hv i)
    set w : Fin m → X := fun i => ((‖v i‖⁻¹ : ℝ) : 𝕜) • v i
    have hw : ∀ i, ‖w i‖ ≤ 1 := by
      intro i
      simp only [w, norm_smul, RCLike.norm_ofReal, abs_inv, abs_norm]
      rw [inv_mul_cancel₀ (hpos i).ne']
    have hvw : v = fun i => ((‖v i‖ : ℝ) : 𝕜) • w i := by
      ext i
      simp only [w, smul_smul, ← RCLike.ofReal_mul, mul_inv_cancel₀ (hpos i).ne',
        RCLike.ofReal_one, one_smul]
    have : A v = (∏ i, ((‖v i‖ : ℝ) : 𝕜)) • A w := by
      conv_lhs => rw [hvw]
      exact A.map_smul_univ _ _
    rw [this, norm_smul, norm_prod]
    simp only [RCLike.norm_ofReal, abs_norm]
    rw [mul_comm]
    gcongr
    exact h w hw

/-- The polarization estimate ({lit}`eq:polarnorm`), upper half: {lit}`‖Ǎ‖ ≤ c_n ‖P‖`. -/
theorem opNorm_le_cPol_mul {A : MLin 𝕜 X Y n} (hA : IsSymm A) :
    ‖A‖ ≤ cPol n * polyNorm (diag A) := by
  apply opNorm_le_of_ball A (mul_nonneg (cPol_nonneg n) (polyNorm_nonneg _))
  intro v hv
  have hfac : (0 : ℝ) < 2 ^ n * n.factorial := by positivity
  have key := sign_polarization hA v
  have hAv : A v = (((2 : 𝕜) ^ n * n.factorial))⁻¹ •
      ∑ ε : Fin n → Bool, (∏ j, (sgn (ε j) : 𝕜)) • diag A (∑ j, (sgn (ε j) : 𝕜) • v j) := by
    rw [← key, smul_smul, inv_mul_cancel₀ (by exact_mod_cast hfac.ne'), one_smul]
  have hterm : ∀ ε : Fin n → Bool,
      ‖(∏ j, (sgn (ε j) : 𝕜)) • diag A (∑ j, (sgn (ε j) : 𝕜) • v j)‖ ≤
        polyNorm (diag A) * (n : ℝ) ^ n := by
    intro ε
    rw [norm_smul, norm_prod]
    simp only [norm_sgn, Finset.prod_const_one, one_mul]
    have hsum : ‖∑ j, (sgn (ε j) : 𝕜) • v j‖ ≤ n := by
      calc ‖∑ j, (sgn (ε j) : 𝕜) • v j‖ ≤ ∑ j, ‖(sgn (ε j) : 𝕜) • v j‖ := norm_sum_le _ _
        _ ≤ ∑ _j : Fin n, (1 : ℝ) := by
            gcongr with j
            rw [norm_smul, norm_sgn, one_mul]; exact hv j
        _ = n := by simp
    exact (norm_diag_le A _).trans (mul_le_mul_of_nonneg_left
      (pow_le_pow_left₀ (norm_nonneg _) hsum n) (polyNorm_nonneg _))
  rw [hAv, norm_smul]
  calc ‖(((2 : 𝕜) ^ n * n.factorial))⁻¹‖ *
        ‖∑ ε : Fin n → Bool, (∏ j, (sgn (ε j) : 𝕜)) • diag A (∑ j, (sgn (ε j) : 𝕜) • v j)‖
      ≤ ((2 : ℝ) ^ n * n.factorial)⁻¹ * ∑ _ε : Fin n → Bool, polyNorm (diag A) * (n : ℝ) ^ n := by
        rw [norm_inv, norm_mul, norm_pow]
        simp only [RCLike.norm_ofNat, RCLike.norm_natCast]
        gcongr
        exact (norm_sum_le _ _).trans (Finset.sum_le_sum fun ε _ => hterm ε)
    _ = cPol n * polyNorm (diag A) := by
        simp only [Finset.sum_const, Finset.card_univ, Fintype.card_fun, Fintype.card_bool,
          Fintype.card_fin, nsmul_eq_mul, cPol]
        push_cast
        field_simp

/-- Uniqueness of the symmetric form: a symmetric map with zero diagonal vanishes. -/
theorem eq_zero_of_diag_eq_zero {A : MLin 𝕜 X Y n} (hA : IsSymm A) (h : diag A = 0) :
    A = 0 := by
  ext v
  have key := finite_polarization hA v
  simp only [h, Pi.zero_apply, smul_zero, Finset.sum_const_zero] at key
  have hne : (n.factorial : 𝕜) ≠ 0 := by exact_mod_cast (Nat.factorial_pos n).ne'
  simpa [hne] using key

theorem eq_of_diag_eq {A B : MLin 𝕜 X Y n} (hA : IsSymm A) (hB : IsSymm B)
    (h : diag A = diag B) : A = B := by
  have := eq_zero_of_diag_eq_zero (hA.sub hB) (by rw [diag_sub, h, sub_self])
  exact sub_eq_zero.mp this

/-- The Lipschitz estimate ({lit}`eq:lipschitz`):
{lit}`‖P x - P y‖ ≤ n c_n ‖P‖ ‖x - y‖` for {lit}`x, y` in the unit ball. -/
theorem lipschitz_diag {A : MLin 𝕜 X Y n} (hA : IsSymm A) {x y : X} (hx : ‖x‖ ≤ 1)
    (hy : ‖y‖ ≤ 1) :
    ‖diag A x - diag A y‖ ≤ n * cPol n * polyNorm (diag A) * ‖x - y‖ := by
  have h := A.norm_image_sub_le (fun _ => x) (fun _ => y)
  simp only [Fintype.card_fin] at h
  have hmax : max ‖(fun _ : Fin n => x)‖ ‖(fun _ : Fin n => y)‖ ≤ 1 := by
    apply max_le
    · exact (pi_norm_le_iff_of_nonneg zero_le_one).mpr fun _ => hx
    · exact (pi_norm_le_iff_of_nonneg zero_le_one).mpr fun _ => hy
  have hdiff : ‖(fun _ : Fin n => x) - (fun _ : Fin n => y)‖ ≤ ‖x - y‖ :=
    (pi_norm_le_iff_of_nonneg (norm_nonneg _)).mpr fun _ => le_rfl
  simp only [diag_apply]
  calc ‖A (fun _ => x) - A (fun _ => y)‖
      ≤ ‖A‖ * n * max ‖(fun _ : Fin n => x)‖ ‖(fun _ : Fin n => y)‖ ^ (n - 1) *
          ‖(fun _ : Fin n => x) - (fun _ : Fin n => y)‖ := h
    _ ≤ (cPol n * polyNorm (diag A)) * n * 1 * ‖x - y‖ := by
        have h1 := opNorm_le_cPol_mul hA
        have h2 : max ‖(fun _ : Fin n => x)‖ ‖(fun _ : Fin n => y)‖ ^ (n - 1) ≤ 1 :=
          pow_le_one₀ (le_trans (norm_nonneg _) (le_max_left _ _)) hmax
        have h3 : 0 ≤ cPol n * polyNorm (diag A) :=
          mul_nonneg (cPol_nonneg n) (polyNorm_nonneg _)
        apply mul_le_mul _ hdiff (norm_nonneg _) (by positivity)
        apply mul_le_mul _ h2 (by positivity) (by positivity)
        exact mul_le_mul_of_nonneg_right h1 (Nat.cast_nonneg n)
    _ = n * cPol n * polyNorm (diag A) * ‖x - y‖ := by ring

end LindenstraussPolynomials
