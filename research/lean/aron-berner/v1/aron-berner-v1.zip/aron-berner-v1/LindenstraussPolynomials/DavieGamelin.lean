import LindenstraussPolynomials.Extension

/-!
# Norm preservation (Lemma lem:isometry)

The theorem of Davie and Gamelin: for a symmetric $`n`-linear form $`a` and $`z` in the closed unit ball of $`X^{**}`,
$$`|\overline a(z,\ldots,z)| \le \sup_{\|x\|\le1}|a(x,\ldots,x)|,`
so the canonical extension preserves the norm of a polynomial.

The proof follows Davie and Gamelin: points of the unit ball of $`X` are chosen one at a time, by a finite-dimensional form of Goldstine's theorem, so that every increasing tuple of chosen points approximates the iterated extension; the polynomial is then evaluated at averages of the chosen points. It uses only multilinearity, so it works over $`\mathbb R` as well as over $`\mathbb C`, as the article remarks.
-/

noncomputable section

open scoped BigOperators
open Finset

namespace LindenstraussPolynomials

variable {𝕜 : Type*} [RCLike 𝕜]
variable {X : Type*} [NormedAddCommGroup X] [NormedSpace 𝕜 X]

/-- A bound on the unit ball bounds the norm of a functional. -/
lemma dual_norm_le_of_re_lt (h : StrongDual 𝕜 X) {u : ℝ}
    (hu : ∀ x : X, ‖x‖ ≤ 1 → RCLike.re (h x) < u) : ‖h‖ ≤ u := by
  have hu0 : 0 < u := by simpa using hu 0 (by simp)
  have hball : ∀ x : X, ‖x‖ ≤ 1 → ‖h x‖ ≤ u := by
    intro x hx
    by_cases hhx : h x = 0
    · rw [hhx, norm_zero]; exact hu0.le
    · set c : 𝕜 := (starRingEnd 𝕜) (h x) / ((‖h x‖ : ℝ) : 𝕜) with hc
      have hcn : ‖c‖ = 1 := by
        rw [hc, norm_div, RCLike.norm_conj, RCLike.norm_ofReal, abs_norm,
          div_self (norm_ne_zero_iff.mpr hhx)]
      have hcx : ‖c • x‖ ≤ 1 := by rw [norm_smul, hcn, one_mul]; exact hx
      have hval : h (c • x) = ((‖h x‖ : ℝ) : 𝕜) := by
        rw [map_smul, smul_eq_mul, hc, div_mul_eq_mul_div, RCLike.conj_mul]
        rw [← RCLike.ofReal_pow, sq, RCLike.ofReal_mul, mul_div_assoc,
          div_self (by exact_mod_cast norm_ne_zero_iff.mpr hhx), mul_one]
      have := hu _ hcx
      rw [hval, RCLike.ofReal_re] at this
      exact this.le
  refine ContinuousLinearMap.opNorm_le_bound _ hu0.le fun x => ?_
  by_cases hx0 : x = 0
  · simp [hx0]
  · have hxpos : 0 < ‖x‖ := norm_pos_iff.mpr hx0
    have h1 := hball (((‖x‖⁻¹ : ℝ) : 𝕜) • x) (by
      rw [norm_smul, RCLike.norm_ofReal, abs_inv, abs_norm, inv_mul_cancel₀ hxpos.ne'])
    rw [map_smul, norm_smul, RCLike.norm_ofReal, abs_inv, abs_norm] at h1
    rw [inv_mul_le_iff₀ hxpos] at h1
    linarith

/-- A finite-dimensional form of Goldstine's theorem: for {lit}`z ∈ B_{X**}`, finitely many
functionals {lit}`g ∈ G` and {lit}`η > 0` there is {lit}`x ∈ B_X` with {lit}`|g(x) - z(g)| < η` for {lit}`g ∈ G`. -/
theorem local_goldstine (z : Bidual 𝕜 X) (hz : ‖z‖ ≤ 1) (G : Finset (StrongDual 𝕜 X))
    {η : ℝ} (hη : 0 < η) : ∃ x : X, ‖x‖ ≤ 1 ∧ ∀ g ∈ G, ‖g x - z g‖ < η := by
  classical
  set T : X →L[𝕜] (G → 𝕜) := ContinuousLinearMap.pi (fun g : G => (g : StrongDual 𝕜 X))
  set w : G → 𝕜 := fun g => z g
  set K : Set (G → 𝕜) := closure (T '' Metric.closedBall (0 : X) 1)
  have hKconv : Convex ℝ K := by
    apply Convex.closure
    rintro _ ⟨x, hx, rfl⟩ _ ⟨y, hy, rfl⟩ s t hs ht hst
    refine ⟨((s : ℝ) : 𝕜) • x + ((t : ℝ) : 𝕜) • y, ?_, ?_⟩
    · simp only [Metric.mem_closedBall, dist_zero_right] at hx hy ⊢
      calc ‖((s : ℝ) : 𝕜) • x + ((t : ℝ) : 𝕜) • y‖
          ≤ ‖((s : ℝ) : 𝕜) • x‖ + ‖((t : ℝ) : 𝕜) • y‖ := norm_add_le _ _
        _ = s * ‖x‖ + t * ‖y‖ := by
            rw [norm_smul, norm_smul, RCLike.norm_ofReal, RCLike.norm_ofReal,
              abs_of_nonneg hs, abs_of_nonneg ht]
        _ ≤ s * 1 + t * 1 := by gcongr
        _ = 1 := by linarith
    · rw [map_add, map_smul, map_smul, RCLike.real_smul_eq_coe_smul (K := 𝕜) s,
        RCLike.real_smul_eq_coe_smul (K := 𝕜) t]
  by_cases hw : w ∈ K
  · rw [Metric.mem_closure_iff] at hw
    obtain ⟨_, ⟨x, hx, rfl⟩, hdist⟩ := hw η hη
    refine ⟨x, by simpa using hx, fun g hg => ?_⟩
    have := dist_le_pi_dist w (T x) ⟨g, hg⟩
    rw [dist_comm, dist_eq_norm] at this
    exact lt_of_le_of_lt this hdist
  · exfalso
    obtain ⟨φ, u, hK, hφw⟩ :=
      RCLike.geometric_hahn_banach_closed_point (𝕜 := 𝕜) hKconv isClosed_closure hw
    set e : G → (G → 𝕜) := fun g => Pi.single g (1 : 𝕜)
    set h : StrongDual 𝕜 X := ∑ g : G, φ (e g) • (g : StrongDual 𝕜 X)
    have hdecomp : ∀ v : G → 𝕜, φ v = ∑ g : G, v g * φ (e g) := by
      intro v
      conv_lhs => rw [show v = ∑ g : G, v g • e g by
        ext k; simp [e, Finset.sum_apply, Pi.single_apply]]
      rw [map_sum]
      simp
    have hhx : ∀ x, h x = φ (T x) := by
      intro x
      rw [hdecomp]
      simp [h, T, mul_comm]
    have hzh : z h = φ w := by
      rw [hdecomp]
      simp [h, w, map_sum, mul_comm]
    have hball : ∀ x : X, ‖x‖ ≤ 1 → RCLike.re (h x) < u := by
      intro x hx
      rw [hhx]
      exact hK _ (subset_closure ⟨x, by simpa using hx, rfl⟩)
    have hnorm := dual_norm_le_of_re_lt h hball
    have : RCLike.re (φ w) ≤ ‖h‖ := by
      rw [← hzh]
      calc RCLike.re (z h) ≤ ‖z h‖ := RCLike.re_le_norm _
        _ ≤ ‖z‖ * ‖h‖ := z.le_opNorm h
        _ ≤ 1 * ‖h‖ := by gcongr
        _ = ‖h‖ := one_mul _
    linarith

/-! ## Choosing points one at a time -/

/-- The invariant of the inductive choice of points {lit}`q 0, …, q (m-1)`: at every level, the
form is approximated by its partial extension at increasing tuples of chosen points. -/
def PickInv (z : Bidual 𝕜 X) (ε : ℝ) (q : ℕ → X) (m : ℕ) : ∀ {r : ℕ}, MLin 𝕜 X 𝕜 r → Prop
  | 0, _ => True
  | r + 1, C => PickInv z ε q m (extLast z C) ∧
      ∀ ι : Fin (r + 1) → ℕ, StrictMono ι → (∀ i, ι i < m) →
        ‖C (fun i => q (ι i)) - extLast z C (fun i => q (ι i.castSucc))‖ ≤ ε

lemma pickInv_approx (z : Bidual 𝕜 X) (ε : ℝ) (q : ℕ → X) (m : ℕ) :
    ∀ {r : ℕ} (C : MLin 𝕜 X 𝕜 r), PickInv z ε q m C →
    ∀ ι : Fin r → ℕ, StrictMono ι → (∀ i, ι i < m) →
      ‖C (fun i => q (ι i)) - diagExt z C‖ ≤ r * ε
  | 0, C, _, ι, _, _ => by
    simp only [diagExt_zero, CharP.cast_eq_zero, zero_mul]
    have : (fun i => q (ι i)) = (fun i => Fin.elim0 i) := funext fun i => Fin.elim0 i
    rw [this, sub_self, norm_zero]
  | r + 1, C, hC, ι, hι, hlt => by
    rw [diagExt_succ]
    have h1 := hC.2 ι hι hlt
    have h2 := pickInv_approx z ε q m (extLast z C) hC.1 (fun i => ι i.castSucc)
      (hι.comp Fin.strictMono_castSucc) (fun i => hlt _)
    calc ‖C (fun i => q (ι i)) - diagExt z (extLast z C)‖
        ≤ ‖C (fun i => q (ι i)) - extLast z C (fun i => q (ι i.castSucc))‖ +
          ‖extLast z C (fun i => q (ι i.castSucc)) - diagExt z (extLast z C)‖ := by
          rw [← dist_eq_norm, ← dist_eq_norm, ← dist_eq_norm]; exact dist_triangle _ _ _
      _ ≤ ε + r * ε := add_le_add h1 h2
      _ = ((r + 1 : ℕ) : ℝ) * ε := by push_cast; ring

lemma pickInv_zero (z : Bidual 𝕜 X) (ε : ℝ) (q : ℕ → X) :
    ∀ {r : ℕ} (C : MLin 𝕜 X 𝕜 r), PickInv z ε q 0 C
  | 0, _ => trivial
  | _ + 1, C => ⟨pickInv_zero z ε q (extLast z C), fun _ _ hlt => absurd (hlt 0) (Nat.not_lt_zero _)⟩

lemma pickInv_extend (z : Bidual 𝕜 X) {ε : ℝ} (hε : 0 < ε) (q : ℕ → X) (m : ℕ) :
    ∀ {r : ℕ} (C : MLin 𝕜 X 𝕜 r), PickInv z ε q m C →
    ∃ G : Finset (StrongDual 𝕜 X), ∃ η : ℝ, 0 < η ∧ ∀ x : X,
      (∀ g ∈ G, ‖g x - z g‖ < η) → PickInv z ε (Function.update q m x) (m + 1) C
  | 0, _, _ => ⟨∅, 1, one_pos, fun _ _ => trivial⟩
  | r + 1, C, hC => by
    classical
    obtain ⟨G1, η1, hη1, h1⟩ := pickInv_extend z hε q m (extLast z C) hC.1
    set G2 : Finset (StrongDual 𝕜 X) :=
      univ.image (fun ι' : Fin r → Fin m => C.curryRight (fun i => q (ι' i)))
    refine ⟨G1 ∪ G2, min η1 ε, lt_min hη1 hε, fun x hx => ⟨?_, ?_⟩⟩
    · exact h1 x (fun g hg => lt_of_lt_of_le (hx g (Finset.mem_union_left _ hg))
        (min_le_left _ _))
    · intro ι hι hlt
      by_cases hl : ι (Fin.last r) < m
      · have hall : ∀ i, ι i < m := fun i =>
          lt_of_le_of_lt (hι.monotone (Fin.le_last i)) hl
        have e1 : (fun i => Function.update q m x (ι i)) = fun i => q (ι i) := by
          funext i; rw [Function.update_of_ne (hall i).ne]
        have e2 : (fun i => Function.update q m x (ι (Fin.castSucc i))) =
            fun i => q (ι (Fin.castSucc i)) := by
          funext i; rw [Function.update_of_ne (hall _).ne]
        rw [e1, e2]
        exact hC.2 ι hι hall
      · have hlast : ι (Fin.last r) = m := by
          have := hlt (Fin.last r); omega
        have hinit : ∀ i : Fin r, ι i.castSucc < m := by
          intro i
          rw [← hlast]
          exact hι (Fin.castSucc_lt_last i)
        set v : Fin r → X := fun i => q (ι i.castSucc)
        have e1 : (fun i => Function.update q m x (ι i)) = Fin.snoc v x := by
          funext i
          induction i using Fin.lastCases with
          | last => rw [Fin.snoc_last, hlast, Function.update_self]
          | cast j =>
            rw [Fin.snoc_castSucc, Function.update_of_ne (hinit j).ne]
        have e2 : (fun i => Function.update q m x (ι (Fin.castSucc i))) = v := by
          funext i; rw [Function.update_of_ne (hinit i).ne]
        rw [e1, e2, extLast_apply, ← curryRight_apply']
        have hmem : C.curryRight v ∈ G1 ∪ G2 := by
          apply Finset.mem_union_right
          refine Finset.mem_image.mpr ⟨fun i => ⟨ι i.castSucc, hinit i⟩, Finset.mem_univ _, ?_⟩
          rfl
        exact (lt_of_lt_of_le (hx _ hmem) (min_le_right _ _)).le

lemma exists_pick (z : Bidual 𝕜 X) (hz : ‖z‖ ≤ 1) {ε : ℝ} (hε : 0 < ε) {r : ℕ}
    (C : MLin 𝕜 X 𝕜 r) : ∀ N : ℕ, ∃ q : ℕ → X, (∀ i, ‖q i‖ ≤ 1) ∧ PickInv z ε q N C
  | 0 => ⟨0, fun _ => by simp, pickInv_zero z ε 0 C⟩
  | N + 1 => by
    obtain ⟨q, hq, hinv⟩ := exists_pick z hz hε C N
    obtain ⟨G, η, hη, hG⟩ := pickInv_extend z hε q N C hinv
    obtain ⟨x, hx, hxG⟩ := local_goldstine z hz G hη
    refine ⟨Function.update q N x, fun i => ?_, hG x hxG⟩
    by_cases hi : i = N
    · subst hi; rw [Function.update_self]; exact hx
    · rw [Function.update_of_ne hi]; exact hq i

/-! ## Averaging -/

/-- Number of non-injective maps: {lit}`1 - N^{(n)}/N^n ≤ n²/N` (falling factorial). -/
lemma one_sub_descFactorial_div_le {n N : ℕ} (hN : n ≤ N) (hN0 : 0 < N) :
    1 - (N.descFactorial n : ℝ) / (N : ℝ) ^ n ≤ (n : ℝ) ^ 2 / N := by
  have hNpos : (0 : ℝ) < N := by exact_mod_cast hN0
  have h1 : ((N + 1 - n : ℕ) : ℝ) ^ n ≤ N.descFactorial n := by
    exact_mod_cast Nat.pow_sub_le_descFactorial N n
  have h2 : ((N : ℝ) - n) ≤ ((N + 1 - n : ℕ) : ℝ) := by
    rw [Nat.cast_sub (by omega)]; push_cast; linarith
  have h3 : ((N : ℝ) - n) ^ n ≤ N.descFactorial n :=
    le_trans (pow_le_pow_left₀ (by have : (n : ℝ) ≤ N := by exact_mod_cast hN
                                   linarith) h2 n) h1
  have hbern : 1 + (n : ℝ) * (-(n : ℝ) / N) ≤ (1 + (-(n : ℝ) / N)) ^ n := by
    apply one_add_mul_le_pow
    have : (n : ℝ) / N ≤ 1 := by
      rw [div_le_one hNpos]; exact_mod_cast hN
    have : -(n : ℝ) / N = -((n : ℝ) / N) := by ring
    linarith
  have h4 : (1 + (-(n : ℝ) / N)) ^ n = ((N : ℝ) - n) ^ n / (N : ℝ) ^ n := by
    rw [← div_pow]; congr 1; field_simp; ring
  rw [h4] at hbern
  have h5 : ((N : ℝ) - n) ^ n / (N : ℝ) ^ n ≤ (N.descFactorial n : ℝ) / (N : ℝ) ^ n :=
    div_le_div_of_nonneg_right h3 (by positivity)
  have : (n : ℝ) * (-(n : ℝ) / N) = -((n : ℝ) ^ 2 / N) := by ring
  linarith

variable {n : ℕ}

/-- The key estimate behind Davie–Gamelin: for every {lit}`ε > 0` and {lit}`N ≥ 1`,
{lit}`|ā(z,…,z)| ≤ ‖P‖ + nε + 2‖a‖(1 - N^{(n)}/N^n)`. -/
lemma norm_diagExt_le_aux {a : MLin 𝕜 X 𝕜 n} (ha : IsSymm a) (z : Bidual 𝕜 X) (hz : ‖z‖ ≤ 1)
    {ε : ℝ} (hε : 0 < ε) {N : ℕ} (hN0 : 0 < N) :
    ‖diagExt z a‖ ≤ polyNorm (diag a) + n * ε +
      2 * ‖a‖ * (1 - (N.descFactorial n : ℝ) / (N : ℝ) ^ n) := by
  classical
  obtain ⟨q, hq, hinv⟩ := exists_pick z hz hε a N
  set D := diagExt z a with hD
  have hDle : ‖D‖ ≤ ‖a‖ := by
    have := norm_diagExt_le z a
    calc ‖D‖ ≤ ‖a‖ * ‖z‖ ^ n := this
      _ ≤ ‖a‖ * 1 := by gcongr; exact pow_le_one₀ (norm_nonneg z) hz
      _ = ‖a‖ := mul_one _
  have hNpos : (0 : ℝ) < N := by exact_mod_cast hN0
  set c : 𝕜 := (((N : ℝ)⁻¹ : ℝ) : 𝕜)
  set avg : X := ∑ j : Fin N, c • q j
  have havg : ‖avg‖ ≤ 1 := by
    calc ‖avg‖ ≤ ∑ j : Fin N, ‖c • q j‖ := norm_sum_le _ _
      _ ≤ ∑ _j : Fin N, (N : ℝ)⁻¹ := by
          gcongr with j
          rw [norm_smul, RCLike.norm_ofReal, abs_of_pos (inv_pos.mpr hNpos)]
          calc (N : ℝ)⁻¹ * ‖q j‖ ≤ (N : ℝ)⁻¹ * 1 := by gcongr; exact hq j
            _ = (N : ℝ)⁻¹ := mul_one _
      _ = 1 := by simp [hNpos.ne']
  -- expansion of `P(avg)`
  have hexp : diag a avg = c ^ n • ∑ g : Fin n → Fin N, a (fun i => q (g i)) := by
    rw [diag_apply, map_diag_sum_smul, Finset.smul_sum]
    refine Finset.sum_congr rfl fun g _ => ?_
    rw [Finset.prod_const, Finset.card_univ, Fintype.card_fin]
    rfl
  have hcn : c ^ n * ((N : 𝕜) ^ n) = 1 := by
    rw [← mul_pow]; simp only [c]; push_cast
    rw [inv_mul_cancel₀ (by exact_mod_cast hN0.ne'), one_pow]
  -- termwise bounds
  have hterm : ∀ g : Fin n → Fin N, ‖a (fun i => q (g i)) - D‖ ≤
      if Function.Injective g then n * ε else 2 * ‖a‖ := by
    intro g
    split_ifs with hg
    · set σ := Tuple.sort g
      have hmono : Monotone (g ∘ σ) := Tuple.monotone_sort g
      have hsm : StrictMono (g ∘ σ) := hmono.strictMono_of_injective (hg.comp σ.injective)
      have hsym : a (fun i => q (g i)) = a (fun i => q ((g ∘ σ) i : ℕ)) := by
        rw [← ha σ (fun i => q (g i))]
        rfl
      rw [hsym]
      exact pickInv_approx z ε q N a hinv (fun i => ((g ∘ σ) i : ℕ))
        (Fin.val_strictMono.comp hsm) (fun i => ((g ∘ σ) i).isLt)
    · calc ‖a (fun i => q (g i)) - D‖ ≤ ‖a (fun i => q (g i))‖ + ‖D‖ := norm_sub_le _ _
        _ ≤ ‖a‖ + ‖a‖ := add_le_add (norm_apply_le_of_ball a (fun i => hq _)) hDle
        _ = 2 * ‖a‖ := by ring
  set inj := (univ.filter fun g : Fin n → Fin N => Function.Injective g) with hinj
  have hcard_inj : (inj.card : ℝ) = N.descFactorial n := by
    have h1 : inj.card = Fintype.card {g : Fin n → Fin N // Function.Injective g} :=
      (Fintype.card_subtype _).symm
    rw [h1, Fintype.card_congr (Equiv.subtypeInjectiveEquivEmbedding _ _),
      Fintype.card_embedding_eq, Fintype.card_fin, Fintype.card_fin]
  have hcard_all : ((univ : Finset (Fin n → Fin N)).card : ℝ) = (N : ℝ) ^ n := by
    simp
  have hsplit := Finset.card_filter_add_card_filter_not
    (s := (univ : Finset (Fin n → Fin N))) (fun g => Function.Injective g)
  have hsum_bound : ∑ g : Fin n → Fin N, ‖a (fun i => q (g i)) - D‖ ≤
      (N.descFactorial n : ℝ) * (n * ε) + ((N : ℝ) ^ n - N.descFactorial n) * (2 * ‖a‖) := by
    calc ∑ g : Fin n → Fin N, ‖a (fun i => q (g i)) - D‖
        ≤ ∑ g : Fin n → Fin N, (if Function.Injective g then (n : ℝ) * ε else 2 * ‖a‖) :=
          Finset.sum_le_sum fun g _ => hterm g
      _ = (inj.card : ℝ) * (n * ε) +
            ((univ.filter fun g : Fin n → Fin N => ¬ Function.Injective g).card : ℝ) *
              (2 * ‖a‖) := by
          rw [Finset.sum_ite, Finset.sum_const, Finset.sum_const, nsmul_eq_mul, nsmul_eq_mul]
      _ = (N.descFactorial n : ℝ) * (n * ε) + ((N : ℝ) ^ n - N.descFactorial n) * (2 * ‖a‖) := by
          rw [hcard_inj]
          congr 2
          rw [← hcard_all, ← hcard_inj, ← hsplit]
          push_cast
          ring
  -- the difference `P(avg) - D`
  have hdiff : diag a avg - D = c ^ n • ∑ g : Fin n → Fin N, (a (fun i => q (g i)) - D) := by
    rw [hexp, Finset.sum_sub_distrib, smul_sub]
    congr 1
    rw [Finset.sum_const, Finset.card_univ, Fintype.card_fun, Fintype.card_fin,
      Fintype.card_fin, nsmul_eq_mul, smul_eq_mul, ← mul_assoc]
    push_cast
    rw [hcn, one_mul]
  have hcnorm : ‖c ^ n‖ = ((N : ℝ) ^ n)⁻¹ := by
    rw [norm_pow, RCLike.norm_ofReal, abs_of_pos (inv_pos.mpr hNpos), inv_pow]
  have hdiff_bound : ‖diag a avg - D‖ ≤ n * ε + 2 * ‖a‖ * (1 - (N.descFactorial n : ℝ) / (N : ℝ) ^ n) := by
    rw [hdiff, norm_smul, hcnorm]
    have hNn : (0 : ℝ) < (N : ℝ) ^ n := by positivity
    calc ((N : ℝ) ^ n)⁻¹ * ‖∑ g : Fin n → Fin N, (a (fun i => q (g i)) - D)‖
        ≤ ((N : ℝ) ^ n)⁻¹ * ((N.descFactorial n : ℝ) * (n * ε) +
            ((N : ℝ) ^ n - N.descFactorial n) * (2 * ‖a‖)) := by
          gcongr
          exact (norm_sum_le _ _).trans hsum_bound
      _ ≤ ((N : ℝ) ^ n)⁻¹ * ((N : ℝ) ^ n * (n * ε) +
            ((N : ℝ) ^ n - N.descFactorial n) * (2 * ‖a‖)) := by
          gcongr
          exact_mod_cast Nat.descFactorial_le_pow N n
      _ = n * ε + 2 * ‖a‖ * (1 - (N.descFactorial n : ℝ) / (N : ℝ) ^ n) := by
          field_simp
  have hPavg := norm_diag_le_polyNorm a havg
  calc ‖D‖ ≤ ‖diag a avg‖ + ‖diag a avg - D‖ := by
        have := norm_sub_norm_le (diag a avg) D
        have := norm_sub_rev (diag a avg) D
        linarith [norm_le_insert' D (diag a avg)]
    _ ≤ polyNorm (diag a) + (n * ε + 2 * ‖a‖ * (1 - (N.descFactorial n : ℝ) / (N : ℝ) ^ n)) :=
        add_le_add hPavg hdiff_bound
    _ = _ := by ring

/-- **Davie–Gamelin.** For a symmetric form {lit}`a` and {lit}`z ∈ B_{X**}`,
{lit}`|ā(z,…,z)| ≤ sup_{x ∈ B_X} |a(x,…,x)|`. -/
theorem davie_gamelin {a : MLin 𝕜 X 𝕜 n} (ha : IsSymm a) (z : Bidual 𝕜 X) (hz : ‖z‖ ≤ 1) :
    ‖diagExt z a‖ ≤ polyNorm (diag a) := by
  apply le_of_forall_pos_le_add
  intro δ hδ
  set ε := δ / (2 * (n + 1)) with hε
  have hεpos : 0 < ε := by positivity
  obtain ⟨N, hN⟩ := exists_nat_gt (n + 4 * ‖a‖ * (n : ℝ) ^ 2 / δ)
  have hNn : n ≤ N := by
    have : (n : ℝ) < N := by
      have : 0 ≤ 4 * ‖a‖ * (n : ℝ) ^ 2 / δ := by positivity
      linarith
    exact_mod_cast this.le
  have hN0 : 0 < N := by
    have : (0 : ℝ) < N := by
      have : 0 ≤ 4 * ‖a‖ * (n : ℝ) ^ 2 / δ := by positivity
      have : (0 : ℝ) ≤ n := Nat.cast_nonneg n
      linarith
    exact_mod_cast this
  have hNpos : (0 : ℝ) < N := by exact_mod_cast hN0
  have h1 := norm_diagExt_le_aux ha z hz hεpos hN0
  have h2 := one_sub_descFactorial_div_le hNn hN0
  have h3 : (n : ℝ) * ε ≤ δ / 2 := by
    rw [hε]
    rw [mul_div_assoc']
    rw [div_le_div_iff₀ (by positivity) (by norm_num)]
    nlinarith
  have h4 : 2 * ‖a‖ * ((n : ℝ) ^ 2 / N) ≤ δ / 2 := by
    have hN' : 4 * ‖a‖ * (n : ℝ) ^ 2 / δ < N := by linarith [Nat.cast_nonneg (α := ℝ) n]
    rw [div_lt_iff₀ hδ] at hN'
    rw [mul_div_assoc', div_le_div_iff₀ hNpos (by norm_num)]
    nlinarith
  have h5 : 2 * ‖a‖ * (1 - (N.descFactorial n : ℝ) / (N : ℝ) ^ n) ≤
      2 * ‖a‖ * ((n : ℝ) ^ 2 / N) := by
    gcongr
  linarith

end LindenstraussPolynomials
