import Mathlib

/-!
# Homogeneous polynomials

Throughout, $`\mathbb K` is $`\mathbb R` or $`\mathbb C` (an {lit}`RCLike` field) and $`X`, $`Y` are normed spaces over $`\mathbb K`. A continuous $`n`-homogeneous polynomial $`P\colon X\to Y` is a map of the form $`P(x)=L(x,\ldots,x)` for some continuous $`n`-linear map $`L` ({lit}`IsHomPoly`). Its norm is the supremum over the closed unit ball,
$$`\|P\| = \sup_{\|x\|\le 1}\|P(x)\|`
({lit}`polyNorm`). This module collects the elementary facts about diagonals of multilinear maps and their symmetrizations used everywhere else.
-/

noncomputable section

open scoped BigOperators
open Finset

namespace LindenstraussPolynomials

variable {𝕜 : Type*} [RCLike 𝕜]
variable {X : Type*} [NormedAddCommGroup X] [NormedSpace 𝕜 X]
variable {Y : Type*} [NormedAddCommGroup Y] [NormedSpace 𝕜 Y]

/-- Continuous {lit}`n`-linear maps {lit}`X × ⋯ × X → Y`. -/
abbrev MLin (𝕜 : Type*) [RCLike 𝕜] (X : Type*) [NormedAddCommGroup X] [NormedSpace 𝕜 X]
    (Y : Type*) [NormedAddCommGroup Y] [NormedSpace 𝕜 Y] (n : ℕ) :=
  ContinuousMultilinearMap 𝕜 (fun _ : Fin n => X) Y

/-- The diagonal {lit}`x ↦ A (x, …, x)` of a multilinear map: the associated polynomial. -/
def diag {n : ℕ} (A : MLin 𝕜 X Y n) (x : X) : Y := A (fun _ => x)

/-- A multilinear map is symmetric if it is invariant under permutations of its arguments. -/
def IsSymm {n : ℕ} (A : MLin 𝕜 X Y n) : Prop :=
  ∀ (σ : Equiv.Perm (Fin n)) (v : Fin n → X), A (v ∘ σ) = A v

/-- {lit}`P : X → Y` is a continuous {lit}`n`-homogeneous polynomial: {lit}`P x = L (x, …, x)` for some
continuous {lit}`n`-linear map {lit}`L`. -/
def IsHomPoly (𝕜 : Type*) [RCLike 𝕜] {X : Type*} [NormedAddCommGroup X] [NormedSpace 𝕜 X]
    {Y : Type*} [NormedAddCommGroup Y] [NormedSpace 𝕜 Y] (n : ℕ) (P : X → Y) : Prop :=
  ∃ L : MLin 𝕜 X Y n, ∀ x, P x = L (fun _ => x)

/-- The sup norm over the closed unit ball: {lit}`‖P‖ = sup_{‖x‖ ≤ 1} ‖P x‖`. -/
def polyNorm {E F : Type*} [NormedAddCommGroup E] [NormedAddCommGroup F] (P : E → F) : ℝ :=
  sSup ((fun x => ‖P x‖) '' Metric.closedBall (0 : E) 1)

section polyNorm

variable {E F : Type*} [NormedAddCommGroup E] [NormedAddCommGroup F]

lemma polyNorm_nonneg (P : E → F) : 0 ≤ polyNorm P := by
  apply Real.sSup_nonneg
  rintro _ ⟨x, -, rfl⟩
  exact norm_nonneg _

lemma polyNorm_le {P : E → F} {M : ℝ} (hM0 : 0 ≤ M) (h : ∀ x, ‖x‖ ≤ 1 → ‖P x‖ ≤ M) :
    polyNorm P ≤ M := by
  apply Real.sSup_le _ hM0
  rintro _ ⟨x, hx, rfl⟩
  exact h x (by simpa using hx)

lemma norm_le_polyNorm {P : E → F} {M : ℝ} (h : ∀ x, ‖x‖ ≤ 1 → ‖P x‖ ≤ M) {x : E}
    (hx : ‖x‖ ≤ 1) : ‖P x‖ ≤ polyNorm P := by
  apply le_csSup
  · refine ⟨M, ?_⟩
    rintro _ ⟨y, hy, rfl⟩
    exact h y (by simpa using hy)
  · exact ⟨x, by simpa using hx, rfl⟩

lemma exists_near_polyNorm {P : E → F} {δ : ℝ}
    (hδ : 0 < δ) : ∃ x, ‖x‖ ≤ 1 ∧ polyNorm P - δ < ‖P x‖ := by
  have hne : ((fun x => ‖P x‖) '' Metric.closedBall (0 : E) 1).Nonempty :=
    ⟨_, 0, by simp, rfl⟩
  obtain ⟨_, ⟨x, hx, rfl⟩, hlt⟩ := exists_lt_of_lt_csSup hne (show polyNorm P - δ < polyNorm P by
    linarith)
  exact ⟨x, by simpa using hx, hlt⟩

end polyNorm

section diag

variable {n : ℕ}

@[simp] lemma diag_apply (A : MLin 𝕜 X Y n) (x : X) : diag A x = A (fun _ => x) := rfl

lemma diag_add (A B : MLin 𝕜 X Y n) : diag (A + B) = diag A + diag B := by
  ext x; simp

lemma diag_sub (A B : MLin 𝕜 X Y n) : diag (A - B) = diag A - diag B := by
  ext x; simp

lemma diag_smul (c : 𝕜) (A : MLin 𝕜 X Y n) : diag (c • A) = c • diag A := by
  ext x; simp

lemma diag_smul_arg (A : MLin 𝕜 X Y n) (c : 𝕜) (x : X) :
    diag A (c • x) = c ^ n • diag A x := by
  simp only [diag_apply]
  rw [show (fun _ : Fin n => c • x) = (fun i => (fun _ => c) i • (fun _ => x) i) from rfl,
    ContinuousMultilinearMap.map_smul_univ]
  simp

lemma norm_apply_le_of_ball (A : MLin 𝕜 X Y n) {v : Fin n → X} (hv : ∀ i, ‖v i‖ ≤ 1) :
    ‖A v‖ ≤ ‖A‖ := by
  calc ‖A v‖ ≤ ‖A‖ * ∏ i, ‖v i‖ := A.le_opNorm v
    _ ≤ ‖A‖ * 1 := by
        gcongr
        exact Finset.prod_le_one₀ (fun i _ => norm_nonneg _) (fun i _ => hv i)
    _ = ‖A‖ := mul_one _

lemma diag_bound (A : MLin 𝕜 X Y n) : ∀ x : X, ‖x‖ ≤ 1 → ‖diag A x‖ ≤ ‖A‖ :=
  fun _ hx => norm_apply_le_of_ball A (fun _ => hx)

lemma norm_diag_le_polyNorm (A : MLin 𝕜 X Y n) {x : X} (hx : ‖x‖ ≤ 1) :
    ‖diag A x‖ ≤ polyNorm (diag A) :=
  norm_le_polyNorm (diag_bound A) hx

lemma polyNorm_diag_le_opNorm (A : MLin 𝕜 X Y n) : polyNorm (diag A) ≤ ‖A‖ :=
  polyNorm_le (norm_nonneg _) (diag_bound A)

/-- Homogeneity estimate {lit}`‖P x‖ ≤ ‖P‖ ‖x‖ ^ n`. -/
lemma norm_diag_le (A : MLin 𝕜 X Y n) (x : X) :
    ‖diag A x‖ ≤ polyNorm (diag A) * ‖x‖ ^ n := by
  rcases eq_or_ne x 0 with rfl | hx
  · rcases Nat.eq_zero_or_pos n with rfl | hn
    · simpa using norm_diag_le_polyNorm A (x := (0 : X)) (by simp)
    · have : diag A (0 : X) = 0 := by
        simp only [diag_apply]
        exact A.map_coord_zero ⟨0, hn⟩ rfl
      rw [this, norm_zero]
      exact mul_nonneg (polyNorm_nonneg _) (by positivity)
  · have hxpos : 0 < ‖x‖ := norm_pos_iff.mpr hx
    set y : X := ((‖x‖⁻¹ : ℝ) : 𝕜) • x
    have hy : ‖y‖ ≤ 1 := by
      simp only [y, norm_smul, RCLike.norm_ofReal, abs_inv, abs_norm]
      rw [inv_mul_cancel₀ hxpos.ne']
    have hxy : x = ((‖x‖ : ℝ) : 𝕜) • y := by
      simp only [y, smul_smul, ← RCLike.ofReal_mul, mul_inv_cancel₀ hxpos.ne',
        RCLike.ofReal_one, one_smul]
    rw [hxy, diag_smul_arg, norm_smul, norm_pow, RCLike.norm_ofReal, abs_norm, mul_comm]
    have := norm_diag_le_polyNorm A hy
    have h2 : ‖(((‖x‖ : ℝ) : 𝕜) • y)‖ = ‖x‖ := by rw [← hxy]
    rw [h2]
    gcongr

lemma polyNorm_diag_add_le (A B : MLin 𝕜 X Y n) :
    polyNorm (diag (A + B)) ≤ polyNorm (diag A) + polyNorm (diag B) := by
  apply polyNorm_le (add_nonneg (polyNorm_nonneg _) (polyNorm_nonneg _))
  intro x hx
  rw [diag_add, Pi.add_apply]
  exact (norm_add_le _ _).trans (add_le_add (norm_diag_le_polyNorm A hx)
    (norm_diag_le_polyNorm B hx))

lemma polyNorm_diag_smul (c : 𝕜) (A : MLin 𝕜 X Y n) :
    polyNorm (diag (c • A)) = ‖c‖ * polyNorm (diag A) := by
  apply le_antisymm
  · apply polyNorm_le (mul_nonneg (norm_nonneg _) (polyNorm_nonneg _))
    intro x hx
    rw [diag_smul, Pi.smul_apply, norm_smul]
    gcongr
    exact norm_diag_le_polyNorm A hx
  · rcases eq_or_ne c 0 with rfl | hc
    · simp [polyNorm_nonneg]
    · have h : polyNorm (diag A) ≤ ‖c‖⁻¹ * polyNorm (diag (c • A)) := by
        apply polyNorm_le (mul_nonneg (inv_nonneg.mpr (norm_nonneg _)) (polyNorm_nonneg _))
        intro x hx
        have h1 := norm_diag_le_polyNorm (c • A) hx
        rw [diag_smul, Pi.smul_apply, norm_smul] at h1
        rw [le_inv_mul_iff₀ (norm_pos_iff.mpr hc)]
        exact h1
      rw [le_inv_mul_iff₀ (norm_pos_iff.mpr hc)] at h
      exact h

lemma polyNorm_diag_neg (A : MLin 𝕜 X Y n) : polyNorm (diag (-A)) = polyNorm (diag A) := by
  have := polyNorm_diag_smul (-1 : 𝕜) A
  simpa using this

lemma polyNorm_diag_sub_comm (A B : MLin 𝕜 X Y n) :
    polyNorm (diag (A - B)) = polyNorm (diag (B - A)) := by
  rw [← neg_sub, polyNorm_diag_neg]

lemma polyNorm_diag_sub_le (A B : MLin 𝕜 X Y n) :
    polyNorm (diag A) ≤ polyNorm (diag B) + polyNorm (diag (A - B)) := by
  have := polyNorm_diag_add_le B (A - B)
  simpa using this

lemma abs_polyNorm_diag_sub_le (A B : MLin 𝕜 X Y n) :
    |polyNorm (diag A) - polyNorm (diag B)| ≤ polyNorm (diag (A - B)) := by
  rw [abs_le]
  constructor
  · have := polyNorm_diag_sub_le B A
    rw [polyNorm_diag_sub_comm] at this
    linarith
  · have := polyNorm_diag_sub_le A B
    linarith

end diag

section symm

variable {n : ℕ}

lemma IsSymm.add {A B : MLin 𝕜 X Y n} (hA : IsSymm A) (hB : IsSymm B) : IsSymm (A + B) := by
  intro σ v; simp [hA σ v, hB σ v]

lemma IsSymm.sub {A B : MLin 𝕜 X Y n} (hA : IsSymm A) (hB : IsSymm B) : IsSymm (A - B) := by
  intro σ v; simp [hA σ v, hB σ v]

lemma IsSymm.smul {A : MLin 𝕜 X Y n} (c : 𝕜) (hA : IsSymm A) : IsSymm (c • A) := by
  intro σ v; simp [hA σ v]

lemma IsSymm.zero : IsSymm (0 : MLin 𝕜 X Y n) := by
  intro σ v; simp

lemma IsSymm.comp {Z : Type*} [NormedAddCommGroup Z] [NormedSpace 𝕜 Z] {A : MLin 𝕜 X Y n}
    (hA : IsSymm A) (g : Y →L[𝕜] Z) : IsSymm (g.compContinuousMultilinearMap A) := by
  intro σ v; simp [hA σ v]

lemma isClosed_isSymm : IsClosed {A : MLin 𝕜 X Y n | IsSymm A} := by
  have : {A : MLin 𝕜 X Y n | IsSymm A} =
      ⋂ σ : Equiv.Perm (Fin n), ⋂ v : Fin n → X, {A | A (v ∘ σ) = A v} := by
    ext A; simp [IsSymm]
  rw [this]
  refine isClosed_iInter fun σ => isClosed_iInter fun v => ?_
  exact isClosed_eq (continuous_eval_const _) (continuous_eval_const _)

/-- Symmetrization {lit}`(1/n!) ∑_σ A ∘ σ` of a multilinear map. -/
def symmetrize (A : MLin 𝕜 X Y n) : MLin 𝕜 X Y n :=
  ((n.factorial : 𝕜))⁻¹ • ∑ σ : Equiv.Perm (Fin n), A.domDomCongr σ

lemma domDomCongr_apply' (A : MLin 𝕜 X Y n) (σ : Equiv.Perm (Fin n)) (v : Fin n → X) :
    A.domDomCongr σ v = A (v ∘ σ) := by
  simp [ContinuousMultilinearMap.domDomCongr]
  rfl

lemma symmetrize_apply (A : MLin 𝕜 X Y n) (v : Fin n → X) :
    symmetrize A v = ((n.factorial : 𝕜))⁻¹ • ∑ σ : Equiv.Perm (Fin n), A (v ∘ σ) := by
  simp [symmetrize]
  rfl

lemma isSymm_symmetrize (A : MLin 𝕜 X Y n) : IsSymm (symmetrize A) := by
  intro τ v
  rw [symmetrize_apply, symmetrize_apply]
  congr 1
  exact Fintype.sum_equiv (Equiv.mulLeft τ) _ _ (fun σ => by simp [Function.comp_assoc])

lemma diag_symmetrize (A : MLin 𝕜 X Y n) : diag (symmetrize A) = diag A := by
  ext x
  simp only [diag_apply, symmetrize_apply]
  have : ∀ σ : Equiv.Perm (Fin n), A ((fun _ : Fin n => x) ∘ σ) = A (fun _ => x) :=
    fun σ => rfl
  simp only [this, Finset.sum_const, Finset.card_univ, Fintype.card_perm, Fintype.card_fin]
  rw [← Nat.cast_smul_eq_nsmul 𝕜, smul_smul, inv_mul_cancel₀ (by exact_mod_cast
    (Nat.factorial_pos n).ne'), one_smul]

lemma symmetrize_of_isSymm {A : MLin 𝕜 X Y n} (hA : IsSymm A) : symmetrize A = A := by
  ext v
  rw [symmetrize_apply]
  simp only [hA _ v, Finset.sum_const, Finset.card_univ, Fintype.card_perm, Fintype.card_fin]
  rw [← Nat.cast_smul_eq_nsmul 𝕜, smul_smul, inv_mul_cancel₀ (by exact_mod_cast
    (Nat.factorial_pos n).ne'), one_smul]

end symm

end LindenstraussPolynomials
