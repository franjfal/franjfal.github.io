import LindenstraussPolynomials.Construction

/-!
# The limit polynomial

The perturbations are summable: $`\|P_m-P_k\|\le 2\alpha_k/(1-a)`, so $`(P_k)` converges to a symmetric form $`Q` with $`\|Q-P_k\|\le4\alpha_k` ({lit}`eq:tailQ`).
-/

noncomputable section

open scoped BigOperators Topology
open Finset Filter

namespace LindenstraussPolynomials

variable {𝕜 : Type*} [RCLike 𝕜]
variable {X : Type*} [NormedAddCommGroup X] [NormedSpace 𝕜 X]
variable {Y : Type*} [NormedAddCommGroup Y] [NormedSpace 𝕜 Y]
variable {d : ℕ}

section facts

variable {A : MLin 𝕜 X Y (d + 1)} {a : ℝ}

/-- {lit}`‖P_{k+N} - P_k‖ ≤ 2 α_k / (1-a)`. -/
lemma polyNorm_seq_diff [Nontrivial X] (hA1 : polyNorm (diag A) = 1) (ha : 0 < a)
    (ha8 : a < 1 / 8) (k N : ℕ) :
    polyNorm (diag (seqP A a (k + N) - seqP A a k)) ≤ 2 * alpha a k / (1 - a) := by
  have h1a : 0 < 1 - a := by linarith
  have key : polyNorm (diag (seqP A a (k + N) - seqP A a k)) ≤
      (∑ i ∈ range N, alpha a (k + i)) / (1 - a) := by
    induction N with
    | zero =>
      simp only [add_zero, sub_self, Finset.sum_range_zero, zero_div]
      exact polyNorm_le le_rfl (fun x _ => by simp [diag_apply])
    | succ N ih =>
      have h := polyNorm_diag_add_le (seqP A a (k + (N + 1)) - seqP A a (k + N))
        (seqP A a (k + N) - seqP A a k)
      rw [sub_add_sub_cancel] at h
      have hinc := polyNorm_seq_increment (A := A) ha (k + N)
      have hM := seqM_le hA1 ha (by linarith) (k + N)
      have hα := alpha_pos ha (k + N)
      rw [Finset.sum_range_succ, add_div]
      have : alpha a (k + N) * seqM A a (k + N) ≤ alpha a (k + N) / (1 - a) := by
        rw [div_eq_mul_one_div]; exact mul_le_mul_of_nonneg_left hM hα.le
      rw [show k + (N + 1) = k + N + 1 by ring] at h ⊢
      linarith
  refine key.trans ?_
  gcongr
  exact sum_alpha_le ha.le (by linarith) k N

/-- The operator-norm version. -/
lemma opNorm_seq_diff [Nontrivial X] (hA : IsSymm A) (hA1 : polyNorm (diag A) = 1) (ha : 0 < a)
    (ha8 : a < 1 / 8) (k N : ℕ) :
    ‖seqP A a (k + N) - seqP A a k‖ ≤ cPol (d + 1) * (2 * alpha a k / (1 - a)) :=
  (opNorm_le_cPol_mul ((isSymm_seqP hA _).sub (isSymm_seqP hA _))).trans
    (mul_le_mul_of_nonneg_left (polyNorm_seq_diff hA1 ha ha8 k N) (cPol_nonneg _))

lemma cauchySeq_seqP [Nontrivial X] (hA : IsSymm A) (hA1 : polyNorm (diag A) = 1) (ha : 0 < a)
    (ha8 : a < 1 / 8) : CauchySeq (seqP A a) := by
  refine cauchySeq_of_le_tendsto_0 (fun k => 2 * (cPol (d + 1) * (2 * alpha a k / (1 - a))))
    ?_ ?_
  · intro m n N hm hn
    rw [dist_eq_norm]
    obtain ⟨i, rfl⟩ := Nat.exists_eq_add_of_le hm
    obtain ⟨j, rfl⟩ := Nat.exists_eq_add_of_le hn
    have h1 := opNorm_seq_diff hA hA1 ha ha8 N i
    have h2 := opNorm_seq_diff hA hA1 ha ha8 N j
    calc ‖seqP A a (N + i) - seqP A a (N + j)‖
        = ‖(seqP A a (N + i) - seqP A a N) - (seqP A a (N + j) - seqP A a N)‖ := by
          congr 1; abel
      _ ≤ ‖seqP A a (N + i) - seqP A a N‖ + ‖seqP A a (N + j) - seqP A a N‖ := norm_sub_le _ _
      _ ≤ _ := by linarith
  · have h := tendsto_alpha ha.le (by linarith : a < 1)
    have := ((h.const_mul 2).div_const (1 - a)).const_mul (cPol (d + 1)) |>.const_mul 2
    simpa using this

/-- The limit {lit}`Q` of the sequence {lit}`P_k`. -/
def limQ [CompleteSpace Y] (A : MLin 𝕜 X Y (d + 1)) (a : ℝ) : MLin 𝕜 X Y (d + 1) :=
  limUnder atTop (seqP A a)

lemma tendsto_limQ [CompleteSpace Y] [Nontrivial X] (hA : IsSymm A)
    (hA1 : polyNorm (diag A) = 1) (ha : 0 < a) (ha8 : a < 1 / 8) :
    Tendsto (seqP A a) atTop (𝓝 (limQ A a)) :=
  (cauchySeq_seqP hA hA1 ha ha8).tendsto_limUnder

lemma isSymm_limQ [CompleteSpace Y] [Nontrivial X] (hA : IsSymm A)
    (hA1 : polyNorm (diag A) = 1) (ha : 0 < a) (ha8 : a < 1 / 8) : IsSymm (limQ A a) :=
  isClosed_isSymm.mem_of_tendsto (tendsto_limQ hA hA1 ha ha8)
    (Eventually.of_forall fun k => isSymm_seqP hA k)

/-- {lit}`‖Q - P_k‖ ≤ 4 α_k` ({lit}`eq:tailQ`). -/
lemma polyNorm_limQ_sub [CompleteSpace Y] [Nontrivial X] (hA : IsSymm A)
    (hA1 : polyNorm (diag A) = 1) (ha : 0 < a) (ha8 : a < 1 / 8) (k : ℕ) :
    polyNorm (diag (limQ A a - seqP A a k)) ≤ 4 * alpha a k := by
  have hα := alpha_pos ha k
  have hb : 2 * alpha a k / (1 - a) ≤ 4 * alpha a k := by
    rw [div_le_iff₀ (by linarith)]; nlinarith
  apply polyNorm_le (by linarith)
  intro x hx
  have hT := tendsto_limQ hA hA1 ha ha8
  have hT' : Tendsto (fun N => diag (seqP A a (k + N) - seqP A a k) x) atTop
      (𝓝 (diag (limQ A a - seqP A a k) x)) := by
    have h1 : Tendsto (fun N => seqP A a (k + N)) atTop (𝓝 (limQ A a)) :=
      hT.comp (tendsto_atTop_atTop_of_monotone (fun _ _ h => by omega)
        (fun b => ⟨b, by omega⟩))
    have h2 := (h1.sub_const (seqP A a k))
    have hc : Continuous fun B : MLin 𝕜 X Y (d + 1) => diag B x :=
      by unfold diag; fun_prop
    exact (hc.tendsto _).comp h2
  refine le_of_tendsto hT'.norm (Eventually.of_forall fun N => ?_)
  exact (norm_diag_le_polyNorm _ hx).trans ((polyNorm_seq_diff hA1 ha ha8 k N).trans hb)

lemma opNorm_limQ_sub [CompleteSpace Y] [Nontrivial X] (hA : IsSymm A)
    (hA1 : polyNorm (diag A) = 1) (ha : 0 < a) (ha8 : a < 1 / 8) (k : ℕ) :
    ‖limQ A a - seqP A a k‖ ≤ cPol (d + 1) * (4 * alpha a k) :=
  (opNorm_le_cPol_mul ((isSymm_limQ hA hA1 ha ha8).sub (isSymm_seqP hA _))).trans
    (mul_le_mul_of_nonneg_left (polyNorm_limQ_sub hA hA1 ha ha8 k) (cPol_nonneg _))

/-- {lit}`|M - M_k| ≤ 4 α_k`. -/
lemma abs_polyNorm_limQ_sub [CompleteSpace Y] [Nontrivial X] (hA : IsSymm A)
    (hA1 : polyNorm (diag A) = 1) (ha : 0 < a) (ha8 : a < 1 / 8) (k : ℕ) :
    |polyNorm (diag (limQ A a)) - seqM A a k| ≤ 4 * alpha a k :=
  (abs_polyNorm_diag_sub_le _ _).trans (polyNorm_limQ_sub hA hA1 ha ha8 k)

/-- {lit}`‖Q - P‖ ≤ 4a`. -/
lemma polyNorm_limQ_sub_A [CompleteSpace Y] [Nontrivial X] (hA : IsSymm A)
    (hA1 : polyNorm (diag A) = 1) (ha : 0 < a) (ha8 : a < 1 / 8) :
    polyNorm (diag (limQ A a - A)) ≤ 4 * a := by
  have := polyNorm_limQ_sub hA hA1 ha ha8 0
  simpa [seqP, alpha_zero] using this

end facts

end LindenstraussPolynomials
