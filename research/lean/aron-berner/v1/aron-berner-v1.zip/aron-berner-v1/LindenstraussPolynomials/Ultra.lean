import LindenstraussPolynomials.Extension

/-!
# Limits along an ultrafilter

For a sequence $`(x_k)` in the unit ball of $`X` and a free ultrafilter $`\mathcal U` on $`\mathbb N`, $`z(f)=\lim_{k\to\mathcal U}f(x_k)` defines a point $`z` of the unit ball of $`X^{**}` ({lit}`eq:z`), and the canonical extension at $`z` is an iterated limit along $`\mathcal U` ({lit}`eq:ulpartial`). Lower bounds that hold at every strictly increasing tuple of indices survive these limits.
-/

noncomputable section

open scoped BigOperators Topology
open Finset Filter

namespace LindenstraussPolynomials

variable {𝕜 : Type*} [RCLike 𝕜]
variable {X : Type*} [NormedAddCommGroup X] [NormedSpace 𝕜 X]

/-- The free ultrafilter used for the limits. -/
abbrev 𝒰 : Ultrafilter ℕ := hyperfilter ℕ

/-- Limit along {lit}`𝒰`. -/
def ulim (s : ℕ → 𝕜) : 𝕜 := limUnder (𝒰 : Filter ℕ) s

lemma tendsto_ulim {s : ℕ → 𝕜} {R : ℝ} (hs : ∀ k, ‖s k‖ ≤ R) :
    Tendsto s (𝒰 : Filter ℕ) (𝓝 (ulim s)) := by
  apply tendsto_nhds_limUnder
  obtain ⟨x, -, hx⟩ := (isCompact_closedBall (0 : 𝕜) R).ultrafilter_le_nhds (𝒰.map s) (by
    rw [Ultrafilter.coe_map, le_principal_iff]
    exact Filter.mem_map.mpr (Filter.univ_mem' fun k => by simpa using hs k))
  exact ⟨x, hx⟩

lemma eventually_gt_ultra (N : ℕ) : ∀ᶠ k in (𝒰 : Filter ℕ), N < k :=
  (eventually_gt_atTop N).filter_mono (hyperfilter_le_cofinite.trans Nat.cofinite_eq_atTop.le)

/-- {lit}`z(f) = lim_{k → 𝒰} f(x_k)` (equation {lit}`eq:z`). -/
def ultraPoint (x : ℕ → X) (hx : ∀ k, ‖x k‖ ≤ 1) : Bidual 𝕜 X :=
  LinearMap.mkContinuous
    { toFun := fun f => ulim (fun k => f (x k))
      map_add' := fun f g => by
        have hf := tendsto_ulim (s := fun k => f (x k)) (R := ‖f‖) (fun k =>
          (f.le_opNorm _).trans (by simpa using mul_le_mul_of_nonneg_left (hx k) (norm_nonneg f)))
        have hg := tendsto_ulim (s := fun k => g (x k)) (R := ‖g‖) (fun k =>
          (g.le_opNorm _).trans (by simpa using mul_le_mul_of_nonneg_left (hx k) (norm_nonneg g)))
        have hfg := tendsto_ulim (s := fun k => (f + g) (x k)) (R := ‖f + g‖) (fun k =>
          ((f + g).le_opNorm _).trans
            (by simpa using mul_le_mul_of_nonneg_left (hx k) (norm_nonneg (f + g))))
        exact tendsto_nhds_unique hfg (by simpa using hf.add hg)
      map_smul' := fun c f => by
        have hf := tendsto_ulim (s := fun k => f (x k)) (R := ‖f‖) (fun k =>
          (f.le_opNorm _).trans (by simpa using mul_le_mul_of_nonneg_left (hx k) (norm_nonneg f)))
        have hcf := tendsto_ulim (s := fun k => (c • f) (x k)) (R := ‖c • f‖) (fun k =>
          ((c • f).le_opNorm _).trans
            (by simpa using mul_le_mul_of_nonneg_left (hx k) (norm_nonneg (c • f))))
        exact tendsto_nhds_unique hcf (by simpa using hf.const_mul c) }
    1
    (fun f => by
      simp only [LinearMap.coe_mk, AddHom.coe_mk, one_mul]
      have hb : ∀ k, ‖f (x k)‖ ≤ ‖f‖ := fun k =>
        (f.le_opNorm _).trans (by simpa using mul_le_mul_of_nonneg_left (hx k) (norm_nonneg f))
      have hf := tendsto_ulim hb
      exact le_of_tendsto hf.norm (Filter.Eventually.of_forall hb))

lemma ultraPoint_apply (x : ℕ → X) (hx : ∀ k, ‖x k‖ ≤ 1) (f : StrongDual 𝕜 X) :
    ultraPoint x hx f = ulim (fun k => f (x k)) := rfl

lemma norm_ultraPoint_le (x : ℕ → X) (hx : ∀ k, ‖x k‖ ≤ 1) : ‖ultraPoint (𝕜 := 𝕜) x hx‖ ≤ 1 :=
  LinearMap.mkContinuous_norm_le _ zero_le_one _

lemma strictMono_snoc {r : ℕ} {ι : Fin r → ℕ} (hι : StrictMono ι) {k : ℕ}
    (hk : ∀ i, ι i < k) : StrictMono (Fin.snoc ι k : Fin (r + 1) → ℕ) := by
  intro a b hab
  induction b using Fin.lastCases with
  | last =>
    induction a using Fin.lastCases with
    | last => exact absurd hab (lt_irrefl _)
    | cast a => simpa using hk a
  | cast b =>
    induction a using Fin.lastCases with
    | last => exact absurd hab (not_lt.mpr (Fin.le_last _))
    | cast a =>
      simp only [Fin.snoc_castSucc]
      exact hι (Fin.castSucc_lt_castSucc_iff.mp hab)

lemma strictMono_cons {r : ℕ} {ι : Fin r → ℕ} (hι : StrictMono ι) {m : ℕ}
    (hm : ∀ i, m < ι i) : StrictMono (Fin.cons m ι : Fin (r + 1) → ℕ) := by
  intro a b hab
  induction b using Fin.cases with
  | zero => exact absurd hab (not_lt.mpr (Fin.zero_le _))
  | succ b =>
    induction a using Fin.cases with
    | zero => simpa using hm b
    | succ a =>
      simp only [Fin.cons_succ]
      exact hι (Fin.succ_lt_succ_iff.mp hab)

/-- Lower bounds at strictly increasing tuples of indices larger than {lit}`m` survive the
iterated limits defining the canonical extension at the ultrafilter limit point. -/
theorem le_norm_diagExt_ultra (x : ℕ → X) (hx : ∀ k, ‖x k‖ ≤ 1) (m : ℕ) (β : ℝ) :
    ∀ {r : ℕ} (C : MLin 𝕜 X 𝕜 r),
      (∀ ι : Fin r → ℕ, StrictMono ι → (∀ i, m < ι i) → β ≤ ‖C (fun i => x (ι i))‖) →
      β ≤ ‖diagExt (ultraPoint x hx) C‖
  | 0, C, h => by
    have := h (fun i => Fin.elim0 i) (fun i => Fin.elim0 i) (fun i => Fin.elim0 i)
    simp only [diagExt_zero]
    convert this using 3
  | r + 1, C, h => by
    rw [diagExt_succ]
    apply le_norm_diagExt_ultra x hx m β (extLast _ C)
    intro ι hι hm
    rw [extLast_apply, ultraPoint_apply]
    set s : ℕ → 𝕜 := fun k => C.curryRight (fun i => x (ι i)) (x k)
    have hb : ∀ k, ‖s k‖ ≤ ‖C.curryRight (fun i => x (ι i))‖ := fun k =>
      ((C.curryRight _).le_opNorm _).trans (by
        simpa using mul_le_mul_of_nonneg_left (hx k) (norm_nonneg _))
    have hs := tendsto_ulim hb
    apply ge_of_tendsto hs.norm
    filter_upwards [eventually_gt_ultra (m + ∑ i, ι i)] with k hk
    simp only [s, curryRight_apply']
    have hk' : ∀ i, ι i < k := fun i => by
      have : ι i ≤ ∑ j, ι j :=
        Finset.single_le_sum (f := ι) (fun j _ => Nat.zero_le _) (Finset.mem_univ i)
      omega
    have := h (Fin.snoc ι k) (strictMono_snoc hι hk') (fun i => by
      induction i using Fin.lastCases with
      | last => simp only [Fin.snoc_last]; omega
      | cast i => simpa using hm i)
    convert this using 3
    funext i
    induction i using Fin.lastCases with
    | last => simp
    | cast i => simp

end LindenstraussPolynomials
