import LindenstraussPolynomials.Core

/-!
# Main results

* Lemma {lit}`lem:isometry`: the canonical extension preserves the norm, for scalar- and vector-valued polynomials.
* Theorem {lit}`thm:main`: for every continuous $`n`-homogeneous scalar polynomial $`P` ($`n\ge1`) and every $`\varepsilon>0` there are $`Q` and $`z` in the unit ball of $`X^{**}` with $`\|Q-P\|<\varepsilon` and $`|\widetilde Q(z)|=\|\widetilde Q\|=\|Q\|`; equivalently, such polynomials are dense.
* Theorem {lit}`thm:vector`: the same for polynomials with values in a Banach space $`Y`.

Here $`\|\widetilde Q\|` is the supremum of $`\|\widetilde Q(z)\|` over the closed unit ball of the bidual. $`X` need not be complete; only $`Y` is assumed complete in the vector-valued case.
-/

noncomputable section

open scoped BigOperators Topology
open Finset Filter

namespace LindenstraussPolynomials

variable {𝕜 : Type*} [RCLike 𝕜]
variable {X : Type*} [NormedAddCommGroup X] [NormedSpace 𝕜 X]
variable {Y : Type*} [NormedAddCommGroup Y] [NormedSpace 𝕜 Y]

lemma isHomPoly_comp {n : ℕ} {P : X → Y} (hP : IsHomPoly 𝕜 n P) (g : StrongDual 𝕜 Y) :
    IsHomPoly 𝕜 n (fun x => g (P x)) := by
  obtain ⟨L, hL⟩ := hP
  exact ⟨g.compContinuousMultilinearMap L, fun x => by simp [hL x]⟩

lemma norm_abExtV_le {n : ℕ} {P : X → Y} (hP : IsHomPoly 𝕜 n P) {z : Bidual 𝕜 X}
    (hz : ‖z‖ ≤ 1) : ‖abExtV 𝕜 n P z‖ ≤ polyNorm P := by
  have h := norm_diagExtV_le (isSymm_symmForm (𝕜 := 𝕜) (n := n) P) z hz
  rwa [diag_symmForm hP] at h

lemma abExtV_inclusion {n : ℕ} {P : X → Y} (hP : IsHomPoly 𝕜 n P) (x : X) :
    abExtV 𝕜 n P (NormedSpace.inclusionInDoubleDual 𝕜 X x) =
      NormedSpace.inclusionInDoubleDual 𝕜 Y (P x) := by
  ext g
  rw [abExtV_apply hP, abExt_inclusion (isHomPoly_comp hP g), NormedSpace.dual_def]

/-- **Norm preservation** (Lemma {lit}`lem:isometry`, Davie–Gamelin), vector-valued version:
{lit}`sup_{‖z‖ ≤ 1} ‖P̃(z)‖ = ‖P‖`. -/
theorem polyNorm_abExtV {n : ℕ} {P : X → Y} (hP : IsHomPoly 𝕜 n P) :
    polyNorm (abExtV 𝕜 n P) = polyNorm P := by
  apply le_antisymm
  · exact polyNorm_le (polyNorm_nonneg _) fun z hz => norm_abExtV_le hP hz
  · apply polyNorm_le (polyNorm_nonneg _)
    intro x hx
    have h := norm_le_polyNorm (P := abExtV 𝕜 n P) (fun z hz => norm_abExtV_le hP hz)
      ((NormedSpace.double_dual_bound 𝕜 X x).trans hx)
    have e : ‖NormedSpace.inclusionInDoubleDual 𝕜 Y (P x)‖ = ‖P x‖ :=
      (NormedSpace.inclusionInDoubleDualLi 𝕜 (E := Y)).norm_map (P x)
    rwa [abExtV_inclusion hP, e] at h

lemma norm_abExt_le {n : ℕ} {P : X → 𝕜} (hP : IsHomPoly 𝕜 n P) {z : Bidual 𝕜 X}
    (hz : ‖z‖ ≤ 1) : ‖abExt 𝕜 n P z‖ ≤ polyNorm P := by
  have h := davie_gamelin (isSymm_symmForm (𝕜 := 𝕜) (n := n) P) z hz
  rwa [diag_symmForm hP] at h

/-- **Norm preservation** (Lemma {lit}`lem:isometry`, Davie–Gamelin \[DG, Theorem 3\]), over {lit}`ℝ` and
{lit}`ℂ`: {lit}`sup_{‖z‖ ≤ 1} |P̃(z)| = ‖P‖`. -/
theorem polyNorm_abExt {n : ℕ} {P : X → 𝕜} (hP : IsHomPoly 𝕜 n P) :
    polyNorm (abExt 𝕜 n P) = polyNorm P := by
  apply le_antisymm
  · exact polyNorm_le (polyNorm_nonneg _) fun z hz => norm_abExt_le hP hz
  · apply polyNorm_le (polyNorm_nonneg _)
    intro x hx
    have h := norm_le_polyNorm (P := abExt 𝕜 n P) (fun z hz => norm_abExt_le hP hz)
      ((NormedSpace.double_dual_bound 𝕜 X x).trans hx)
    rwa [abExt_inclusion hP] at h

/-- For scalar-valued forms, the vector-valued extension has the same modulus. -/
lemma norm_diagExtV_scalar {m : ℕ} (z : Bidual 𝕜 X) (B : MLin 𝕜 X 𝕜 m) :
    ‖diagExtV z B‖ = ‖diagExt z B‖ := by
  have hcomp : ∀ g : StrongDual 𝕜 𝕜, g.compContinuousMultilinearMap B = g 1 • B := by
    intro g
    ext v
    simp only [ContinuousLinearMap.compContinuousMultilinearMap_coe, Function.comp_apply,
      smul_apply, smul_eq_mul]
    conv_lhs => rw [← mul_one (B v)]
    rw [← smul_eq_mul, map_smul, smul_eq_mul, mul_comm]
  have hval : ∀ g : StrongDual 𝕜 𝕜, diagExtV z B g = g 1 * diagExt z B := by
    intro g
    rw [diagExtV_apply, hcomp, diagExt_smul]
  apply le_antisymm
  · apply ContinuousLinearMap.opNorm_le_bound _ (norm_nonneg _)
    intro g
    rw [hval, norm_mul, mul_comm]
    gcongr
    simpa using g.le_opNorm 1
  · calc ‖diagExt z B‖ = ‖diagExtV z B (ContinuousLinearMap.id 𝕜 𝕜)‖ := by
          rw [hval]; simp
      _ ≤ ‖diagExtV z B‖ * ‖ContinuousLinearMap.id 𝕜 𝕜‖ := (diagExtV z B).le_opNorm _
      _ ≤ ‖diagExtV z B‖ * 1 :=
          mul_le_mul_of_nonneg_left ContinuousLinearMap.norm_id_le
            (ContinuousLinearMap.opNorm_nonneg _)
      _ = _ := mul_one _

lemma norm_abExtV_scalar {n : ℕ} (P : X → 𝕜) (z : Bidual 𝕜 X) :
    ‖abExtV 𝕜 n P z‖ = ‖abExt 𝕜 n P z‖ :=
  norm_diagExtV_scalar z _

lemma norm_smul_bidual {c : 𝕜} (hc : c ≠ 0) (T : Bidual 𝕜 Y) : ‖c • T‖ = ‖c‖ * ‖T‖ := by
  apply le_antisymm (ContinuousLinearMap.opNorm_smul_le c T)
  have h := ContinuousLinearMap.opNorm_smul_le c⁻¹ (c • T)
  rw [inv_smul_smul₀ hc, norm_inv] at h
  have hcpos : 0 < ‖c‖ := norm_pos_iff.mpr hc
  calc ‖c‖ * ‖T‖ ≤ ‖c‖ * (‖c‖⁻¹ * ‖c • T‖) := mul_le_mul_of_nonneg_left h hcpos.le
    _ = ‖c • T‖ := by field_simp

lemma polyNorm_zero_fun : polyNorm (0 : X → Y) = 0 :=
  le_antisymm (polyNorm_le le_rfl fun x _ => by simp) (polyNorm_nonneg _)

/-- **Theorem {lit}`thm:vector`** (polynomial Lindenstrauss theorem, vector-valued).
For every continuous {lit}`n`-homogeneous polynomial {lit}`P : X → Y` ({lit}`n ≥ 1`, {lit}`Y` complete) and
every {lit}`ε > 0` there are a continuous {lit}`n`-homogeneous polynomial {lit}`Q` with {lit}`‖Q - P‖ < ε` and
a point {lit}`z` of the closed unit ball of {lit}`X**` with {lit}`‖Q̃(z)‖ = ‖Q̃‖ = ‖Q‖`. -/
theorem polynomial_lindenstrauss_vector [CompleteSpace Y] {n : ℕ} (hn : 1 ≤ n) {P : X → Y}
    (hP : IsHomPoly 𝕜 n P) {ε : ℝ} (hε : 0 < ε) :
    ∃ Q : X → Y, IsHomPoly 𝕜 n Q ∧ polyNorm (Q - P) < ε ∧
      ∃ z : Bidual 𝕜 X, ‖z‖ ≤ 1 ∧
        ‖abExtV 𝕜 n Q z‖ = polyNorm (abExtV 𝕜 n Q) ∧ polyNorm (abExtV 𝕜 n Q) = polyNorm Q := by
  obtain ⟨d, rfl⟩ : ∃ d, n = d + 1 := ⟨n - 1, by omega⟩
  set S := symmForm 𝕜 (d + 1) P with hSdef
  have hS : IsSymm S := isSymm_symmForm P
  have hSP : diag S = P := diag_symmForm hP
  set p := polyNorm P with hpdef
  have hp0 : 0 ≤ p := polyNorm_nonneg _
  rcases hp0.eq_or_lt with hp | hp
  · -- `P = 0` in norm: take `Q = P` and `z = 0`
    have hz0 : ‖(0 : Bidual 𝕜 X)‖ ≤ 1 :=
      ContinuousLinearMap.opNorm_le_bound _ zero_le_one (fun g => by simp)
    refine ⟨P, hP, by rw [sub_self, polyNorm_zero_fun]; exact hε, 0, hz0, ?_,
      polyNorm_abExtV hP⟩
    rw [polyNorm_abExtV hP]
    have h0 := norm_abExtV_le hP hz0
    have hP0 : polyNorm P = 0 := hp.symm
    rw [hP0] at h0 ⊢
    exact le_antisymm h0 (ContinuousLinearMap.opNorm_nonneg _)
  · have : Nontrivial X := by
      by_contra hX
      rw [not_nontrivial_iff_subsingleton] at hX
      have : p ≤ 0 := polyNorm_le le_rfl fun x _ => by
        rw [Subsingleton.elim x 0, ← hSP]
        simp only [diag_apply]
        rw [S.map_coord_zero 0 rfl, norm_zero]
      linarith
    set A : MLin 𝕜 X Y (d + 1) := ((p⁻¹ : ℝ) : 𝕜) • S with hAdef
    have hA : IsSymm A := hS.smul _
    have hA1 : polyNorm (diag A) = 1 := by
      rw [hAdef, polyNorm_diag_smul, hSP, RCLike.norm_ofReal, abs_inv, abs_of_pos hp,
        inv_mul_cancel₀ hp.ne']
    obtain ⟨B, hB, hBA, z, hz, hatt⟩ := core_attain hA hA1 (div_pos hε hp)
    have hpS : ((p : ℝ) : 𝕜) • A = S := by
      rw [hAdef, smul_smul, ← RCLike.ofReal_mul, mul_inv_cancel₀ hp.ne', RCLike.ofReal_one,
        one_smul]
    set Q := diag (((p : ℝ) : 𝕜) • B) with hQdef
    have hQ : IsHomPoly 𝕜 (d + 1) Q := isHomPoly_diag _
    have hsQ : symmForm 𝕜 (d + 1) Q = ((p : ℝ) : 𝕜) • B :=
      symmForm_eq_of_isSymm (hB.smul _)
    have hnp : ‖((p : ℝ) : 𝕜)‖ = p := by rw [RCLike.norm_ofReal, abs_of_pos hp]
    refine ⟨Q, hQ, ?_, z, hz, ?_, polyNorm_abExtV hQ⟩
    · have : Q - P = diag (((p : ℝ) : 𝕜) • (B - A)) := by
        rw [smul_sub, hpS, diag_sub, hSP]
      rw [this, polyNorm_diag_smul, hnp]
      calc p * polyNorm (diag (B - A)) < p * (ε / p) := mul_lt_mul_of_pos_left hBA hp
        _ = ε := by field_simp
    · rw [polyNorm_abExtV hQ, abExtV, hsQ, diagExtV_smul,
        norm_smul_bidual (by exact_mod_cast hp.ne'), hnp, hatt, hQdef, polyNorm_diag_smul, hnp]

/-- **Theorem {lit}`thm:main`** (polynomial Lindenstrauss theorem, scalar-valued; {lit}`𝕜 = ℝ` or {lit}`ℂ`).
For every continuous {lit}`n`-homogeneous polynomial {lit}`P : X → 𝕜` ({lit}`n ≥ 1`) and every {lit}`ε > 0`
there are a continuous {lit}`n`-homogeneous polynomial {lit}`Q` with {lit}`‖Q - P‖ < ε` and a point {lit}`z`
of the closed unit ball of {lit}`X**` with {lit}`|Q̃(z)| = ‖Q̃‖ = ‖Q‖`. -/
theorem polynomial_lindenstrauss {n : ℕ} (hn : 1 ≤ n) {P : X → 𝕜}
    (hP : IsHomPoly 𝕜 n P) {ε : ℝ} (hε : 0 < ε) :
    ∃ Q : X → 𝕜, IsHomPoly 𝕜 n Q ∧ polyNorm (Q - P) < ε ∧
      ∃ z : Bidual 𝕜 X, ‖z‖ ≤ 1 ∧
        ‖abExt 𝕜 n Q z‖ = polyNorm (abExt 𝕜 n Q) ∧ polyNorm (abExt 𝕜 n Q) = polyNorm Q := by
  obtain ⟨Q, hQ, hQP, z, hz, h1, h2⟩ := polynomial_lindenstrauss_vector hn hP hε
  refine ⟨Q, hQ, hQP, z, hz, ?_, polyNorm_abExt hQ⟩
  rw [polyNorm_abExt hQ, ← norm_abExtV_scalar, h1, h2]

/-- The density formulation of Theorem {lit}`thm:main`: every continuous {lit}`n`-homogeneous scalar
polynomial is a limit, in the norm {lit}`‖·‖`, of polynomials whose canonical extensions attain
their norms. -/
theorem polynomial_lindenstrauss_dense {n : ℕ} (hn : 1 ≤ n) {P : X → 𝕜}
    (hP : IsHomPoly 𝕜 n P) :
    ∃ Q : ℕ → X → 𝕜, (∀ k, IsHomPoly 𝕜 n (Q k) ∧
        ∃ z : Bidual 𝕜 X, ‖z‖ ≤ 1 ∧ ‖abExt 𝕜 n (Q k) z‖ = polyNorm (abExt 𝕜 n (Q k))) ∧
      Tendsto (fun k => polyNorm (Q k - P)) atTop (𝓝 0) := by
  choose Q hQ hQP z hz h1 _ using fun k : ℕ =>
    polynomial_lindenstrauss hn hP (Nat.one_div_pos_of_nat (n := k) (α := ℝ))
  refine ⟨Q, fun k => ⟨hQ k, z k, hz k, h1 k⟩, ?_⟩
  refine squeeze_zero (fun k => polyNorm_nonneg _) (fun k => (hQP k).le) ?_
  exact tendsto_one_div_add_atTop_nhds_zero_nat

end LindenstraussPolynomials
