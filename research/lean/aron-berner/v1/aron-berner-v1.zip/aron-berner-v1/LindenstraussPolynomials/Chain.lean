import LindenstraussPolynomials.Substitution

/-!
# Ordered compositions of substitutions

The composition $`S_1(t_1)\,S_2(t_2)\cdots S_d(t_d)\,x`, where $`S_i(t)\,y=(1-t)\,y+t\,f_i(y)\,u_i`. As in the article, the operators act from right to left: $`S_d(t_d)` is applied first and $`S_1(t_1)` last. Each $`S_i(t)` is a linear contraction when $`\|f_i\|\le1` and $`\|u_i\|\le1`.
-/

noncomputable section

open scoped BigOperators
open Finset

namespace LindenstraussPolynomials

variable {𝕜 : Type*} [RCLike 𝕜]
variable {X : Type*} [NormedAddCommGroup X] [NormedSpace 𝕜 X]

/-- {lit}`chainApply f u t x = S_{u₀,f₀}(t₀) (S_{u₁,f₁}(t₁) (⋯ (S_{u_{d-1},f_{d-1}}(t_{d-1}) x)))`. -/
def chainApply : ∀ {d : ℕ}, (Fin d → StrongDual 𝕜 X) → (Fin d → X) → (Fin d → ℝ) → X → X
  | 0, _, _, _, x => x
  | _ + 1, f, u, t, x =>
    substOp (f 0) (u 0) (t 0) (chainApply (Fin.tail f) (Fin.tail u) (Fin.tail t) x)

@[simp] lemma chainApply_zero (f : Fin 0 → StrongDual 𝕜 X) (u : Fin 0 → X) (t : Fin 0 → ℝ)
    (x : X) : chainApply f u t x = x := rfl

lemma chainApply_succ {d : ℕ} (f : Fin (d + 1) → StrongDual 𝕜 X) (u : Fin (d + 1) → X)
    (t : Fin (d + 1) → ℝ) (x : X) :
    chainApply f u t x =
      substOp (f 0) (u 0) (t 0) (chainApply (Fin.tail f) (Fin.tail u) (Fin.tail t) x) := rfl

/-- A composition of contractions is a contraction. -/
lemma norm_chainApply_le : ∀ {d : ℕ} (f : Fin d → StrongDual 𝕜 X) (u : Fin d → X)
    (t : Fin d → ℝ), (∀ i, ‖f i‖ ≤ 1) → (∀ i, ‖u i‖ ≤ 1) → (∀ i, t i ∈ Set.Icc (0 : ℝ) 1) →
    ∀ x, ‖chainApply f u t x‖ ≤ ‖x‖
  | 0, _, _, _, _, _, _, x => le_rfl
  | d + 1, f, u, t, hf, hu, ht, x => by
    rw [chainApply_succ]
    refine (norm_substOp_le (hf 0) (hu 0) (ht 0).1 (ht 0).2 _).trans ?_
    exact norm_chainApply_le (Fin.tail f) (Fin.tail u) (Fin.tail t) (fun i => hf _)
      (fun i => hu _) (fun i => ht _) x

lemma chainApply_eq_self : ∀ {d : ℕ} (f : Fin d → StrongDual 𝕜 X) (u : Fin d → X)
    (t : Fin d → ℝ), (∀ i, t i = 0) → ∀ x, chainApply f u t x = x
  | 0, _, _, _, _, _ => rfl
  | d + 1, f, u, t, ht, x => by
    rw [chainApply_succ, ht 0, substOp_zero]
    exact chainApply_eq_self _ _ _ (fun i => ht _) x

lemma chainApply_single : ∀ {d : ℕ} (f : Fin d → StrongDual 𝕜 X) (u : Fin d → X)
    (t : Fin d → ℝ) (j : Fin d), (∀ h, h ≠ j → t h = 0) → ∀ x,
    chainApply f u t x = substOp (f j) (u j) (t j) x
  | 0, _, _, _, j, _, _ => Fin.elim0 j
  | d + 1, f, u, t, j, ht, x => by
    rw [chainApply_succ]
    induction j using Fin.cases with
    | zero =>
      rw [chainApply_eq_self (Fin.tail f) (Fin.tail u) (Fin.tail t)
        (fun i => ht i.succ (Fin.succ_ne_zero i))]
    | succ j' =>
      have h0 : t 0 = 0 := ht 0 (Fin.succ_ne_zero j').symm
      rw [h0, substOp_zero]
      exact chainApply_single (Fin.tail f) (Fin.tail u) (Fin.tail t) j'
        (fun h hh => ht _ (fun e => hh (Fin.succ_injective _ e))) x

lemma chainApply_pair : ∀ {d : ℕ} (f : Fin d → StrongDual 𝕜 X) (u : Fin d → X)
    (t : Fin d → ℝ) (i j : Fin d), i < j → (∀ h, h ≠ i → h ≠ j → t h = 0) → ∀ x,
    chainApply f u t x = substOp (f i) (u i) (t i) (substOp (f j) (u j) (t j) x)
  | 0, _, _, _, i, _, _, _, _ => Fin.elim0 i
  | d + 1, f, u, t, i, j, hij, ht, x => by
    rw [chainApply_succ]
    induction i using Fin.cases with
    | zero =>
      induction j using Fin.cases with
      | zero => exact absurd hij (lt_irrefl _)
      | succ j' =>
        rw [chainApply_single (Fin.tail f) (Fin.tail u) (Fin.tail t) j'
          (fun h hh => ht _ (Fin.succ_ne_zero h) (fun e => hh (Fin.succ_injective _ e))) x]
        rfl
    | succ i' =>
      induction j using Fin.cases with
      | zero => exact absurd hij (not_lt.mpr (Fin.zero_le _))
      | succ j' =>
        have h0 : t 0 = 0 := ht 0 (Fin.succ_ne_zero i').symm (Fin.succ_ne_zero j').symm
        rw [h0, substOp_zero]
        exact chainApply_pair (Fin.tail f) (Fin.tail u) (Fin.tail t) i' j'
          (Fin.succ_lt_succ_iff.mp hij)
          (fun h hi hj => ht _ (fun e => hi (Fin.succ_injective _ e))
            (fun e => hj (Fin.succ_injective _ e))) x

/-- The points {lit}`z₀,…,z_{d-1}, z_d` of the proof of Lemma {lit}`lem:geometry`:
{lit}`zᵢ = fᵢ(x) uᵢ` for {lit}`i < d` and {lit}`z_d = x`. -/
def zv {d : ℕ} (f : Fin d → StrongDual 𝕜 X) (u : Fin d → X) (x : X) : Fin (d + 1) → X :=
  Fin.lastCases x (fun j => f j x • u j)

@[simp] lemma zv_last {d : ℕ} (f : Fin d → StrongDual 𝕜 X) (u : Fin d → X) (x : X) :
    zv f u x (Fin.last d) = x := by simp [zv]

@[simp] lemma zv_castSucc {d : ℕ} (f : Fin d → StrongDual 𝕜 X) (u : Fin d → X) (x : X)
    (j : Fin d) : zv f u x j.castSucc = f j x • u j := by simp [zv]

lemma zv_zero {d : ℕ} (f : Fin (d + 1) → StrongDual 𝕜 X) (u : Fin (d + 1) → X) (x : X) :
    zv f u x 0 = f 0 x • u 0 := by
  have : (0 : Fin (d + 2)) = (0 : Fin (d + 1)).castSucc := rfl
  rw [this, zv_castSucc]

lemma zv_succ {d : ℕ} (f : Fin (d + 1) → StrongDual 𝕜 X) (u : Fin (d + 1) → X) (x : X)
    (k : Fin (d + 1)) : zv f u x k.succ = zv (Fin.tail f) (Fin.tail u) x k := by
  induction k using Fin.lastCases with
  | last => rw [Fin.succ_last, zv_last, zv_last]
  | cast j => rw [Fin.succ_castSucc, zv_castSucc, zv_castSucc]; rfl

lemma norm_zv_le {d : ℕ} {f : Fin d → StrongDual 𝕜 X} {u : Fin d → X} {x : X}
    (hf : ∀ i, ‖f i‖ ≤ 1) (hu : ∀ i, ‖u i‖ ≤ 1) (hx : ‖x‖ ≤ 1) (k : Fin (d + 1)) :
    ‖zv f u x k‖ ≤ 1 := by
  induction k using Fin.lastCases with
  | last => rw [zv_last]; exact hx
  | cast j =>
    rw [zv_castSucc, norm_smul]
    calc ‖f j x‖ * ‖u j‖ ≤ (‖f j‖ * ‖x‖) * 1 := by
          gcongr
          · exact (f j).le_opNorm x
          · exact hu j
      _ ≤ (1 * 1) * 1 := by gcongr; exact hf j
      _ = 1 := by ring

/-- Comparison of the composed vectors with convex combinations of the points {lit}`zᵢ`
(equations {lit}`eq:convexdistance` and {lit}`eq:weights`): every convex combination of
{lit}`z₀,…,z_d` is within {lit}`d δ` of some composed vector. -/
theorem chain_approx : ∀ {d : ℕ} (f : Fin d → StrongDual 𝕜 X) (u : Fin d → X) (x : X)
    (δ : ℝ), 0 ≤ δ → (∀ i, ‖f i‖ ≤ 1) → (∀ i, ‖u i‖ ≤ 1) →
    (∀ i j : Fin d, i < j → ‖f i (f j x • u j) - f i x‖ ≤ δ) →
    ∀ θ : Fin (d + 1) → ℝ, (∀ k, 0 ≤ θ k) → ∑ k, θ k = 1 →
    ∃ t : Fin d → ℝ, (∀ i, t i ∈ Set.Icc (0 : ℝ) 1) ∧
      ‖chainApply f u t x - ∑ k, ((θ k : ℝ) : 𝕜) • zv f u x k‖ ≤ d * δ
  | 0, f, u, x, δ, _, _, _, _, θ, _, hsum => by
    refine ⟨fun i => Fin.elim0 i, fun i => Fin.elim0 i, ?_⟩
    have h0 : θ 0 = 1 := by simpa using hsum
    rw [Fin.sum_univ_one, h0, chainApply_zero, show (0 : Fin 1) = Fin.last 0 from rfl, zv_last]
    simp
  | d + 1, f, u, x, δ, hδ, hf, hu, hcomp, θ, hθ, hsum => by
    set θ0 := θ 0 with hθ0
    set θ' : Fin (d + 1) → ℝ := fun k => θ k.succ with hθ'
    have hsum' : ∑ k, θ' k = 1 - θ0 := by
      rw [Fin.sum_univ_succ] at hsum; simp only [θ']; linarith
    have hθ0le : θ0 ≤ 1 := by
      have : 0 ≤ ∑ k, θ' k := Finset.sum_nonneg fun k _ => hθ _
      linarith
    -- normalized weights
    set θ'' : Fin (d + 1) → ℝ := fun k =>
      if θ0 < 1 then θ' k / (1 - θ0) else (if k = Fin.last d then 1 else 0) with hθ''
    have hθ''nn : ∀ k, 0 ≤ θ'' k := by
      intro k
      by_cases h1 : θ0 < 1
      · simp only [θ'', ite_eq_left h1]
        exact div_nonneg (hθ _) (by linarith)
      · simp only [θ'', ite_eq_right h1]
        split_ifs
        · exact zero_le_one
        · exact le_rfl
    have hθ''sum : ∑ k, θ'' k = 1 := by
      by_cases h1 : θ0 < 1
      · simp only [θ'', ite_eq_left h1]
        rw [← Finset.sum_div, hsum', div_self (by linarith)]
      · simp only [θ'', ite_eq_right h1]
        simp
    have hθ'rel : ∀ k, θ' k = (1 - θ0) * θ'' k := by
      intro k
      by_cases h1 : θ0 < 1
      · simp only [θ'', ite_eq_left h1]
        have hne : (1 - θ0) ≠ 0 := (sub_pos.mpr h1).ne'
        field_simp
      · simp only [θ'', ite_eq_right h1]
        have h1' : θ0 = 1 := le_antisymm hθ0le (not_lt.mp h1)
        have hz : θ' k = 0 := by
          have hnn : ∀ k ∈ Finset.univ, 0 ≤ θ' k := fun k _ => hθ _
          have h0sum : ∑ k, θ' k = 0 := by rw [hsum', h1']; ring
          exact (Finset.sum_eq_zero_iff_of_nonneg hnn).mp h0sum k (Finset.mem_univ _)
        rw [hz, h1']; ring
    obtain ⟨t', ht', hdist⟩ := chain_approx (Fin.tail f) (Fin.tail u) x δ hδ
      (fun i => hf _) (fun i => hu _)
      (fun i j hij => hcomp _ _ (Fin.succ_lt_succ_iff.mpr hij)) θ'' hθ''nn hθ''sum
    refine ⟨Fin.cons θ0 t', ?_, ?_⟩
    · intro i
      induction i using Fin.cases with
      | zero => exact ⟨hθ _, hθ0le⟩
      | succ i => simpa using ht' i
    · set y := chainApply (Fin.tail f) (Fin.tail u) t' x with hy
      set v' := ∑ k, ((θ'' k : ℝ) : 𝕜) • zv (Fin.tail f) (Fin.tail u) x k with hv'
      have htarget : ∑ k, ((θ k : ℝ) : 𝕜) • zv f u x k =
          ((1 - θ0 : ℝ) : 𝕜) • v' + ((θ0 : ℝ) : 𝕜) • (f 0 x • u 0) := by
        rw [Fin.sum_univ_succ, zv_zero, hv', Finset.smul_sum]
        simp_rw [zv_succ, smul_smul, ← RCLike.ofReal_mul]
        rw [add_comm]
        congr 1
        refine Finset.sum_congr rfl fun k _ => ?_
        rw [← hθ'rel k]
      have hchain : chainApply f u (Fin.cons θ0 t') x = substOp (f 0) (u 0) θ0 y := by
        rw [chainApply_succ]
        simp [hy]
      rw [hchain, htarget]
      have hid : substOp (f 0) (u 0) θ0 y -
          (((1 - θ0 : ℝ) : 𝕜) • v' + ((θ0 : ℝ) : 𝕜) • (f 0 x • u 0)) =
          substOp (f 0) (u 0) θ0 (y - v') + ((θ0 : ℝ) : 𝕜) • ((f 0 v' - f 0 x) • u 0) := by
        simp only [substOp_apply, map_sub]
        module
      rw [hid]
      -- the defect `f₀(v') - f₀(x)`
      have hdefect : ‖f 0 v' - f 0 x‖ ≤ δ := by
        have hfx : f 0 x = ∑ k, ((θ'' k : ℝ) : 𝕜) * f 0 x := by
          rw [← Finset.sum_mul, ← RCLike.ofReal_sum, hθ''sum]; simp
        have hfv : f 0 v' = ∑ k, ((θ'' k : ℝ) : 𝕜) * f 0 (zv (Fin.tail f) (Fin.tail u) x k) := by
          rw [hv', map_sum]; simp
        rw [hfx, hfv, ← Finset.sum_sub_distrib]
        calc ‖∑ k, (((θ'' k : ℝ) : 𝕜) * f 0 (zv (Fin.tail f) (Fin.tail u) x k) -
              ((θ'' k : ℝ) : 𝕜) * f 0 x)‖
            ≤ ∑ k, ‖((θ'' k : ℝ) : 𝕜) * f 0 (zv (Fin.tail f) (Fin.tail u) x k) -
              ((θ'' k : ℝ) : 𝕜) * f 0 x‖ := norm_sum_le _ _
          _ ≤ ∑ k, θ'' k * δ := by
              gcongr with k
              rw [← mul_sub, norm_mul, RCLike.norm_ofReal, abs_of_nonneg (hθ''nn k)]
              apply mul_le_mul_of_nonneg_left _ (hθ''nn k)
              induction k using Fin.lastCases with
              | last => simpa using hδ
              | cast j =>
                rw [zv_castSucc]
                exact hcomp 0 j.succ (Fin.succ_pos j)
          _ = δ := by rw [← Finset.sum_mul, hθ''sum, one_mul]
      calc ‖substOp (f 0) (u 0) θ0 (y - v') + ((θ0 : ℝ) : 𝕜) • ((f 0 v' - f 0 x) • u 0)‖
          ≤ ‖substOp (f 0) (u 0) θ0 (y - v')‖ + ‖((θ0 : ℝ) : 𝕜) • ((f 0 v' - f 0 x) • u 0)‖ :=
            norm_add_le _ _
        _ ≤ ‖y - v'‖ + 1 * (δ * 1) := by
            gcongr
            · exact norm_substOp_le (hf 0) (hu 0) (hθ 0) hθ0le _
            · rw [norm_smul, norm_smul, RCLike.norm_ofReal, abs_of_nonneg (hθ 0)]
              gcongr
              · exact hu 0
        _ ≤ d * δ + δ := by linarith
        _ = ((d + 1 : ℕ) : ℝ) * δ := by push_cast; ring

end LindenstraussPolynomials
