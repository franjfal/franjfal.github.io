import LindenstraussPolynomials.Extension

/-!
# The substitutions and the averaging operators

For $`\|u\|=\|f\|=f(u)=1` and $`t\in[0,1]`, the substitution
$$`S_{u,f}(t)\,x = (1-t)\,x + t\,f(x)\,u`
({lit}`eq:substitution`) maps the unit ball into itself and fixes $`u`. Averaging a polynomial over these substitutions gives
$$`\mathcal R_{u,f}P(x) = \int_0^1 P\bigl(S_{u,f}(t)\,x\bigr)\,dt,`
and this module proves the properties of $`\mathcal R_{u,f}` the construction needs ({lit}`eq:Rproperties`, {lit}`eq:expansion`, {lit}`eq:Rfinite`).
-/

noncomputable section

open scoped BigOperators
open Finset

namespace LindenstraussPolynomials

variable {𝕜 : Type*} [RCLike 𝕜]
variable {X : Type*} [NormedAddCommGroup X] [NormedSpace 𝕜 X]
variable {Y : Type*} [NormedAddCommGroup Y] [NormedSpace 𝕜 Y]

/-- The substitution {lit}`S_{u,f}(t) x = (1-t) x + t f(x) u`. -/
def substOp (f : StrongDual 𝕜 X) (u : X) (t : ℝ) : X →L[𝕜] X :=
  (((1 - t : ℝ) : 𝕜)) • ContinuousLinearMap.id 𝕜 X + ((t : ℝ) : 𝕜) • f.smulRight u

lemma substOp_apply (f : StrongDual 𝕜 X) (u : X) (t : ℝ) (x : X) :
    substOp f u t x = ((1 - t : ℝ) : 𝕜) • x + ((t : ℝ) : 𝕜) • (f x • u) := by
  simp [substOp]

@[simp] lemma substOp_zero (f : StrongDual 𝕜 X) (u : X) (x : X) : substOp f u 0 x = x := by
  simp [substOp_apply]

lemma substOp_one (f : StrongDual 𝕜 X) (u : X) (x : X) : substOp f u 1 x = f x • u := by
  simp [substOp_apply]

lemma substOp_fix {f : StrongDual 𝕜 X} {u : X} (hfu : f u = 1) (t : ℝ) :
    substOp f u t u = u := by
  rw [substOp_apply, hfu, one_smul, ← add_smul, ← RCLike.ofReal_add]
  simp

/-- {lit}`S_{u,f}(t)` is a contraction when {lit}`‖f‖, ‖u‖ ≤ 1` and {lit}`t ∈ [0,1]`. -/
lemma norm_substOp_le {f : StrongDual 𝕜 X} {u : X} (hf : ‖f‖ ≤ 1) (hu : ‖u‖ ≤ 1) {t : ℝ}
    (ht0 : 0 ≤ t) (ht1 : t ≤ 1) (x : X) : ‖substOp f u t x‖ ≤ ‖x‖ := by
  rw [substOp_apply]
  calc ‖((1 - t : ℝ) : 𝕜) • x + ((t : ℝ) : 𝕜) • (f x • u)‖
      ≤ ‖((1 - t : ℝ) : 𝕜) • x‖ + ‖((t : ℝ) : 𝕜) • (f x • u)‖ := norm_add_le _ _
    _ = (1 - t) * ‖x‖ + t * (‖f x‖ * ‖u‖) := by
        rw [norm_smul, norm_smul, norm_smul, RCLike.norm_ofReal, RCLike.norm_ofReal,
          abs_of_nonneg (by linarith), abs_of_nonneg ht0]
    _ ≤ (1 - t) * ‖x‖ + t * ‖x‖ := by
        gcongr
        calc ‖f x‖ * ‖u‖ ≤ ‖f x‖ * 1 := by gcongr
          _ = ‖f x‖ := mul_one _
          _ ≤ ‖f‖ * ‖x‖ := f.le_opNorm x
          _ ≤ 1 * ‖x‖ := by gcongr
          _ = ‖x‖ := one_mul _
    _ = ‖x‖ := by ring

lemma continuous_substOp_apply (f : StrongDual 𝕜 X) (u : X) (x : X) :
    Continuous fun t : ℝ => substOp f u t x := by
  simp only [substOp_apply]
  fun_prop

/-! ## Expansion of {lit}`A((1-t)x + t w, …)` -/

variable {n : ℕ}

lemma prod_ite_mem_const (s : Finset (Fin n)) (c d : 𝕜) :
    (∏ i, (if i ∈ s then c else d)) = c ^ s.card * d ^ (n - s.card) := by
  rw [Finset.prod_ite, Finset.prod_const, Finset.prod_const]
  congr 2
  · congr 1; ext i; simp
  · rw [Finset.filter_not, Finset.card_sdiff_of_subset (Finset.filter_subset _ _),
      Finset.card_univ, Fintype.card_fin]
    congr 2; ext i; simp

/-- {lit}`A((1-t)x + tw, …) = ∑_s (1-t)^{|s|} t^{n-|s|} A(s.piecewise x w)`. -/
lemma map_convex_expand (A : MLin 𝕜 X Y n) (x w : X) (c d : 𝕜) :
    A (fun _ => c • x + d • w) =
      ∑ s : Finset (Fin n), (c ^ s.card * d ^ (n - s.card)) •
        A (s.piecewise (fun _ => x) (fun _ => w)) := by
  classical
  have h1 : (fun _ : Fin n => c • x + d • w) = (fun _ => c • x) + (fun _ => d • w) := rfl
  rw [h1, A.map_add_univ]
  refine Finset.sum_congr rfl fun s _ => ?_
  have h2 : s.piecewise (fun _ : Fin n => c • x) (fun _ => d • w) =
      fun i => (if i ∈ s then c else d) • s.piecewise (fun _ : Fin n => x) (fun _ => w) i := by
    funext i
    by_cases hi : i ∈ s <;> simp [Finset.piecewise, hi]
  rw [h2, A.map_smul_univ, prod_ite_mem_const]

/-- {lit}`t ↦ Re A(S(t)y, …)` is a real polynomial of degree at most {lit}`n`. -/
lemma exists_poly_re (a : MLin 𝕜 X 𝕜 n) (f : StrongDual 𝕜 X) (u y : X) :
    ∃ p : Polynomial ℝ, p.natDegree ≤ n ∧
      ∀ t : ℝ, p.eval t = RCLike.re (a (fun _ => substOp f u t y)) := by
  classical
  set cs : Finset (Fin n) → 𝕜 := fun s => a (s.piecewise (fun _ => y) (fun _ => f y • u))
  refine ⟨∑ s : Finset (Fin n), Polynomial.C (RCLike.re (cs s)) *
      ((1 - Polynomial.X) ^ s.card * Polynomial.X ^ (n - s.card)), ?_, ?_⟩
  · apply Polynomial.natDegree_sum_le_of_forall_le
    intro s _
    refine (Polynomial.natDegree_C_mul_le _ _).trans ?_
    refine (Polynomial.natDegree_mul_le).trans ?_
    have h1 : ((1 - Polynomial.X : Polynomial ℝ) ^ s.card).natDegree ≤ s.card := by
      refine (Polynomial.natDegree_pow_le).trans ?_
      have : (1 - Polynomial.X : Polynomial ℝ).natDegree ≤ 1 := by
        refine (Polynomial.natDegree_sub_le _ _).trans ?_
        simp
      calc s.card * (1 - Polynomial.X : Polynomial ℝ).natDegree ≤ s.card * 1 := by gcongr
        _ = s.card := mul_one _
    have h2 : ((Polynomial.X : Polynomial ℝ) ^ (n - s.card)).natDegree ≤ n - s.card := by
      simp
    have h3 : s.card ≤ n := by
      simpa using Finset.card_le_univ s
    omega
  · intro t
    have hexp : (fun _ : Fin n => substOp f u t y) =
        fun _ => ((1 - t : ℝ) : 𝕜) • y + ((t : ℝ) : 𝕜) • (f y • u) := by
      funext; rw [substOp_apply]
    rw [hexp, map_convex_expand]
    simp only [Polynomial.eval_finsetSum, Polynomial.eval_mul, Polynomial.eval_C,
      Polynomial.eval_pow, Polynomial.eval_sub, Polynomial.eval_one, Polynomial.eval_X,
      map_sum, smul_eq_mul]
    refine Finset.sum_congr rfl fun s _ => ?_
    rw [← RCLike.ofReal_pow, ← RCLike.ofReal_pow, ← RCLike.ofReal_mul, RCLike.re_ofReal_mul]
    ring

/-! ## The averaging operator -/

/-- Beta-type weights {lit}`∫₀¹ (1-t)^k t^{n-k} dt`. -/
def betaW (n k : ℕ) : ℝ := ∫ t in (0 : ℝ)..1, (1 - t) ^ k * t ^ (n - k)

/-- The averaging operator {lit}`R_{u,f}` acting on symmetric forms: its diagonal is
{lit}`x ↦ ∫₀¹ P(S_{u,f}(t) x) dt` (see {lit}`diag_Rop`). -/
def Rop (u : X) (f : StrongDual 𝕜 X) (a : MLin 𝕜 X 𝕜 n) : MLin 𝕜 X 𝕜 n :=
  symmetrize (∑ s : Finset (Fin n), ((betaW n s.card : ℝ) : 𝕜) •
    a.compContinuousLinearMap (fun i => if i ∈ s then ContinuousLinearMap.id 𝕜 X
      else f.smulRight u))

lemma isSymm_Rop (u : X) (f : StrongDual 𝕜 X) (a : MLin 𝕜 X 𝕜 n) : IsSymm (Rop u f a) :=
  isSymm_symmetrize _

lemma continuous_diag_substOp (a : MLin 𝕜 X 𝕜 n) (f : StrongDual 𝕜 X) (u x : X) :
    Continuous fun t : ℝ => a (fun _ => substOp f u t x) :=
  a.cont.comp (continuous_pi fun _ => continuous_substOp_apply f u x)

/-- The diagonal of {lit}`R_{u,f} a` is {lit}`x ↦ ∫₀¹ a(S(t)x,…,S(t)x) dt`. -/
lemma diag_Rop (u : X) (f : StrongDual 𝕜 X) (a : MLin 𝕜 X 𝕜 n) (x : X) :
    diag (Rop u f a) x = ∫ t in (0 : ℝ)..1, a (fun _ => substOp f u t x) := by
  classical
  rw [Rop, diag_symmetrize, diag_apply]
  have hexp : ∀ t : ℝ, a (fun _ => substOp f u t x) =
      ∑ s : Finset (Fin n), ((((1 - t) ^ s.card * t ^ (n - s.card) : ℝ)) : 𝕜) *
        a (s.piecewise (fun _ => x) (fun _ => f x • u)) := by
    intro t
    have : (fun _ : Fin n => substOp f u t x) =
        fun _ => ((1 - t : ℝ) : 𝕜) • x + ((t : ℝ) : 𝕜) • (f x • u) := by
      funext; rw [substOp_apply]
    rw [this, map_convex_expand]
    refine Finset.sum_congr rfl fun s _ => ?_
    push_cast
    rfl
  simp_rw [hexp]
  rw [intervalIntegral.integral_finsetSum]
  · simp only [_root_.sum_apply, smul_apply,
      ContinuousMultilinearMap.compContinuousLinearMap_apply, smul_eq_mul]
    refine Finset.sum_congr rfl fun s _ => ?_
    rw [intervalIntegral.integral_mul_const, RCLike.intervalIntegral_ofReal, betaW]
    congr 2
    funext i
    by_cases hi : i ∈ s <;> simp [Finset.piecewise, hi]
  · intro s _
    apply Continuous.intervalIntegrable
    fun_prop

lemma norm_integral_diag_le (a : MLin 𝕜 X 𝕜 n) {f : StrongDual 𝕜 X} {u : X} (hf : ‖f‖ ≤ 1)
    (hu : ‖u‖ ≤ 1) {x : X} (hx : ‖x‖ ≤ 1) :
    ‖∫ t in (0 : ℝ)..1, a (fun _ => substOp f u t x)‖ ≤ polyNorm (diag a) := by
  have := intervalIntegral.norm_integral_le_of_norm_le_const (a := 0) (b := 1)
    (f := fun t => a (fun _ => substOp f u t x)) (C := polyNorm (diag a)) (by
      intro t ht
      rw [Set.uIoc_of_le zero_le_one] at ht
      exact norm_diag_le_polyNorm a ((norm_substOp_le hf hu ht.1.le ht.2 x).trans hx))
  simpa using this

/-- {lit}`‖R_{u,f} P‖ ≤ ‖P‖` ({lit}`eq:Rproperties`). -/
lemma polyNorm_Rop_le (a : MLin 𝕜 X 𝕜 n) {f : StrongDual 𝕜 X} {u : X} (hf : ‖f‖ ≤ 1)
    (hu : ‖u‖ ≤ 1) : polyNorm (diag (Rop u f a)) ≤ polyNorm (diag a) := by
  apply polyNorm_le (polyNorm_nonneg _)
  intro x hx
  rw [diag_Rop]
  exact norm_integral_diag_le a hf hu hx

/-- {lit}`R_{u,f} P (u) = P(u)` ({lit}`eq:Rproperties`). -/
lemma diag_Rop_fix (a : MLin 𝕜 X 𝕜 n) {f : StrongDual 𝕜 X} {u : X} (hfu : f u = 1) :
    diag (Rop u f a) u = diag a u := by
  rw [diag_Rop]
  simp only [substOp_fix hfu]
  simp

/-- The real part commutes with the integral. -/
lemma re_integral_diag (a : MLin 𝕜 X 𝕜 n) (f : StrongDual 𝕜 X) (u x : X) :
    RCLike.re (∫ t in (0 : ℝ)..1, a (fun _ => substOp f u t x)) =
      ∫ t in (0 : ℝ)..1, RCLike.re (a (fun _ => substOp f u t x)) := by
  have := ContinuousLinearMap.intervalIntegral_comp_comm (RCLike.reCLM (K := 𝕜))
    ((continuous_diag_substOp a f u x).intervalIntegrable (μ := MeasureTheory.volume) 0 1)
  simpa using this.symm

end LindenstraussPolynomials
