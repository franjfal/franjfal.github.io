import LindenstraussPolynomials.Geometry
import LindenstraussPolynomials.LemmaK
import LindenstraussPolynomials.Alpha
import LindenstraussPolynomials.Ultra

/-!
# The perturbation scheme

Starting from $`P_0=P`, the construction ({lit}`eq:viteration`) sets
$$`P_{k+1} = P_k + \alpha_k\,(\mathcal R_k p_k)\,w_k,\qquad p_k=y_k^*\circ P_k,\quad w_k=\frac{P_k(x_k)}{\|P_k(x_k)\|},`
where $`x_k` almost norms $`P_k`, $`f_k` is a norming functional of $`x_k`, and $`y_k^*` norms $`P_k(x_k)`. Polynomials are represented by their symmetric $`n`-linear forms. The module proves the norm increments ({lit}`eq:increment`) and bounds ({lit}`eq:normbounds`).
-/

noncomputable section

open scoped BigOperators Topology
open Finset Filter

namespace LindenstraussPolynomials

variable {𝕜 : Type*} [RCLike 𝕜]
variable {X : Type*} [NormedAddCommGroup X] [NormedSpace 𝕜 X]
variable {Y : Type*} [NormedAddCommGroup Y] [NormedSpace 𝕜 Y]
variable {d : ℕ}

/-- The data {lit}`(x_k, f_k, y_k^*)` chosen at a stage. -/
abbrev Choice (𝕜 X Y : Type*) [RCLike 𝕜] [NormedAddCommGroup X] [NormedSpace 𝕜 X]
    [NormedAddCommGroup Y] [NormedSpace 𝕜 Y] := X × StrongDual 𝕜 X × StrongDual 𝕜 Y

/-- Requirements on the choice made for {lit}`P` with tolerance {lit}`δ`. -/
structure Good (P : MLin 𝕜 X Y (d + 1)) (δ : ℝ) (t : Choice 𝕜 X Y) : Prop where
  norm_x : ‖t.1‖ = 1
  near : polyNorm (diag P) - δ ≤ ‖diag P t.1‖
  norm_f : ‖t.2.1‖ = 1
  f_x : t.2.1 t.1 = 1
  norm_g : ‖t.2.2‖ ≤ 1
  g_P : t.2.2 (diag P t.1) = ((‖diag P t.1‖ : ℝ) : 𝕜)

lemma exists_good [Nontrivial X] (P : MLin 𝕜 X Y (d + 1)) {δ : ℝ} (hδ : 0 < δ) :
    ∃ t : Choice 𝕜 X Y, Good P δ t := by
  -- a unit vector almost norming `P`
  have hx : ∃ x : X, ‖x‖ = 1 ∧ polyNorm (diag P) - δ ≤ ‖diag P x‖ := by
    obtain ⟨x0, hx0, hlt⟩ := exists_near_polyNorm (P := diag P) hδ
    by_cases h0 : x0 = 0
    · obtain ⟨e0, he0⟩ := exists_ne (0 : X)
      have he0p : 0 < ‖e0‖ := norm_pos_iff.mpr he0
      refine ⟨((‖e0‖⁻¹ : ℝ) : 𝕜) • e0, ?_, ?_⟩
      · rw [norm_smul, RCLike.norm_ofReal, abs_inv, abs_norm, inv_mul_cancel₀ he0p.ne']
      have : diag P (0 : X) = 0 := by
        simp only [diag_apply]; exact P.map_coord_zero 0 rfl
      · rw [h0, this, norm_zero] at hlt
        exact hlt.le.trans (norm_nonneg _)
    · have hpos : 0 < ‖x0‖ := norm_pos_iff.mpr h0
      refine ⟨((‖x0‖⁻¹ : ℝ) : 𝕜) • x0, ?_, ?_⟩
      · rw [norm_smul, RCLike.norm_ofReal, abs_inv, abs_norm, inv_mul_cancel₀ hpos.ne']
      · rw [diag_smul_arg, norm_smul, norm_pow, RCLike.norm_ofReal, abs_inv, abs_norm]
        have h1 : 1 ≤ (‖x0‖⁻¹) ^ (d + 1) := one_le_pow₀ (one_le_inv₀ hpos |>.mpr hx0)
        have h2 : ‖diag P x0‖ ≤ (‖x0‖⁻¹) ^ (d + 1) * ‖diag P x0‖ :=
          le_mul_of_one_le_left (norm_nonneg _) h1
        linarith
  obtain ⟨x, hxn, hxP⟩ := hx
  obtain ⟨f, hfn, hfx⟩ := exists_dual_vector 𝕜 x (by rw [← norm_ne_zero_iff, hxn]; norm_num)
  obtain ⟨g, hgn, hgP⟩ := exists_dual_vector'' 𝕜 (diag P x)
  exact ⟨(x, f, g), ⟨hxn, hxP, hfn, by simpa [hxn] using hfx, hgn, hgP⟩⟩

/-- The choice made at a stage. -/
def pick (P : MLin 𝕜 X Y (d + 1)) (δ : ℝ) : Choice 𝕜 X Y := Classical.epsilon (Good P δ)

lemma pick_good [Nontrivial X] (P : MLin 𝕜 X Y (d + 1)) {δ : ℝ} (hδ : 0 < δ) :
    Good P δ (pick P δ) :=
  Classical.epsilon_spec (exists_good P hδ)

/-- {lit}`w = P(x)/‖P(x)‖`. -/
def wvec (P : MLin 𝕜 X Y (d + 1)) (t : Choice 𝕜 X Y) : Y :=
  ((‖diag P t.1‖⁻¹ : ℝ) : 𝕜) • diag P t.1

/-- One step of the construction ({lit}`eq:viteration`). -/
def stepMap (α δ : ℝ) (P : MLin 𝕜 X Y (d + 1)) : MLin 𝕜 X Y (d + 1) :=
  P + ((α : ℝ) : 𝕜) • (Rop (pick P δ).1 (pick P δ).2.1
    ((pick P δ).2.2.compContinuousMultilinearMap P)).smulRight (wvec P (pick P δ))

/-- The sequence {lit}`P_k`. -/
def seqP (A : MLin 𝕜 X Y (d + 1)) (a : ℝ) : ℕ → MLin 𝕜 X Y (d + 1)
  | 0 => A
  | k + 1 => stepMap (alpha a k) (alpha a k ^ 2) (seqP A a k)

variable (A : MLin 𝕜 X Y (d + 1)) (a : ℝ)

/-- {lit}`M_k = ‖P_k‖`. -/
def seqM (k : ℕ) : ℝ := polyNorm (diag (seqP A a k))
/-- The choice at stage {lit}`k`. -/
def seqT (k : ℕ) : Choice 𝕜 X Y := pick (seqP A a k) (alpha a k ^ 2)
/-- {lit}`x_k`. -/
def seqx (k : ℕ) : X := (seqT A a k).1
/-- {lit}`f_k`. -/
def seqf (k : ℕ) : StrongDual 𝕜 X := (seqT A a k).2.1
/-- {lit}`y_k^*`. -/
def seqg (k : ℕ) : StrongDual 𝕜 Y := (seqT A a k).2.2
/-- {lit}`w_k`. -/
def seqw (k : ℕ) : Y := wvec (seqP A a k) (seqT A a k)

lemma seqP_succ (k : ℕ) : seqP A a (k + 1) = seqP A a k + ((alpha a k : ℝ) : 𝕜) •
    (Rop (seqx A a k) (seqf A a k)
      ((seqg A a k).compContinuousMultilinearMap (seqP A a k))).smulRight (seqw A a k) := rfl

section facts

variable {A a}

lemma seq_good [Nontrivial X] (ha : 0 < a) (k : ℕ) :
    Good (seqP A a k) (alpha a k ^ 2) (seqT A a k) :=
  pick_good _ (pow_pos (alpha_pos ha k) 2)

lemma isSymm_seqP (hA : IsSymm A) : ∀ k, IsSymm (seqP A a k)
  | 0 => hA
  | k + 1 => by
    rw [seqP_succ]
    refine (isSymm_seqP hA k).add (IsSymm.smul _ ?_)
    intro σ v
    simp only [ContinuousMultilinearMap.smulRight_apply]
    rw [isSymm_Rop _ _ _ σ v]

lemma norm_seqx [Nontrivial X] (ha : 0 < a) (k : ℕ) : ‖seqx A a k‖ = 1 :=
  (seq_good ha k).norm_x

lemma norm_seqf [Nontrivial X] (ha : 0 < a) (k : ℕ) : ‖seqf A a k‖ = 1 :=
  (seq_good ha k).norm_f

lemma seqf_seqx [Nontrivial X] (ha : 0 < a) (k : ℕ) : seqf A a k (seqx A a k) = 1 :=
  (seq_good ha k).f_x

lemma norm_seqg [Nontrivial X] (ha : 0 < a) (k : ℕ) : ‖seqg A a k‖ ≤ 1 :=
  (seq_good ha k).norm_g

lemma norm_seqw_le (k : ℕ) : ‖seqw A a k‖ ≤ 1 := by
  unfold seqw wvec
  rw [norm_smul, RCLike.norm_ofReal, abs_inv, abs_norm]
  by_cases h : ‖diag (seqP A a k) (seqT A a k).1‖ = 0
  · rw [h]; simp
  · rw [inv_mul_cancel₀ h]

lemma polyNorm_comp_le {m : ℕ} (g : StrongDual 𝕜 Y) (P : MLin 𝕜 X Y m) :
    polyNorm (diag (g.compContinuousMultilinearMap P)) ≤ ‖g‖ * polyNorm (diag P) := by
  apply polyNorm_le (mul_nonneg (norm_nonneg _) (polyNorm_nonneg _))
  intro x hx
  simp only [diag_apply, ContinuousLinearMap.compContinuousMultilinearMap_coe,
    Function.comp_apply]
  calc ‖g (P fun _ => x)‖ ≤ ‖g‖ * ‖P fun _ => x‖ := g.le_opNorm _
    _ ≤ ‖g‖ * polyNorm (diag P) := by gcongr; exact norm_diag_le_polyNorm P hx

lemma polyNorm_smulRight_le {m : ℕ} (R : MLin 𝕜 X 𝕜 m) (w : Y) :
    polyNorm (diag (R.smulRight w)) ≤ polyNorm (diag R) * ‖w‖ := by
  apply polyNorm_le (mul_nonneg (polyNorm_nonneg _) (norm_nonneg _))
  intro x hx
  simp only [diag_apply, ContinuousMultilinearMap.smulRight_apply, norm_smul]
  gcongr
  exact norm_diag_le_polyNorm R hx

/-- {lit}`‖P_{k+1} - P_k‖ ≤ α_k M_k` ({lit}`eq:increment`). -/
lemma polyNorm_seq_increment [Nontrivial X] (ha : 0 < a) (k : ℕ) :
    polyNorm (diag (seqP A a (k + 1) - seqP A a k)) ≤ alpha a k * seqM A a k := by
  rw [seqP_succ, add_sub_cancel_left, polyNorm_diag_smul, RCLike.norm_ofReal,
    abs_of_pos (alpha_pos ha k)]
  apply mul_le_mul_of_nonneg_left _ (alpha_pos ha k).le
  calc polyNorm (diag ((Rop (seqx A a k) (seqf A a k)
          ((seqg A a k).compContinuousMultilinearMap (seqP A a k))).smulRight (seqw A a k)))
      ≤ polyNorm (diag (Rop (seqx A a k) (seqf A a k)
          ((seqg A a k).compContinuousMultilinearMap (seqP A a k)))) * ‖seqw A a k‖ :=
        polyNorm_smulRight_le _ _
    _ ≤ polyNorm (diag ((seqg A a k).compContinuousMultilinearMap (seqP A a k))) * 1 := by
        gcongr
        · exact polyNorm_nonneg _
        · exact polyNorm_Rop_le _ (norm_seqf ha k).le (norm_seqx ha k).le
        · exact norm_seqw_le k
    _ ≤ (‖seqg A a k‖ * seqM A a k) * 1 := by
        gcongr; exact polyNorm_comp_le _ _
    _ ≤ (1 * seqM A a k) * 1 := by
        gcongr
        · exact polyNorm_nonneg _
        · exact norm_seqg ha k
    _ = seqM A a k := by ring

/-- The value of {lit}`P_{k+1}` in terms of {lit}`P_k`. -/
lemma diag_seqP_succ (k : ℕ) (y : X) :
    diag (seqP A a (k + 1)) y = diag (seqP A a k) y + ((alpha a k : ℝ) : 𝕜) •
      ((∫ t in (0 : ℝ)..1, (seqg A a k).compContinuousMultilinearMap (seqP A a k)
          (fun _ => substOp (seqf A a k) (seqx A a k) t y)) • seqw A a k) := by
  rw [seqP_succ, diag_add, Pi.add_apply, diag_smul, Pi.smul_apply]
  congr 2
  simp only [diag_apply, ContinuousMultilinearMap.smulRight_apply]
  rw [← diag_apply, diag_Rop]

/-- {lit}`P_{k+1}(x_k) = (1 + α_k) P_k(x_k)`. -/
lemma diag_seqP_succ_seqx [Nontrivial X] (ha : 0 < a) (k : ℕ) :
    diag (seqP A a (k + 1)) (seqx A a k) =
      ((1 + alpha a k : ℝ) : 𝕜) • diag (seqP A a k) (seqx A a k) := by
  rw [seqP_succ, diag_add, Pi.add_apply, diag_smul, Pi.smul_apply]
  simp only [diag_apply, ContinuousMultilinearMap.smulRight_apply]
  rw [← diag_apply (Rop _ _ _), diag_Rop_fix _ (seqf_seqx ha k)]
  simp only [diag_apply, ContinuousLinearMap.compContinuousMultilinearMap_coe,
    Function.comp_apply]
  have hg' : (seqg A a k) (seqP A a k fun _ => seqx A a k) =
      ((‖seqP A a k fun _ => seqx A a k‖ : ℝ) : 𝕜) := (seq_good (A := A) ha k).g_P
  rw [hg']
  have hw : ((‖seqP A a k fun _ => seqx A a k‖ : ℝ) : 𝕜) • seqw A a k =
      seqP A a k fun _ => seqx A a k := by
    unfold seqw wvec
    rw [smul_smul, ← RCLike.ofReal_mul]
    by_cases h : ‖seqP A a k fun _ => seqx A a k‖ = 0
    · have h0 : (seqP A a k fun _ => seqx A a k) = 0 := norm_eq_zero.mp h
      simp only [diag_apply]
      rw [show (seqT A a k).1 = seqx A a k from rfl, h0, smul_zero]
    · simp only [diag_apply]
      rw [show (seqT A a k).1 = seqx A a k from rfl, mul_inv_cancel₀ h, RCLike.ofReal_one,
        one_smul]
  rw [hw]
  rw [show ((1 + alpha a k : ℝ) : 𝕜) = 1 + ((alpha a k : ℝ) : 𝕜) by push_cast; ring, add_smul,
    one_smul]

/-- {lit}`(1 + α_k)(M_k - α_k²) ≤ M_{k+1} ≤ (1 + α_k) M_k` ({lit}`eq:normbounds`). -/
lemma seqM_succ_bounds [Nontrivial X] (ha : 0 < a) (k : ℕ) :
    (1 + alpha a k) * (seqM A a k - alpha a k ^ 2) ≤ seqM A a (k + 1) ∧
      seqM A a (k + 1) ≤ (1 + alpha a k) * seqM A a k := by
  have hα := alpha_pos ha k
  constructor
  · have h1 := norm_diag_le_polyNorm (seqP A a (k + 1)) (norm_seqx (A := A) ha k).le
    rw [diag_seqP_succ_seqx ha, norm_smul, RCLike.norm_ofReal, abs_of_pos (by linarith)] at h1
    have h2 := (seq_good (A := A) ha k).near
    change seqM A a k - alpha a k ^ 2 ≤ ‖diag (seqP A a k) (seqx A a k)‖ at h2
    calc (1 + alpha a k) * (seqM A a k - alpha a k ^ 2)
        ≤ (1 + alpha a k) * ‖diag (seqP A a k) (seqx A a k)‖ := by gcongr
      _ ≤ seqM A a (k + 1) := h1
  · have h1 := polyNorm_diag_sub_le (seqP A a (k + 1)) (seqP A a k)
    have h2 := polyNorm_seq_increment (A := A) ha k
    unfold seqM at *
    nlinarith

/-- {lit}`M_k ≥ 1` for every {lit}`k`. -/
lemma one_le_seqM [Nontrivial X] (hA1 : polyNorm (diag A) = 1) (ha : 0 < a) (ha8 : a < 1 / 8) :
    ∀ k, 1 ≤ seqM A a k
  | 0 => by simp [seqM, seqP, hA1]
  | k + 1 => by
    have ih := one_le_seqM hA1 ha ha8 k
    have hα := alpha_pos ha k
    have hα8 : alpha a k < 1 / 8 := (alpha_le ha.le (by linarith) k).trans_lt ha8
    have := (seqM_succ_bounds (A := A) ha k).1
    nlinarith

/-- {lit}`M_k ≤ ∏_{h<k} (1 + α_h) = (1-α_k)/(1-a)` ({lit}`eq:product`). -/
lemma seqM_le_prod [Nontrivial X] (hA1 : polyNorm (diag A) = 1) (ha : 0 < a) :
    ∀ k, seqM A a k ≤ ∏ h ∈ range k, (1 + alpha a h)
  | 0 => by simp [seqM, seqP, hA1]
  | k + 1 => by
    rw [Finset.prod_range_succ]
    have := (seqM_succ_bounds (A := A) ha k).2
    have ih := seqM_le_prod hA1 ha k
    have hα := alpha_pos ha k
    nlinarith

lemma seqM_le [Nontrivial X] (hA1 : polyNorm (diag A) = 1) (ha : 0 < a) (ha1 : a < 1) (k : ℕ) :
    seqM A a k ≤ 1 / (1 - a) := by
  have h1 := seqM_le_prod hA1 ha k
  have h2 := prod_one_add_alpha a k
  have h3 : 0 < 1 - a := by linarith
  rw [le_div_iff₀ h3]
  have := alpha_pos ha k
  nlinarith

end facts

end LindenstraussPolynomials
