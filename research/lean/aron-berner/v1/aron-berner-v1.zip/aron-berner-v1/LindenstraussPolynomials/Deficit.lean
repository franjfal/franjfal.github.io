import LindenstraussPolynomials.Limit

/-!
# Deficits

The deficits $`d_k^g(y)=M_k-\operatorname{Re}g(P_k\,y)` and the losses $`\lambda_k=(1+\alpha_k)M_k-M_{k+1}` satisfy an exact identity under the perturbation ({lit}`eq:vdeficit`); from it come the backward estimate ({lit}`eq:vbackward`), the insertion estimate ({lit}`eq:vinsert`) and the bound on the losses ({lit}`eq:loss`).
-/

noncomputable section

open scoped BigOperators Topology
open Finset Filter

namespace LindenstraussPolynomials

variable {𝕜 : Type*} [RCLike 𝕜]
variable {X : Type*} [NormedAddCommGroup X] [NormedSpace 𝕜 X]
variable {Y : Type*} [NormedAddCommGroup Y] [NormedSpace 𝕜 Y]
variable {d : ℕ}

/-- The constant {lit}`K_n` of Lemma K. -/
def Kc (n : ℕ) : ℝ := Classical.choose (lemmaK n)

lemma one_le_Kc (n : ℕ) : 1 ≤ Kc n := (Classical.choose_spec (lemmaK n)).1

lemma Kc_spec (n : ℕ) : ∀ r : Polynomial ℝ, r.natDegree ≤ n →
    (∀ t ∈ Set.Icc (0 : ℝ) 1, 0 ≤ r.eval t) →
    ∀ t ∈ Set.Icc (0 : ℝ) 1, r.eval t ≤ Kc n * ∫ s in (0 : ℝ)..1, r.eval s :=
  (Classical.choose_spec (lemmaK n)).2

variable (A : MLin 𝕜 X Y (d + 1)) (a : ℝ)

/-- The deficit {lit}`d_k^g(y) = M_k - Re g(P_k(y))`. -/
def defc (k : ℕ) (g : StrongDual 𝕜 Y) (y : X) : ℝ :=
  seqM A a k - RCLike.re (g (diag (seqP A a k) y))

/-- The loss {lit}`λ_k = (1 + α_k) M_k - M_{k+1}`. -/
def lam (k : ℕ) : ℝ := (1 + alpha a k) * seqM A a k - seqM A a (k + 1)

variable {A a}

lemma defc_nonneg (k : ℕ) {g : StrongDual 𝕜 Y} (hg : ‖g‖ ≤ 1) {y : X} (hy : ‖y‖ ≤ 1) :
    0 ≤ defc A a k g y := by
  unfold defc seqM
  have h1 := RCLike.re_le_norm (g (diag (seqP A a k) y))
  have h2 := g.le_opNorm (diag (seqP A a k) y)
  have h3 := norm_diag_le_polyNorm (seqP A a k) hy
  have h4 : ‖g‖ * ‖diag (seqP A a k) y‖ ≤ 1 * polyNorm (diag (seqP A a k)) :=
    mul_le_mul hg h3 (norm_nonneg _) zero_le_one
  linarith

lemma lam_nonneg [Nontrivial X] (ha : 0 < a) (k : ℕ) : 0 ≤ lam A a k := by
  have := (seqM_succ_bounds (A := A) ha k).2
  unfold lam; linarith

lemma lam_le [Nontrivial X] (ha : 0 < a) (ha1 : a ≤ 1) (k : ℕ) :
    lam A a k ≤ 2 * alpha a k ^ 2 := by
  have h := (seqM_succ_bounds (A := A) ha k).1
  have hα := alpha_pos ha k
  have hα1 := alpha_le ha.le ha1 k
  unfold lam
  nlinarith

lemma sum_lam_le [Nontrivial X] (ha : 0 < a) (ha2 : a ≤ 1 / 2) (k N : ℕ) :
    ∑ i ∈ range N, lam A a (k + i) ≤ 4 * alpha a k ^ 2 := by
  calc ∑ i ∈ range N, lam A a (k + i) ≤ ∑ i ∈ range N, 2 * alpha a (k + i) ^ 2 :=
        Finset.sum_le_sum fun i _ => lam_le ha (by linarith) _
    _ = 2 * ∑ i ∈ range N, alpha a (k + i) ^ 2 := by rw [Finset.mul_sum]
    _ ≤ 2 * (2 * alpha a k ^ 2) := by gcongr; exact sum_alpha_sq_le ha.le ha2 k N
    _ = 4 * alpha a k ^ 2 := by ring

/-- The modified functional {lit}`g(w_k) y_k^*`. -/
def nextG (A : MLin 𝕜 X Y (d + 1)) (a : ℝ) (k : ℕ) (g : StrongDual 𝕜 Y) : StrongDual 𝕜 Y :=
  g (seqw A a k) • seqg A a k

lemma norm_nextG_le [Nontrivial X] (ha : 0 < a) (k : ℕ) {g : StrongDual 𝕜 Y} (hg : ‖g‖ ≤ 1) :
    ‖nextG A a k g‖ ≤ 1 := by
  unfold nextG
  rw [norm_smul]
  have h1 : ‖g (seqw A a k)‖ ≤ 1 :=
    (g.le_opNorm _).trans (by
      have := norm_seqw_le (A := A) (a := a) k
      nlinarith [norm_nonneg g, norm_nonneg (seqw A a k)])
  have h2 := norm_seqg (A := A) ha k
  nlinarith [norm_nonneg (g (seqw A a k)), norm_nonneg (seqg A a k)]

lemma continuous_defc_subst (k : ℕ) (g : StrongDual 𝕜 Y) (f : StrongDual 𝕜 X) (u y : X) :
    Continuous fun t : ℝ => defc A a k g (substOp f u t y) := by
  unfold defc
  have := continuous_diag_substOp (g.compContinuousMultilinearMap (seqP A a k)) f u y
  exact continuous_const.sub (RCLike.continuous_re.comp this)

/-- The exact identity {lit}`eq:vdeficit`. -/
lemma deficit_identity (k : ℕ) (g : StrongDual 𝕜 Y) (y : X) :
    defc A a k g y + alpha a k * ∫ t in (0 : ℝ)..1,
        defc A a k (nextG A a k g) (substOp (seqf A a k) (seqx A a k) t y) =
      defc A a (k + 1) g y + lam A a k := by
  set a' := (nextG A a k g).compContinuousMultilinearMap (seqP A a k) with ha'
  have hint : ∫ t in (0 : ℝ)..1,
      defc A a k (nextG A a k g) (substOp (seqf A a k) (seqx A a k) t y) =
      seqM A a k - RCLike.re (∫ t in (0 : ℝ)..1,
        a' (fun _ => substOp (seqf A a k) (seqx A a k) t y)) := by
    rw [re_integral_diag]
    have hfun : (fun t : ℝ =>
        defc A a k (nextG A a k g) (substOp (seqf A a k) (seqx A a k) t y)) =
        fun t => seqM A a k - RCLike.re (a' (fun _ => substOp (seqf A a k) (seqx A a k) t y)) := by
      funext t; simp [defc, ha', diag_apply]
    have hi : IntervalIntegrable
        (fun t : ℝ => RCLike.re (a' (fun _ => substOp (seqf A a k) (seqx A a k) t y)))
        MeasureTheory.volume 0 1 :=
      (RCLike.continuous_re.comp (continuous_diag_substOp a' _ _ y)).intervalIntegrable _ _
    rw [hfun, intervalIntegral.integral_sub intervalIntegrable_const hi]
    simp
  have hval : g (diag (seqP A a (k + 1)) y) = g (diag (seqP A a k) y) +
      ((alpha a k : ℝ) : 𝕜) * ∫ t in (0 : ℝ)..1,
        a' (fun _ => substOp (seqf A a k) (seqx A a k) t y) := by
    rw [diag_seqP_succ, map_add, map_smul, map_smul, smul_eq_mul, smul_eq_mul]
    congr 2
    rw [ha']
    simp only [ContinuousLinearMap.compContinuousMultilinearMap_coe, Function.comp_apply,
      nextG, smul_apply, smul_eq_mul]
    rw [intervalIntegral.integral_const_mul, mul_comm]
  rw [hint]
  unfold defc lam
  rw [hval, map_add, RCLike.re_ofReal_mul]
  ring

lemma integral_defc_nonneg [Nontrivial X] (ha : 0 < a) (k : ℕ) {g : StrongDual 𝕜 Y}
    (hg : ‖g‖ ≤ 1) {y : X} (hy : ‖y‖ ≤ 1) :
    0 ≤ ∫ t in (0 : ℝ)..1,
        defc A a k (nextG A a k g) (substOp (seqf A a k) (seqx A a k) t y) := by
  apply intervalIntegral.integral_nonneg zero_le_one
  intro t ht
  exact defc_nonneg k (norm_nextG_le ha k hg)
    ((norm_substOp_le (norm_seqf ha k).le (norm_seqx ha k).le ht.1 ht.2 y).trans hy)

/-- {lit}`eq:vbackward`. -/
lemma defc_backward [Nontrivial X] (ha : 0 < a) (k : ℕ) {g : StrongDual 𝕜 Y}
    (hg : ‖g‖ ≤ 1) {y : X} (hy : ‖y‖ ≤ 1) :
    defc A a k g y ≤ defc A a (k + 1) g y + lam A a k := by
  have h := deficit_identity (A := A) (a := a) k g y
  have h2 := integral_defc_nonneg (A := A) ha k hg hy
  have h3 := alpha_pos ha k
  nlinarith

/-- {lit}`eq:vinsert`. -/
lemma defc_insert [Nontrivial X] (ha : 0 < a) (k : ℕ) {g : StrongDual 𝕜 Y}
    (hg : ‖g‖ ≤ 1) {y : X} (hy : ‖y‖ ≤ 1) {t : ℝ} (ht : t ∈ Set.Icc (0 : ℝ) 1) :
    defc A a k (nextG A a k g) (substOp (seqf A a k) (seqx A a k) t y) ≤
      Kc (d + 1) / alpha a k * (defc A a (k + 1) g y + lam A a k) := by
  set a' := (nextG A a k g).compContinuousMultilinearMap (seqP A a k) with ha'
  obtain ⟨p, hpdeg, hp⟩ := exists_poly_re a' (seqf A a k) (seqx A a k) y
  set r : Polynomial ℝ := Polynomial.C (seqM A a k) - p with hr
  have hreval : ∀ s, r.eval s =
      defc A a k (nextG A a k g) (substOp (seqf A a k) (seqx A a k) s y) := by
    intro s
    rw [hr, Polynomial.eval_sub, Polynomial.eval_C, hp]
    simp [defc, ha', diag_apply]
  have hrdeg : r.natDegree ≤ d + 1 :=
    (Polynomial.natDegree_sub_le _ _).trans (by simp [hpdeg])
  have hrnn : ∀ s ∈ Set.Icc (0 : ℝ) 1, 0 ≤ r.eval s := by
    intro s hs
    rw [hreval]
    exact defc_nonneg k (norm_nextG_le ha k hg)
      ((norm_substOp_le (norm_seqf ha k).le (norm_seqx ha k).le hs.1 hs.2 y).trans hy)
  have hK := Kc_spec (d + 1) r hrdeg hrnn t ht
  simp only [hreval] at hK
  have hid := deficit_identity (A := A) (a := a) k g y
  have h0 := defc_nonneg (A := A) (a := a) k hg hy
  have hα := alpha_pos ha k
  have hKpos : 0 ≤ Kc (d + 1) := (zero_le_one).trans (one_le_Kc _)
  have hI : ∫ s in (0 : ℝ)..1,
      defc A a k (nextG A a k g) (substOp (seqf A a k) (seqx A a k) s y) ≤
      (defc A a (k + 1) g y + lam A a k) / alpha a k := by
    rw [le_div_iff₀ hα]; nlinarith
  calc _ ≤ Kc (d + 1) * ∫ s in (0 : ℝ)..1,
        defc A a k (nextG A a k g) (substOp (seqf A a k) (seqx A a k) s y) := hK
    _ ≤ Kc (d + 1) * ((defc A a (k + 1) g y + lam A a k) / alpha a k) :=
        mul_le_mul_of_nonneg_left hI hKpos
    _ = _ := by ring

/-- Iterating {lit}`eq:vbackward`: {lit}`d_k^g(y) ≤ d_{k+N}^g(y) + 4 α_k²`. -/
lemma defc_backward_iter [Nontrivial X] (ha : 0 < a) (ha2 : a ≤ 1 / 2) (k N : ℕ)
    {g : StrongDual 𝕜 Y} (hg : ‖g‖ ≤ 1) {y : X} (hy : ‖y‖ ≤ 1) :
    defc A a k g y ≤ defc A a (k + N) g y + 4 * alpha a k ^ 2 := by
  have key : defc A a k g y ≤ defc A a (k + N) g y + ∑ i ∈ range N, lam A a (k + i) := by
    induction N with
    | zero => simp
    | succ N ih =>
      rw [Finset.sum_range_succ]
      have := defc_backward (A := A) ha (k + N) hg hy
      rw [show k + (N + 1) = k + N + 1 by ring]
      linarith
  linarith [sum_lam_le (A := A) ha ha2 k N]

end LindenstraussPolynomials
