import LindenstraussPolynomials.Polarization

/-!
# The canonical (Aron–Berner) extension

For $`z\in X^{**}` and a continuous $`(m+1)`-linear form $`C` on $`X`, one step of the extension is the $`m`-linear form
$$`(v_1,\ldots,v_m)\longmapsto z\bigl(v\mapsto C(v_1,\ldots,v_m,v)\bigr)`
({lit}`eq:partial`). Iterating it $`n` times extends the last variable first and gives $`\overline A(z,\ldots,z)`, the value at the diagonal point of the canonical extension ({lit}`eq:arens`, {lit}`eq:AB`). For a vector-valued polynomial the extension $`\widetilde P\colon X^{**}\to Y^{**}` is defined by $`\widetilde P(z)(y^*)=\widetilde{y^*\circ P}(z)` ({lit}`eq:ABvector`).
-/

noncomputable section

open scoped BigOperators
open Finset

namespace LindenstraussPolynomials

variable {𝕜 : Type*} [RCLike 𝕜]
variable {X : Type*} [NormedAddCommGroup X] [NormedSpace 𝕜 X]
variable {Y : Type*} [NormedAddCommGroup Y] [NormedSpace 𝕜 Y]

/-- The bidual {lit}`X**`. -/
abbrev Bidual (𝕜 : Type*) [RCLike 𝕜] (X : Type*) [NormedAddCommGroup X] [NormedSpace 𝕜 X] :=
  StrongDual 𝕜 (StrongDual 𝕜 X)

/-- One step of the canonical extension ({lit}`eq:partial`):
{lit}`(extLast z C)(v₁,…,vₘ) = z (v ↦ C(v₁,…,vₘ,v))`. -/
def extLast (z : Bidual 𝕜 X) {m : ℕ} (C : MLin 𝕜 X 𝕜 (m + 1)) : MLin 𝕜 X 𝕜 m :=
  z.compContinuousMultilinearMap C.curryRight

lemma extLast_apply (z : Bidual 𝕜 X) {m : ℕ} (C : MLin 𝕜 X 𝕜 (m + 1)) (v : Fin m → X) :
    extLast z C v = z (C.curryRight v) := rfl

lemma curryRight_apply' {m : ℕ} (C : MLin 𝕜 X 𝕜 (m + 1)) (v : Fin m → X) (x : X) :
    C.curryRight v x = C (Fin.snoc v x) := ContinuousMultilinearMap.curryRight_apply _ _ _

lemma extLast_add (z : Bidual 𝕜 X) {m : ℕ} (C D : MLin 𝕜 X 𝕜 (m + 1)) :
    extLast z (C + D) = extLast z C + extLast z D := by
  ext v
  simp only [extLast_apply, add_apply]
  rw [← map_add]
  congr 1

lemma extLast_smul (z : Bidual 𝕜 X) {m : ℕ} (c : 𝕜) (C : MLin 𝕜 X 𝕜 (m + 1)) :
    extLast z (c • C) = c • extLast z C := by
  ext v
  simp only [extLast_apply, smul_apply, smul_eq_mul]
  rw [← smul_eq_mul, ← map_smul]
  congr 1

lemma norm_extLast_le (z : Bidual 𝕜 X) {m : ℕ} (C : MLin 𝕜 X 𝕜 (m + 1)) :
    ‖extLast z C‖ ≤ ‖z‖ * ‖C‖ := by
  unfold extLast
  refine (ContinuousLinearMap.norm_compContinuousMultilinearMap_le _ _).trans ?_
  rw [ContinuousMultilinearMap.curryRight_norm]

/-- The value {lit}`Ā(z,…,z)` of the canonical extension of an {lit}`m`-linear form at the diagonal. -/
def diagExt (z : Bidual 𝕜 X) : ∀ {m : ℕ}, MLin 𝕜 X 𝕜 m → 𝕜
  | 0, C => C (fun i => Fin.elim0 i)
  | _ + 1, C => diagExt z (extLast z C)

@[simp] lemma diagExt_zero (z : Bidual 𝕜 X) (C : MLin 𝕜 X 𝕜 0) :
    diagExt z C = C (fun i => Fin.elim0 i) := rfl

@[simp] lemma diagExt_succ (z : Bidual 𝕜 X) {m : ℕ} (C : MLin 𝕜 X 𝕜 (m + 1)) :
    diagExt z C = diagExt z (extLast z C) := rfl

lemma diagExt_add (z : Bidual 𝕜 X) : ∀ {m : ℕ} (C D : MLin 𝕜 X 𝕜 m),
    diagExt z (C + D) = diagExt z C + diagExt z D
  | 0, C, D => by simp
  | m + 1, C, D => by
    simp only [diagExt_succ, extLast_add]
    exact diagExt_add z _ _

lemma diagExt_smul (z : Bidual 𝕜 X) : ∀ {m : ℕ} (c : 𝕜) (C : MLin 𝕜 X 𝕜 m),
    diagExt z (c • C) = c * diagExt z C
  | 0, c, C => by simp
  | m + 1, c, C => by
    simp only [diagExt_succ, extLast_smul]
    exact diagExt_smul z c _

lemma diagExt_sub (z : Bidual 𝕜 X) {m : ℕ} (C D : MLin 𝕜 X 𝕜 m) :
    diagExt z (C - D) = diagExt z C - diagExt z D := by
  rw [sub_eq_add_neg, diagExt_add, ← neg_one_smul 𝕜 D, diagExt_smul]; ring

/-- {lit}`|Ā(z,…,z)| ≤ ‖A‖ ‖z‖^m`. -/
lemma norm_diagExt_le (z : Bidual 𝕜 X) : ∀ {m : ℕ} (C : MLin 𝕜 X 𝕜 m),
    ‖diagExt z C‖ ≤ ‖C‖ * ‖z‖ ^ m
  | 0, C => by
    simp only [diagExt_zero, pow_zero, mul_one]
    simp
  | m + 1, C => by
    simp only [diagExt_succ]
    refine (norm_diagExt_le z (extLast z C)).trans ?_
    calc ‖extLast z C‖ * ‖z‖ ^ m ≤ (‖z‖ * ‖C‖) * ‖z‖ ^ m := by
          gcongr; exact norm_extLast_le z C
      _ = ‖C‖ * ‖z‖ ^ (m + 1) := by ring

omit [NormedAddCommGroup X] in
lemma snoc_const {m : ℕ} (x : X) : (Fin.snoc (fun _ : Fin m => x) x : Fin (m + 1) → X) =
    fun _ => x := by
  funext i
  refine Fin.lastCases ?_ (fun j => ?_) i
  · simp
  · simp

/-- The canonical extension extends: {lit}`Ā(Jx,…,Jx) = A(x,…,x)`. -/
lemma diagExt_inclusion (x : X) : ∀ {m : ℕ} (C : MLin 𝕜 X 𝕜 m),
    diagExt (NormedSpace.inclusionInDoubleDual 𝕜 X x) C = C (fun _ => x)
  | 0, C => by
    simp only [diagExt_zero]
    congr 1
    funext i; exact Fin.elim0 i
  | m + 1, C => by
    simp only [diagExt_succ]
    rw [diagExt_inclusion x (extLast _ C), extLast_apply,
      NormedSpace.dual_def, curryRight_apply', snoc_const]

/-- The vector-valued canonical extension at the diagonal ({lit}`eq:ABvector`):
{lit}`(diagExtV z A)(y*) = (y* ∘ A)‾(z,…,z)`. -/
def diagExtV (z : Bidual 𝕜 X) {n : ℕ} (A : MLin 𝕜 X Y n) : Bidual 𝕜 Y :=
  LinearMap.mkContinuous
    { toFun := fun g => diagExt z (g.compContinuousMultilinearMap A)
      map_add' := fun g h => by
        rw [← diagExt_add]
        congr 1
      map_smul' := fun c g => by
        simp only [RingHom.id_apply, smul_eq_mul]
        rw [← diagExt_smul]
        congr 1 }
    (‖A‖ * ‖z‖ ^ n)
    (fun g => by
      simp only [LinearMap.coe_mk, AddHom.coe_mk]
      refine (norm_diagExt_le z _).trans ?_
      calc ‖g.compContinuousMultilinearMap A‖ * ‖z‖ ^ n ≤ (‖g‖ * ‖A‖) * ‖z‖ ^ n := by
            gcongr; exact ContinuousLinearMap.norm_compContinuousMultilinearMap_le _ _
        _ = ‖A‖ * ‖z‖ ^ n * ‖g‖ := by ring)

lemma diagExtV_apply (z : Bidual 𝕜 X) {n : ℕ} (A : MLin 𝕜 X Y n) (g : StrongDual 𝕜 Y) :
    diagExtV z A g = diagExt z (g.compContinuousMultilinearMap A) := rfl

/-! ## Polynomials as functions and their symmetric forms -/

/-- The symmetric {lit}`n`-linear form {lit}`Ǎ` associated with a homogeneous polynomial {lit}`P`
(the symmetrization of any {lit}`L` with {lit}`P = L(x,…,x)`; junk value {lit}`0` if {lit}`P` is not a
continuous {lit}`n`-homogeneous polynomial). -/
def symmForm (𝕜 : Type*) [RCLike 𝕜] {X : Type*} [NormedAddCommGroup X] [NormedSpace 𝕜 X]
    {Y : Type*} [NormedAddCommGroup Y] [NormedSpace 𝕜 Y] (n : ℕ) (P : X → Y) : MLin 𝕜 X Y n :=
  haveI := Classical.propDecidable (IsHomPoly 𝕜 n P)
  if h : IsHomPoly 𝕜 n P then symmetrize (Classical.choose h) else 0

variable {n : ℕ}

lemma isSymm_symmForm (P : X → Y) : IsSymm (symmForm 𝕜 n P) := by
  unfold symmForm
  split_ifs with h
  · exact isSymm_symmetrize _
  · exact IsSymm.zero

lemma diag_symmForm {P : X → Y} (hP : IsHomPoly 𝕜 n P) : diag (symmForm 𝕜 n P) = P := by
  unfold symmForm
  rw [dite_eq_left hP, diag_symmetrize]
  funext x
  exact (Classical.choose_spec hP x).symm

lemma isHomPoly_diag (A : MLin 𝕜 X Y n) : IsHomPoly 𝕜 n (diag A) := ⟨A, fun _ => rfl⟩

/-- The symmetric form is the unique symmetric {lit}`n`-linear map with diagonal {lit}`P`. -/
lemma symmForm_eq_of_isSymm {A : MLin 𝕜 X Y n} (hA : IsSymm A) :
    symmForm 𝕜 n (diag A) = A :=
  eq_of_diag_eq (isSymm_symmForm _) hA (diag_symmForm (isHomPoly_diag A))

lemma symmForm_comp {P : X → Y} (hP : IsHomPoly 𝕜 n P) (g : StrongDual 𝕜 Y) :
    symmForm 𝕜 n (fun x => g (P x)) = g.compContinuousMultilinearMap (symmForm 𝕜 n P) := by
  have h1 : (fun x => g (P x)) = diag (g.compContinuousMultilinearMap (symmForm 𝕜 n P)) := by
    funext x
    simp only [diag_apply, ContinuousLinearMap.compContinuousMultilinearMap_coe,
      Function.comp_apply]
    rw [← diag_apply, diag_symmForm hP]
  rw [h1, symmForm_eq_of_isSymm ((isSymm_symmForm P).comp g)]

/-- The canonical (Aron–Berner) extension {lit}`P̃ : X** → 𝕜` of a scalar polynomial {lit}`P`:
{lit}`P̃(z) = Ā(z,…,z)` with {lit}`A = Ǎ` ({lit}`eq:AB`). -/
def abExt (𝕜 : Type*) [RCLike 𝕜] {X : Type*} [NormedAddCommGroup X] [NormedSpace 𝕜 X]
    (n : ℕ) (P : X → 𝕜) (z : Bidual 𝕜 X) : 𝕜 :=
  diagExt z (symmForm 𝕜 n P)

/-- The canonical (Aron–Berner) extension {lit}`P̃ : X** → Y**` of a vector-valued polynomial:
{lit}`P̃(z)(y*) = (y* ∘ P)~(z)` ({lit}`eq:ABvector`); see {lit}`abExtV_apply`. -/
def abExtV (𝕜 : Type*) [RCLike 𝕜] {X : Type*} [NormedAddCommGroup X] [NormedSpace 𝕜 X]
    {Y : Type*} [NormedAddCommGroup Y] [NormedSpace 𝕜 Y]
    (n : ℕ) (P : X → Y) (z : Bidual 𝕜 X) : Bidual 𝕜 Y :=
  diagExtV z (symmForm 𝕜 n P)

/-- The defining property {lit}`P̃(z)(y*) = (y* ∘ P)~(z)` of the vector-valued extension. -/
theorem abExtV_apply {P : X → Y} (hP : IsHomPoly 𝕜 n P) (z : Bidual 𝕜 X)
    (g : StrongDual 𝕜 Y) : abExtV 𝕜 n P z g = abExt 𝕜 n (fun x => g (P x)) z := by
  rw [abExtV, diagExtV_apply, abExt, symmForm_comp hP]

/-- The canonical extension extends {lit}`P`: {lit}`P̃(Jx) = P(x)`. -/
theorem abExt_inclusion {P : X → 𝕜} (hP : IsHomPoly 𝕜 n P) (x : X) :
    abExt 𝕜 n P (NormedSpace.inclusionInDoubleDual 𝕜 X x) = P x := by
  rw [abExt, diagExt_inclusion, ← diag_apply, diag_symmForm hP]

end LindenstraussPolynomials
