import LindenstraussPolynomials.Theorems
import LindenstraussPolynomials.Geometry
import LindenstraussPolynomials.LemmaK

/-!
# Density of polynomials whose Aron–Berner extensions attain their norms

A Lean 4 formalization, with Mathlib, of the article *Density of polynomials whose Aron–Berner extensions attain their norms* by J. Falcó. Every result below is proved without {lit}`sorry` and depends only on the standard axioms {lit}`propext`, {lit}`Classical.choice` and {lit}`Quot.sound`. The scalar field is any {lit}`RCLike` field, so each statement holds over $`\mathbb R` and over $`\mathbb C`.

## The theorems

* Theorem {lit}`thm:main` (polynomial Lindenstrauss theorem): {name}`LindenstraussPolynomials.polynomial_lindenstrauss`, and its density form {name}`LindenstraussPolynomials.polynomial_lindenstrauss_dense`.
* Theorem {lit}`thm:vector` (vector-valued version): {name}`LindenstraussPolynomials.polynomial_lindenstrauss_vector`.
* Lemma {lit}`lem:isometry` (Davie–Gamelin): {name}`LindenstraussPolynomials.polyNorm_abExt` and {name}`LindenstraussPolynomials.polyNorm_abExtV`.
* Lemma {lit}`lem:K`: {name}`LindenstraussPolynomials.lemmaK`.
* Lemma {lit}`lem:geometry` and Remark {lit}`rem:real`: {name}`LindenstraussPolynomials.geometry_lemma` and {name}`LindenstraussPolynomials.geometry_lemma_real`.

## How it is organized

The modules follow the article: polynomials and their norms, polarization, the canonical extension and its norm preservation, the estimate for nonnegative polynomials, the substitutions and the geometric lemma, and then the perturbation scheme — step sizes, construction, limit, deficits, ordered compositions — and the passage to the bidual along an ultrafilter. As the final note of the article suggests, the formal proof follows the vector-valued scheme of Section 3 and obtains the scalar case by taking $`Y=\mathbb K`.

## Conventions

* A polynomial is a function $`P\colon X\to Y` with $`P(x)=L(x,\ldots,x)` for a continuous $`n`-linear $`L`.
* $`\|P\|` is the supremum of $`\|P(x)\|` over the closed unit ball.
* The canonical extension extends the last variable first, as in the article.

The first formal proof was produced with the help of Aristotle (Harmonic) for Lean and Mathlib v4.28.0; it was ported to Lean and Mathlib v4.35.0 and reviewed against the article in Proofline.
-/
