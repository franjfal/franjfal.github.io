# Density of polynomials whose Aron–Berner extensions attain their norms — Lean formalization

A Lean 4 formalization, with Mathlib, of the article *Density of polynomials whose Aron–Berner extensions attain their norms* by J. Falcó.

| Article | Lean |
|---|---|
| Theorem `thm:main` | `LindenstraussPolynomials.polynomial_lindenstrauss`, `polynomial_lindenstrauss_dense` |
| Theorem `thm:vector` | `LindenstraussPolynomials.polynomial_lindenstrauss_vector` |
| Lemma `lem:isometry` (Davie–Gamelin) | `polyNorm_abExt`, `polyNorm_abExtV` |
| Lemma `lem:K` | `lemmaK` |
| Lemma `lem:geometry` | `geometry_lemma` |
| Remark `rem:real` | `geometry_lemma_real` |

Every declaration depends only on the standard axioms (`propext`, `Classical.choice`, `Quot.sound`); nothing uses `sorry`. The scalar field is any `RCLike` field, so the results hold over ℝ and ℂ. `X` need not be complete; in the vector-valued theorem only the codomain `Y` is.

The first formal proof was produced with Aristotle (Harmonic) for Lean and Mathlib v4.28.0. It was ported to Lean and Mathlib v4.35.0 — renamed Mathlib lemmas only, no statement changed — reviewed against the article, and documented with Verso in Proofline.

Formalizes results of [arXiv:2610.18117v1](https://arxiv.org/abs/2610.18117v1).


## Verification

Verified by Proofline on 2026-10-25T20:03:13.398632+00:00 with Lean (version 4.35.0, arm64-apple-darwin24.6.0, commit eb6cafb7290e8bd5f2937522d8d804f58f02bafc, Release), Mathlib v4.35.0 (56a005855ea1) and Verso v4.35.0 (304b8561790c): **Verified**.

To check it yourself:

```bash
# install elan: https://lean-lang.org/install/
lake exe cache get   # Mathlib's prebuilt files
lake build
lake query :literateHtml   # optional: the interactive documentation
```

`lake-manifest.json` pins every dependency to the exact revision that was verified; `VERIFICATION.json` records the result, including the axioms each declaration depends on.
